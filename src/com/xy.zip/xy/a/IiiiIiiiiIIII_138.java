/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iIIiiiiiIIIIi
 */
package com.xy.a;

import com.xy.a.iIIiiiiiIIIIi;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiiIiiiiIIII
extends JComponent {
    final /* synthetic */ iIIiiiiiIIIIi ALLATORIxDEMO;

    IiiiIiiiiIIII(iIIiiiiiIIIIi iIIiiiiiIIIIi2) {
        this.ALLATORIxDEMO = iIIiiiiiIIIIi2;
    }
}
