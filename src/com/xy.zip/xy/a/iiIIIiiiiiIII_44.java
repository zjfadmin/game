/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiiIiiiiIIIIi
 */
package com.xy.a;

import com.xy.a.IiiIiiiiIIIIi;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiIIIiiiiiIII
implements ListSelectionListener {
    final /* synthetic */ IiiIiiiiIIIIi ALLATORIxDEMO;

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        this.ALLATORIxDEMO.iIiIiiiiIIiii(IiiIiiiiIIIIi.ALLATORIxDEMO((IiiIiiiiIIIIi)this.ALLATORIxDEMO).getSelectedIndex());
    }

    iiIIIiiiiiIII(IiiIiiiiIIIIi iiiIiiiiIIIIi) {
        this.ALLATORIxDEMO = iiiIiiiiIIIIi;
    }
}
