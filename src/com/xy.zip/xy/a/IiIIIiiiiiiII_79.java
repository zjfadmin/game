/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIiIiiiiiIIi
 *  com.xy.a.IiIiiiiiIIIII
 *  com.xy.a.IiIiiiiiIiIii
 *  com.xy.a.q.iiIiIiiiiIiIi
 *  com.xy.i.IIIIIiiiIIIiI
 *  com.xy.q.IIiIIiiiIIIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiII
 *  com.xy.q.iIIiIiiiIiiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.q.iiIiIiiiiIiIi
 *  com.xy.readbean.MoneyType
 *  com.xy.richtext.RichLabel
 *  com.xy.text.GameView
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 *  com.xy.w.IIiIiiiiIIiii
 */
package com.xy.a;

import com.xy.a.IiIiIiiiiiIIi;
import com.xy.a.IiIiiiiiIIIII;
import com.xy.a.IiIiiiiiIiIii;
import com.xy.a.q.iiIiIiiiiIiIi;
import com.xy.i.IIIIIiiiIIIiI;
import com.xy.q.IIiIIiiiIIIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiII;
import com.xy.q.iIIiIiiiIiiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.readbean.MoneyType;
import com.xy.richtext.RichLabel;
import com.xy.text.GameView;
import com.xy.w.IIIIIiiiIiiII;
import com.xy.w.IIIiiiiiIiIiI;
import com.xy.w.IIiIiiiiIIiii;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIIIiiiiiiII
extends JComponent {
    private IIIiiiiiIiIiI[] iIIIIiiiiiIIi;
    private int IiiIIiiiiiiiI;
    private IIIiiiiiIiIiI IIiiiiiiIiiII;
    private iiIiIiiiiIiIi[] IiiiIiiiIiIII;
    private IiiiIiiiiIiII[] IIiiiiiiiIIIi;
    final /* synthetic */ IiIiiiiiIIIII IIIiiiiiIIiII;
    private JComponent iiIiiiiiiIIiI;
    private IIIIIiiiIIIiI[] iIiiIiiiIiIIi = new IIIIIiiiIIIiI[2];
    private JLabel iiiiIiiiIIiii;
    private int iIIiIiiiiiiIi;
    private JComponent IIIIiiiiiiiII;
    private iIIiIiiiIiiIi iiIIIiiiiiiiI;
    private com.xy.q.iiIiIiiiiIiIi IiIiiiiiIIIII;
    private IIIIIiiiIIIiI[] iiIiIiiiiIIIi;
    private IIIIIiiiIIIiI[] iiiiIiiiIiiII;
    private iIIiIiiiIiiIi[] iiiIiiiiiiiIi;
    private RichLabel iIiiIiiiiiiII;
    private MoneyType IIiiIiiiIIiIi;
    private IIiIIiiiIIIiI[] iIiIiiiiIiIii;
    private JLabel[] IiIIIiiiiIiiI;
    private com.xy.q.iiIiIiiiiIiIi[] iiIiiiiiiiIii;
    private MoneyType IiiiiiiiIIIII;
    private int ALLATORIxDEMO;

    static /* synthetic */ com.xy.q.iiIiIiiiiIiIi[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iiIiiiiiiiIii;
    }

    static /* synthetic */ iIIiIiiiIiiIi[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iiiIiiiiiiiIi;
    }

    static /* synthetic */ MoneyType ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.IIiiIiiiIIiIi;
    }

    static /* synthetic */ void iiiIiiiiiiIIi(IiIIIiiiiiiII arg0, int arg1) {
        arg0.iIIiIiiiiiiIi = arg1;
    }

    static /* synthetic */ iiIiIiiiiIiIi[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.IiiiIiiiIiIII;
    }

    static /* synthetic */ IIIIIiiiIIIiI[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iIiiIiiiIiIIi;
    }

    static /* synthetic */ void iIiIiiiiIIiii(IiIIIiiiiiiII arg0, int arg1) {
        arg0.IiiIIiiiiiiiI = arg1;
    }

    static /* synthetic */ IIiIIiiiIIIiI[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iIiIiiiiIiIii;
    }

    static /* synthetic */ void ALLATORIxDEMO(IiIIIiiiiiiII arg0, int arg1) {
        arg0.ALLATORIxDEMO = arg1;
    }

    static /* synthetic */ int iiiIiiiiiiIIi(IiIIIiiiiiiII arg0) {
        return arg0.IiiIIiiiiiiiI;
    }

    static /* synthetic */ iIIiIiiiIiiIi ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iiIIIiiiiiiiI;
    }

    static /* synthetic */ JComponent iIiIiiiiIIiii(IiIIIiiiiiiII arg0) {
        return arg0.IIIIiiiiiiiII;
    }

    static /* synthetic */ IiiiIiiiiIiII[] ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.IIiiiiiiiIIIi;
    }

    public void ALLATORIxDEMO() {
    }

    static /* synthetic */ int iIiIiiiiIIiii(IiIIIiiiiiiII arg0) {
        return arg0.ALLATORIxDEMO;
    }

    static /* synthetic */ com.xy.q.iiIiIiiiiIiIi ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.IiIiiiiiIIIII;
    }

    static /* synthetic */ int ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iIIiIiiiiiiIi;
    }

    public IiIIIiiiiiiII(IiIiiiiiIIIII iiIiiiiiIIIII) {
        this.IIIiiiiiIIiII = iiIiiiiiIIIII;
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIiiIiiiIiIIi.length) {
            this.iIiiIiiiIiIIi[IiiiiiiiIIIII] = new IIIIIiiiIIIiI("sc/e/39.png", 2, 165 + IiiiiiiiIIIII, iiIIiiiiIiiII.IIiiIiiiIIiIi, null, IiiiiiiiIIIII == 0 ? "\u65a9\u5996\u79ef\u5206" : (IiiiiiiiIIIII == 1 ? "\u4f0f\u9b54\u4ee4" : ""), iiIiiiiiIIIII.ALLATORIxDEMO());
            this.iIiiIiiiIiIIi[IiiiiiiiIIIII].setOffsetTexts(iiIIiiiiIiiII.IiIIIiiiiiiiI);
            this.iIiiIiiiIiIIi[IiiiiiiiIIIII].setBounds(50 + 102 * IiiiiiiiIIIII, 60, 100, 24);
            this.add((Component)this.iIiiIiiiIiIIi[IiiiiiiiIIIII++]);
        }
        this.iiIiiiiiiIIiI = new IiIiIiiiiiIIi(this);
        this.IIIIiiiiiiiII = new IiIiiiiiIiIii(this);
        this.iiIiiiiiiIIiI.setBounds(0, 0, 620, 479);
        this.IIIIiiiiiiiII.setBounds(0, 0, 620, 479);
        this.add(this.iiIiiiiiiIIiI);
        this.add(this.IIIIiiiiiiiII);
        this.IiiiiiiiIIIII = new MoneyType();
        this.IiiiiiiiIIIII.setIdAndKey(0, "\u65a9\u5996\u79ef\u5206");
        this.IiIiiiiiIIIII = IiIIIiiiiIIiI.ALLATORIxDEMO((int)483, (int)62, (int)110, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii, (MoneyType)this.IiiiiiiiIIIII, (GameView)iiIiiiiiIIIII.iiIIiiiiIiIIi);
        this.iiIIIiiiiiiiI = IiIIIiiiiIIiI.ALLATORIxDEMO((int)290, (int)430, (int)58, (int)18, (int)0, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii);
        this.IiIiiiiiIIIII.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
        this.iiIIIiiiiiiiI.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
        this.IiIiiiiiIIIII.ALLATORIxDEMO(2);
        this.iiIiiiiiiIIiI.add((Component)this.IiIiiiiiIIIII);
        this.iiIiiiiiiIIiI.add((Component)this.iiIIIiiiiiiiI);
        this.IiiiIiiiIiIII = new iiIiIiiiiIiIi[8];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiiiIiiiIiIII.length) {
            this.IiiiIiiiIiIII[IiiiiiiiIIIII] = new iiIiIiiiiIiIi(iiIiiiiiIIIII.ALLATORIxDEMO());
            this.IiiiIiiiIiIII[IiiiiiiiIIIII].setBounds(58 + IiiiiiiiIIIII % 4 * 138, 105 + IiiiiiiiIIIII / 4 * 165, 115, 150);
            this.iiIiiiiiiIIiI.add((Component)this.IiiiIiiiIiIII[IiiiiiiiIIIII++]);
        }
        this.iiiiIiiiIIiii = IiIIIiiiiIIiI.ALLATORIxDEMO((int)411, (int)62, (int)110, (int)19, (Color)Color.black, (Font)iiIIiiiiIiiII.iiiiIiiiIiiII);
        this.iiiiIiiiIIiii.setText("\u65a9\u5996\u79ef\u5206");
        this.iiIiiiiiiIIiI.add(this.iiiiIiiiIIiii);
        this.iiIiIiiiiIIIi = new IIIIIiiiIIIiI[4];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiIiIiiiiIIIi.length) {
            if (IiiiiiiiIIIII == 0 || IiiiiiiiIIIII == 1) {
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII] = new IIIIIiiiIIIiI("sc/e/6.png", 1, 167 + IiiiiiiiIIIII, iiIIiiiiIiiII.iiIiiiiiiIIiI, null, IiiiiiiiIIIII == 0 ? "\u9996\u9875" : (IiiiiiiiIIIII == 1 ? "\u672b\u9875" : ""), iiIiiiiiIIIII.ALLATORIxDEMO());
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII].setBounds(232 + IiiiiiiiIIIII * 140, 430, 34, 18);
            } else {
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII] = new IIIIIiiiIIIiI(IiiiiiiiIIIII == 2 ? "sc/e/42.png" : "sc/e/43.png", 1, 167 + IiiiiiiiIIIII, iiIiiiiiIIIII.ALLATORIxDEMO());
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII].setBounds(269 + (IiiiiiiiIIIII - 2) * 82, 430, 18, 18);
            }
            this.iiIiiiiiiIIiI.add((Component)this.iiIiIiiiiIIIi[IiiiiiiiIIIII++]);
        }
        this.iiiiIiiiIiiII = new IIIIIiiiIIIiI[2];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiiiIiiiIiiII.length) {
            this.iiiiIiiiIiiII[IiiiiiiiIIIII] = new IIIIIiiiIIIiI("sc/e/31.png", 1, 171 + IiiiiiiiIIIII, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IIiiiiiiIiiII, "\u5151\u6362", iiIiiiiiIIIII.ALLATORIxDEMO());
            this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(415, 156 + IiiiiiiiIIIII * 150, 79, 25);
            this.IIIIiiiiiiiII.add((Component)this.iiiiIiiiIiiII[IiiiiiiiIIIII++]);
        }
        this.IiIIIiiiiIiiI = new JLabel[10];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIIiiiiIiiI.length) {
            this.IiIIIiiiiIiiI[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)150, (int)(100 + 150 * IiiiiiiiIIIII), (int)100, (int)19, (Color)Color.black, (Font)iiIIiiiiIiiII.iiiiIiiiIiiII);
            this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setText(IiiiiiiiIIIII == 0 || IiiiiiiiIIIII == 1 ? "\u4f0f\u9b54\u4ee4" : (IiiiiiiiIIIII == 2 || IiiiiiiiIIIII == 5 ? "\u62e5\u6709" : (IiiiiiiiIIIII == 3 || IiiiiiiiIIIII == 6 ? "\u5151\u6362" : (IiiiiiiiIIIII == 4 || IiiiiiiiIIIII == 7 ? "\u83b7\u5f97" : (IiiiiiiiIIIII == 8 ? "\u3010\u4eba\u7269\u7ecf\u9a8c\u3011" : (IiiiiiiiIIIII == 9 ? "\u3010\u52c7\u8005\u79ef\u5206\u3011" : ""))))));
            this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setHorizontalAlignment(0);
            if (IiiiiiiiIIIII >= 2 && IiiiiiiiIIIII <= 4) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(263, 132 + (IiiiiiiiIIIII - 2) * 27, 36, 19);
            } else if (IiiiiiiiIIIII >= 5 && IiiiiiiiIIIII <= 7) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(263, 283 + (IiiiiiiiIIIII - 5) * 27, 36, 19);
            } else if (IiiiiiiiIIIII >= 8 && IiiiiiiiIIIII <= 9) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setHorizontalAlignment(10);
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setFont(iiIIiiiiIiiII.iIIiiiiiiIIII);
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(300, 206 + (IiiiiiiiIIIII - 8) * 150, 80, 14);
            }
            this.IIIIiiiiiiiII.add(this.IiIIIiiiiIiiI[IiiiiiiiIIIII++]);
        }
        this.iIiiIiiiiiiII = new RichLabel("", iiIIiiiiIiiII.iIIiiiiiiIIII);
        this.iIiiIiiiiiiII.setTextSize("#c000000\u6e29\u99a8\u63d0\u793a\uff1a#r1\u3001\u6bcf\u5f20\u4f0f\u9b54\u4ee4\u53ef\u5151\u6362\u7684\u4eba\u7269\u7ecf\u9a8c\u4e0e\u5151\u6362\u65f6\u7684\u4eba\u7269\u7b49\u7ea7\u6709\u5173\u3002#r2\u3001\u6bcf\u5f20\u4f0f\u9b54\u4ee4\u53ef\u5151\u6362\u7684\u52c7\u8005\u79ef\u5206\uff0c\u6839\u636e\u4ef7\u683c\u89c4\u5f8b\u6d6e\u52a8\u3002", 360);
        this.iIiiIiiiiiiII.setBounds(149, 385, this.iIiiIiiiiiiII.getWidth(), this.iIiiIiiiiiiII.getHeight());
        this.IIIIiiiiiiiII.add((Component)this.iIiiIiiiiiiII);
        this.IIiiIiiiIIiIi = new MoneyType();
        this.IIiiIiiiIIiIi.setIdAndKey(0, "\u4f0f\u9b54\u4ee4");
        this.iIiIiiiiIiIii = new IIiIIiiiIIIiI[2];
        this.iiIiiiiiiiIii = new com.xy.q.iiIiIiiiiIiIi[2];
        this.IIiiiiiiiIIIi = new IiiiIiiiiIiII[2];
        this.iiiIiiiiiiiIi = new iIIiIiiiIiiIi[2];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < 2) {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)305, (int)(132 + 150 * IiiiiiiiIIIII), (int)94, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii, (MoneyType)this.IIiiIiiiIIiIi, (GameView)iiIiiiiiIIIII.iiIIiiiiIiIIi);
            this.IIiiiiiiiIIIi[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((IIiIiiiiIIiii)IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)6, (int)6, (int)6, (int)6, (boolean)false), (Font)iiIIiiiiIiiII.iIIIiiiiIIIii, (Color)Color.white);
            this.iiiIiiiiiiiIi[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)305, (int)(186 + 150 * IiiiiiiiIIIII), (int)94, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii);
            this.IIiiiiiiiIIIi[IiiiiiiiIIIII].setBounds(305, 159 + 150 * IiiiiiiiIIIII, 94, 19);
            this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
            this.iiiIiiiiiiiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
            this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(2);
            this.IIIIiiiiiiiII.add((Component)this.IIiiiiiiiIIIi[IiiiiiiiIIIII]);
            this.IIIIiiiiiiiII.add((Component)this.iiiIiiiiiiiIi[IiiiiiiiIIIII]);
            this.IIIIiiiiiiiII.add((Component)this.iiIiiiiiiiIii[IiiiiiiiIIIII]);
            int n = IiiiiiiiIIIII;
            IIiIIiiiIIIiI iIiIIiiiIIIiI = new IIiIIiiiIIIiI(15, (JTextField)this.IIiiiiiiiIIIi[IiiiiiiiIIIII], iiIiiiiiIIIII.ALLATORIxDEMO());
            ++IiiiiiiiIIIII;
            this.iIiIiiiiIiIii[n] = iIiIIiiiIIIiI;
        }
        this.iIIIIiiiiiIIi = new IIIiiiiiIiIiI[5];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIIIIiiiiiIIi.length) {
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII] = new IIIiiiiiIiIiI();
            if (IiiiiiiiIIIII >= 0 && IiiiiiiiIIIII <= 1) {
                if (IiiiiiiiIIIII == 0) {
                    this.iIIIIiiiiiIIi[IiiiiiiiIIIII].iIiIiiiiIIiii("sc/d/77.png");
                } else if (IiiiiiiiIIIII == 1) {
                    this.iIIIIiiiiiIIi[IiiiiiiiIIIII].iIiIiiiiIIiii("sc/d/78.png");
                }
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII].setBounds(154, 123 + IiiiiiiiIIIII * 150, 92, 92);
            } else if (IiiiiiiiIIIII >= 2 && IiiiiiiiIIIII <= 3) {
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/4.png", (int)5, (int)5, (int)5, (int)5, (boolean)false));
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII].setBounds(150, 119 + (IiiiiiiiIIIII - 2) * 150, 100, 100);
            } else if (IiiiiiiiIIIII == 4) {
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/66.png", (int)80, (int)1, (int)80, (int)1, (boolean)false));
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII].setBounds(112, 237, 416, 2);
            }
            this.IIIIiiiiiiiII.add((Component)this.iIIIIiiiiiIIi[IiiiiiiiIIIII++]);
        }
        this.IIiiiiiiIiiII = new IIIiiiiiIiIiI(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/36.png", (int)20, (int)20, (int)20, (int)20, (boolean)false));
        this.IIiiiiiiIiiII.setBounds(43, 84, 550, 374);
        this.add((Component)this.IIiiiiiiIiiII);
        this.setBounds(0, 0, 620, 479);
    }

    static /* synthetic */ JComponent ALLATORIxDEMO(IiIIIiiiiiiII arg0) {
        return arg0.iiIiiiiiiIIiI;
    }
}
