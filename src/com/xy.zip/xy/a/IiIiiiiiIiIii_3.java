/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIIIiiiiiiII
 */
package com.xy.a;

import com.xy.a.IiIIIiiiiiiII;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIiiiiiIiIii
extends JComponent {
    final /* synthetic */ IiIIIiiiiiiII ALLATORIxDEMO;

    IiIiiiiiIiIii(IiIIIiiiiiiII iiIIIiiiiiiII) {
        this.ALLATORIxDEMO = iiIIIiiiiiiII;
    }
}
