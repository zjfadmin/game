/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IIiIiiiiIIiii
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a;

import com.xy.a.IIiIiiiiIIiii;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiiIiiiIiiiI
extends IIIiiiiiIiIiI {
    final /* synthetic */ IIiIiiiiIIiii ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        IIiIiiiiIIiii.ALLATORIxDEMO((IIiIiiiiIIiii)this.ALLATORIxDEMO).mouseReleased(e);
    }

    IIiiIiiiIiiiI(IIiIiiiiIIiii iIiIiiiiIIiii, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIiIiiiiIIiii;
        super($anonymous0);
    }
}
