/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIiIiiiiiIIi
 */
package com.xy.a;

import com.xy.a.iiIiIiiiiiIIi;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIIIiiiiiiIi
extends JComponent {
    final /* synthetic */ iiIiIiiiiiIIi ALLATORIxDEMO;

    IiIIIiiiiiiIi(iiIiIiiiiiIIi iiIiIiiiiiIIi2) {
        this.ALLATORIxDEMO = iiIiIiiiiiIIi2;
    }
}
