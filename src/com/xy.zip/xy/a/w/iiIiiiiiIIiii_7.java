/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIiiiiiIIiiI
 *  com.xy.a.w.IIIiiiiiiiiIi
 */
package com.xy.a.w;

import com.xy.a.iiIiiiiiIIiiI;
import com.xy.a.w.IIIiiiiiiiiIi;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiIiiiiiIIiii
extends JLabel
implements MouseListener {
    private String iiIiiiiiiiIii;
    final /* synthetic */ IIIiiiiiiiiIi IiiiiiiiIIIII;
    private double ALLATORIxDEMO;

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
        this.IiiiiiiiIIIII.ALLATORIxDEMO().iiiIiiiiiiIIi(46);
    }

    static /* synthetic */ void ALLATORIxDEMO(iiIiiiiiIIiii arg0, double arg1) {
        arg0.ALLATORIxDEMO = arg1;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        Object IiiiiiiiIIIII;
        String IiiiiiiiIIIII2 = null;
        if (this.iiIiiiiiiiIii.equals("kwl")) {
            IiiiiiiiIIIII2 = "\u80fd\u591f\u62b5\u6297\u7269\u7406\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kzs")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u9707\u6151\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kff")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u98ce\u7cfb\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("klf")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u96f7\u7cfb\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("ksf")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u6c34\u7cfb\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("khf")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("khl")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u4e2d\u6df7\u4e71\u6cd5\u672f\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("khs")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u4e2d\u660f\u7761\u6cd5\u672f\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kfy")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u4e2d\u5c01\u5370\u6cd5\u672f\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kzd")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u4e2d\u6bd2\u6cd5\u672f\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kzds")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u4e2d\u6bd2\u6cd5\u672f\u4f24\u5bb3\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("kyw")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u4e2d\u9057\u5fd8\u6cd5\u672f\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kgh")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u9b3c\u706b\u6cd5\u672f\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("ksc")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u4e09\u5c38\u6cd5\u672f\u4f24\u5bb3\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("klb")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u7075\u5b9d\u4f24\u5bb3\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("kqk")) {
            IiiiiiiiIIIII2 = "\u51cf\u5c11\u53d7\u5230\u6240\u6709\u7684\u5f3a\u529b\u514b\u6548\u679c\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kwsx")) {
            IiiiiiiiIIIII2 = "\u51cf\u5c11\u53d7\u5230\u65e0\u5c5e\u6027\u4f24\u5bb3\u6548\u679c\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kzshp")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u9707\u6151\u6cd5\u672f\u6c14\u8840\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kzsmp")) {
            IiiiiiiiIIIII2 = "\u80fd\u62b5\u6297\u9707\u6151\u6cd5\u672f\u9b54\u6cd5\u4f24\u5bb3\u7684\u4e00\u5b9a\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("kjge")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6cd5\u5b9d\u91d1\u7b8d\u63a7\u5236\u7684\u51e0\u7387\u51cf\u5c0f";
        } else if (this.iiIiiiiiiiIii.equals("kqw")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6cd5\u5b9d\u60c5\u7f51\u63a7\u5236\u7684\u51e0\u7387\u51cf\u5c0f";
        } else if (this.iiIiiiiiiiIii.equals("khr")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u6d69\u7136\u6b63\u6c14\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("kgs")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u9694\u5c71\u6253\u725b\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("kqm")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u9752\u9762\u7360\u7259\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("ktm")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u5929\u9b54\u89e3\u4f53\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("kxl")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u5c0f\u697c\u591c\u54ed\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("kfg")) {
            IiiiiiiiIIIII2 = "\u62b5\u6297\u4e00\u5b9a\u7684\u5185\u4e39\u5206\u5149\u5316\u5f71\u4f24\u5bb3";
        } else if (this.iiIiiiiiiiIii.equals("kzml")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u7269\u7406\u653b\u51fb\u65f6\u81f4\u547d\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kbf")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u98ce\u7cfb\u6cd5\u672f\u4f24\u5bb3\u65f6\u72c2\u66b4\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kbh")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u65f6\u72c2\u66b4\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kbs")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u6c34\u7cfb\u6cd5\u672f\u4f24\u5bb3\u65f6\u72c2\u66b4\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kbl")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u96f7\u7cfb\u6cd5\u672f\u4f24\u5bb3\u65f6\u72c2\u66b4\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kbg")) {
            IiiiiiiiIIIII2 = "\u964d\u4f4e\u53d7\u5230\u9b3c\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u65f6\u72c2\u66b4\u89e6\u53d1\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("kwlgj")) {
            IiiiiiiiIIIII2 = "\u80fd\u591f\u62b5\u6297\u7269\u7406\u4f24\u5bb3\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hfyv")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u65e0\u89c6\u5bf9\u65b9\u7269\u7406\u6297\u6027\u7a0b\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("hfyl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u65e0\u89c6\u5bf9\u65b9\u7269\u7406\u6297\u6027\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("hff")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u98ce\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hlf")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u96f7\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hsf")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u6c34\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hhf")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u706b\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hhl")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u6df7\u4e71\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hhs")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u660f\u7761\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hfy")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u5c01\u5370\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hzd")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u6bd2\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hzs")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u9707\u6151\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hds")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u7269\u7406\u8eb2\u95ea\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hfj")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u7269\u7406\u53cd\u51fb\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hxfkl")) {
            IiiiiiiiIIIII2 = "\u4ed9\u6cd5\u653b\u51fb\u65f6\u65e0\u89c6\u5bf9\u65b9\u4ed9\u6cd5\u6297\u6027\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("hxfcd")) {
            IiiiiiiiIIIII2 = "\u4ed9\u6cd5\u653b\u51fb\u65f6\u65e0\u89c6\u5bf9\u65b9\u4ed9\u6cd5\u6297\u6027\u7a0b\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("hgh")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u9b3c\u706b\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("hyw")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u9057\u5fd8\u6297\u6027\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("qff")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u98ce\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qlf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u96f7\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qsf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6c34\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qhf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u706b\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qhl")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6df7\u4e71\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qhs")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u660f\u7761\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qzs")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9707\u6151\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qfy")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u5c01\u5370\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qzd")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6bd2\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qzds")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6bd2\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qgh")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9b3c\u706b\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qyw")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9057\u5fd8\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qsc")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u4e09\u5c38\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qschx")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u4e09\u5c38\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qqk")) {
            IiiiiiiiIIIII2 = "\u589e\u52a0\u81ea\u8eab\u6240\u6709\u7684\u5f3a\u529b\u514b\u6548\u679c\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("qzhs")) {
            IiiiiiiiIIIII2 = "\u589e\u52a0\u81ea\u8eab\u5bf9\u53ec\u5524\u517d\u4f24\u5bb3\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("qgjf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u52a0\u653b\u6cd5\u672f\u7684\u6548\u679c";
        } else if (this.iiIiiiiiiiIii.equals("qfyf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u52a0\u9632\u6cd5\u672f\u7684\u6548\u679c";
        } else if (this.iiIiiiiiiiIii.equals("qsdf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u52a0\u901f\u6cd5\u672f\u7684\u6548\u679c";
        } else if (this.iiIiiiiiiiIii.equals("qmh")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9b45\u60d1\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qjg")) {
            IiiiiiiiIIIII2 = "\u4f7f\u7528\u6cd5\u5b9d\u91d1\u7b8d\u6210\u529f\u7387\u589e\u52a0";
        } else if (this.iiIiiiiiiiIii.equals("qqw")) {
            IiiiiiiiIIIII2 = "\u4f7f\u7528\u6cd5\u5b9d\u60c5\u7f51\u6210\u529f\u7387\u589e\u52a0";
        } else if (this.iiIiiiiiiiIii.equals("qlpl")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9739\u96f3\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qlfy")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6276\u6447\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qlcb")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6ca7\u6ce2\u6cd5\u672f\u7684\u5f3a\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("qlglv")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u7518\u9716\u6cd5\u672f\u7684\u5f3a\u5ea6\u7684\u7edd\u5bf9\u503c";
        } else if (this.iiIiiiiiiiIii.equals("qlglc")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u7518\u9716\u6cd5\u672f\u7684\u5f3a\u5ea6\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("eds")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("efjl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u6240\u80fd\u53cd\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("efjv")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u6240\u80fd\u53cd\u51fb\u7684\u6b21\u6570";
        } else if (this.iiIiiiiiiiIii.equals("efjff")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u98ce\u6cd5\u53cd\u51fb\u5bf9\u65b9";
        } else if (this.iiIiiiiiiiIii.equals("efjhf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u706b\u6cd5\u53cd\u51fb\u5bf9\u65b9";
        } else if (this.iiIiiiiiiiIii.equals("efjsf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u6c34\u6cd5\u53cd\u51fb\u5bf9\u65b9";
        } else if (this.iiIiiiiiiiIii.equals("efjlf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u96f7\u6cd5\u53cd\u51fb\u5bf9\u65b9";
        } else if (this.iiIiiiiiiiIii.equals("efjkx")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u91ca\u653e\u542b\u60c5\u8109\u8109\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("efjjs")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u91ca\u653e\u4e7e\u5764\u501f\u901f\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("efjll")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7269\u7406\u653b\u51fb\u91ca\u653e\u9b54\u795e\u9644\u4f53\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("eljl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u6240\u80fd\u8fde\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("eljv")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u6240\u80fd\u8fde\u51fb\u7684\u6b21\u6570";
        } else if (this.iiIiiiiiiiIii.equals("emzl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("ezml")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u4e00\u5b9a\u51e0\u7387\u51fa\u73b0\u81f4\u547d\u51e0\u7387\uff0c\u654c\u65b9\u8840\u91cf\u8d8a\u591a\u6548\u679c\u8d8a\u9ad8";
        } else if (this.iiIiiiiiiiIii.equals("ekbl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u65f6\u4e00\u5b9a\u51e0\u7387\u5c06\u81ea\u8eab\u9632\u5fa1\u7387\u8f6c\u5316\u4e3a\u653b\u51fb\u529b";
        } else if (this.iiIiiiiiiiIii.equals("efzl")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u4f24\u5bb3\u53cd\u9707\u7ed9\u5bf9\u65b9\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("efzcd")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u4f24\u5bb3\u53cd\u9707\u7ed9\u5bf9\u65b9\u7684\u7a0b\u5ea6";
        } else if (this.iiIiiiiiiiIii.equals("exfljl")) {
            IiiiiiiiIIIII2 = "\u4ed9\u6cd5\u653b\u51fb\u65f6\u6240\u80fd\u8fde\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("exfljs")) {
            IiiiiiiiIIIII2 = "\u4ed9\u6cd5\u653b\u51fb\u65f6\u6240\u80fd\u8fde\u51fb\u7684\u6b21\u6570";
        } else if (this.iiIiiiiiiiIii.equals("ejs")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6240\u6709\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("efsds")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("wxj")) {
            IiiiiiiiIIIII2 = "\u4e94\u884c\u4e4b\u4e00,\u91d1\u514b\u6728";
        } else if (this.iiIiiiiiiiIii.equals("wxm")) {
            IiiiiiiiIIIII2 = "\u4e94\u884c\u4e4b\u4e00,\u6728\u514b\u571f";
        } else if (this.iiIiiiiiiiIii.equals("wxt")) {
            IiiiiiiiIIIII2 = "\u4e94\u884c\u4e4b\u4e00,\u571f\u514b\u6c34";
        } else if (this.iiIiiiiiiiIii.equals("wxs")) {
            IiiiiiiiIIIII2 = "\u4e94\u884c\u4e4b\u4e00,\u6c34\u514b\u706b";
        } else if (this.iiIiiiiiiiIii.equals("wxh")) {
            IiiiiiiiIIIII2 = "\u4e94\u884c\u4e4b\u4e00,\u706b\u514b\u91d1";
        } else if (this.iiIiiiiiiiIii.equals("wxqj")) {
            IiiiiiiiIIIII2 = "\u5bf9\u4e94\u884c\u5c5e\u91d1\u7684\u76ee\u6807\u9020\u6210\u6cd5\u672f\u548c\u7269\u7406\u4f24\u5bb3\u65f6\uff0c\u53d7\u5230\u767e\u5206\u6bd4\u52a0\u6210";
        } else if (this.iiIiiiiiiiIii.equals("wxqm")) {
            IiiiiiiiIIIII2 = "\u5bf9\u4e94\u884c\u5c5e\u6728\u7684\u76ee\u6807\u9020\u6210\u6cd5\u672f\u548c\u7269\u7406\u4f24\u5bb3\u65f6\uff0c\u53d7\u5230\u767e\u5206\u6bd4\u52a0\u6210";
        } else if (this.iiIiiiiiiiIii.equals("wxqt")) {
            IiiiiiiiIIIII2 = "\u5bf9\u4e94\u884c\u5c5e\u571f\u7684\u76ee\u6807\u9020\u6210\u6cd5\u672f\u548c\u7269\u7406\u4f24\u5bb3\u65f6\uff0c\u53d7\u5230\u767e\u5206\u6bd4\u52a0\u6210";
        } else if (this.iiIiiiiiiiIii.equals("wxqs")) {
            IiiiiiiiIIIII2 = "\u5bf9\u4e94\u884c\u5c5e\u6c34\u7684\u76ee\u6807\u9020\u6210\u6cd5\u672f\u548c\u7269\u7406\u4f24\u5bb3\u65f6\uff0c\u53d7\u5230\u767e\u5206\u6bd4\u52a0\u6210";
        } else if (this.iiIiiiiiiiIii.equals("wxqh")) {
            IiiiiiiiIIIII2 = "\u5bf9\u4e94\u884c\u5c5e\u706b\u7684\u76ee\u6807\u9020\u6210\u6cd5\u672f\u548c\u7269\u7406\u4f24\u5bb3\u65f6\uff0c\u53d7\u5230\u767e\u5206\u6bd4\u52a0\u6210";
        } else if (this.iiIiiiiiiiIii.equals("swsx")) {
            IiiiiiiiIIIII2 = "\u5bf9\u65e0\u5c5e\u6027\u76ee\u6807\u4f24\u5bb3\u589e\u52a0";
        } else if (this.iiIiiiiiiiIii.equals("sff")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u98ce\u6cd5\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("slf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u96f7\u6cd5\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("ssf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6c34\u6cd5\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("shf")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u706b\u6cd5\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("szd")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u6bd2\u6cd5\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("sgh")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u9b3c\u706b\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("ssc")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u4e09\u5c38\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("sbls")) {
            IiiiiiiiIIIII2 = "\u52a0\u5f3a\u51b0\u5203\u672f\u4f24\u5bb3\u7684\u57fa\u7840\u503c";
        } else if (this.iiIiiiiiiiIii.equals("blf")) {
            IiiiiiiiIIIII2 = "\u96f7\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bff")) {
            IiiiiiiiIIIII2 = "\u98ce\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bsf")) {
            IiiiiiiiIIIII2 = "\u6c34\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bhf")) {
            IiiiiiiiIIIII2 = "\u706b\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bgh")) {
            IiiiiiiiIIIII2 = "\u9b3c\u706b\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bsc")) {
            IiiiiiiiIIIII2 = "\u4e09\u5c38\u7cfb\u6cd5\u672f\u72c2\u66b4\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjff")) {
            IiiiiiiiIIIII2 = "\u98ce\u6cd5\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjlf")) {
            IiiiiiiiIIIII2 = "\u96f7\u6cd5\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjsf")) {
            IiiiiiiiIIIII2 = "\u6c34\u6cd5\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjhf")) {
            IiiiiiiiIIIII2 = "\u706b\u6cd5\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjhl")) {
            IiiiiiiiIIIII2 = "\u6df7\u4e71\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjfy")) {
            IiiiiiiiIIIII2 = "\u5c01\u5370\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjhs")) {
            IiiiiiiiIIIII2 = "\u660f\u7761\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjzd")) {
            IiiiiiiiIIIII2 = "\u4e2d\u6bd2\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjzs")) {
            IiiiiiiiIIIII2 = "\u9707\u6151\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjjs")) {
            IiiiiiiiIIIII2 = "\u52a0\u901f\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjjg")) {
            IiiiiiiiIIIII2 = "\u52a0\u653b\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjjf")) {
            IiiiiiiiIIIII2 = "\u52a0\u9632\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjsc")) {
            IiiiiiiiIIIII2 = "\u4e09\u5c38\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjmh")) {
            IiiiiiiiIIIII2 = "\u9b45\u60d1\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjgh")) {
            IiiiiiiiIIIII2 = "\u9b3c\u706b\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjyw")) {
            IiiiiiiiIIIII2 = "\u9057\u5fd8\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjlpl")) {
            IiiiiiiiIIIII2 = "\u9739\u96f3\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjlfy")) {
            IiiiiiiiIIIII2 = "\u6276\u6447\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjlcb")) {
            IiiiiiiiIIIII2 = "\u6ca7\u6ce2\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("bjlgl")) {
            IiiiiiiiIIIII2 = "\u7518\u9716\u7cfb\u6cd5\u672f\u66b4\u51fb\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("blfcd")) {
            IiiiiiiiIIIII2 = "\u96f7\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("bffcd")) {
            IiiiiiiiIIIII2 = "\u98ce\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("bsfcd")) {
            IiiiiiiiIIIII2 = "\u6c34\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("bhfcd")) {
            IiiiiiiiIIIII2 = "\u706b\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("bghcd")) {
            IiiiiiiiIIIII2 = "\u9b3c\u706b\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("bsccd")) {
            IiiiiiiiIIIII2 = "\u4e09\u5c38\u866b\u7cfb\u6cd5\u672f\u72c2\u66b4\u540e\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("f_f")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u5c01\u5370\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_h")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u6df7\u4e71\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_d")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u4e2d\u6bd2\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_xf")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u98ce\u6cd5\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_xh")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u706b\u6cd5\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_xs")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u6c34\u6cd5\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_xl")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u96f7\u6cd5\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_zs")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u9707\u6151\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("f_sc")) {
            IiiiiiiiIIIII2 = "\u7269\u7406\u653b\u51fb\u9644\u52a0\u4e09\u5c38\u6cd5\u672f";
        } else if (this.iiIiiiiiiiIii.equals("dzs")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u9707\u6151\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dhf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dlf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u96f7\u7cfb\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dff")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u98ce\u7cfb\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dsf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6c34\u7cfb\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("ddf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6bd2\u7cfb\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dfy")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u5c01\u5370\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dhl")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6df7\u4e71\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dhs")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u660f\u7761\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dyw")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u9057\u5fd8\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dgh")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u9b3c\u706b\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("dsc")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u4e09\u5c38\u6cd5\u672f\u4f24\u5bb3\u8eb2\u95ea\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("jsf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u6c34\u7cfb\u6cd5\u672f\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("jff")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u98ce\u7cfb\u6cd5\u672f\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("jlf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u96f7\u7cfb\u6cd5\u672f\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("jhf")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("jgh")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u9b3c\u706b\u6cd5\u672f\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("jlb")) {
            IiiiiiiiIIIII2 = "\u53d7\u5230\u7075\u5b9d\u4f24\u5bb3\u51cf\u5c11\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("ehsfzl")) {
            IiiiiiiiIIIII2 = "\u5ffd\u89c6\u5bf9\u65b9\u53cd\u9707\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mzs")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u9707\u6151\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mhf")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u706b\u6cd5\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mlf")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u96f7\u6cd5\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mff")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u98ce\u6cd5\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("msf")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u6c34\u6cd5\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mdf")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u6bd2\u6cd5\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mfy")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u5c01\u5370\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mhl")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u6df7\u4e71\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mhs")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u660f\u7761\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("myw")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u9057\u5fd8\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("mgh")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u9b3c\u706b\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("msc")) {
            IiiiiiiiIIIII2 = "\u91ca\u653e\u4e09\u5c38\u65f6\u6240\u80fd\u547d\u4e2d\u7684\u51e0\u7387";
        } else if (this.iiIiiiiiiiIii.equals("zsf")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u6c34\u7cfb\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zff")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u98ce\u7cfb\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zlf")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u96f7\u7cfb\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zhf")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u706b\u7cfb\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zgh")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u9b3c\u706b\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zdf")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u6bd2\u7cfb\u6cd5\u672f\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        } else if (this.iiIiiiiiiiIii.equals("zzsmp")) {
            IiiiiiiiIIIII2 = "\u9020\u6210\u9707\u6151\u6cd5\u672f\u9b54\u6cd5\u4f24\u5bb3\u589e\u52a0\u7684\u767e\u5206\u6bd4";
        }
        if (IiiiiiiiIIIII2 == null) {
            return;
        }
        Integer IiiiiiiiIIIII3 = (Integer)IIIiiiiiiiiIi.ALLATORIxDEMO().get(this.iiIiiiiiiiIii);
        if (IiiiiiiiIIIII3 != null && (IiiiiiiiIIIII3 >> IIIiiiiiiiiIi.ALLATORIxDEMO((IIIiiiiiiiiIi)this.IiiiiiiiIIIII) & 1) == 1 && (IiiiiiiiIIIII = this.IiiiiiiiIIIII.ALLATORIxDEMO(this)) != null) {
            IiiiiiiiIIIII2 = String.valueOf(IiiiiiiiIIIII2) + "#r\u8ddd\u79bb\u6297\u6027\u4e0a\u9650:" + String.format("%.1f", IiiiiiiiIIIII);
        }
        IiiiiiiiIIIII = (iiIiiiiiIIiiI)this.IiiiiiiiIIIII.ALLATORIxDEMO().iiiIiiiiiiIIi(46);
        IiiiiiiiIIIII.iIiIiiiiIIiIi(IiiiiiiiIIIII2);
    }

    static /* synthetic */ void ALLATORIxDEMO(iiIiiiiiIIiii arg0, String arg1) {
        arg0.iiIiiiiiiiIii = arg1;
    }

    public iiIiiiiiIIiii(IIIiiiiiiiiIi iIIiiiiiiiiIi) {
        this.IiiiiiiiIIIII = iIIiiiiiiiiIi;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    static /* synthetic */ String ALLATORIxDEMO(iiIiiiiiIIiii arg0) {
        return arg0.iiIiiiiiiiIii;
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    static /* synthetic */ double ALLATORIxDEMO(iiIiiiiiIIiii arg0) {
        return arg0.ALLATORIxDEMO;
    }
}
