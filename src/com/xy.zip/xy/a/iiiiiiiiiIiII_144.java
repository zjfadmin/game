/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIIiiiiiIIII
 */
package com.xy.a;

import com.xy.a.IiIIiiiiiIIII;
import java.awt.Graphics;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiiiiiiiiIiII
extends JComponent {
    final /* synthetic */ IiIIiiiiiIIII ALLATORIxDEMO;

    iiiiiiiiiIiII(IiIIiiiiiIIII iiIIiiiiiIIII) {
        this.ALLATORIxDEMO = iiIIiiiiiIIII;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.ALLATORIxDEMO.ALLATORIxDEMO(g);
    }
}
