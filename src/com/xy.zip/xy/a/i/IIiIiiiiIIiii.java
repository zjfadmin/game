/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiiiiiiiiIIII
 */
package com.xy.a.i;

import com.xy.a.i.IiiiiiiiiIIII;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiIIiii
implements MouseListener {
    final /* synthetic */ IiiiiiiiiIIII ALLATORIxDEMO;

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (IiiiiiiiiIIII.ALLATORIxDEMO((IiiiiiiiiIIII)this.ALLATORIxDEMO) == 0) {
            return;
        }
        this.ALLATORIxDEMO.iIiIiiiiIIiii(0);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    IIiIiiiiIIiii(IiiiiiiiiIIII iiiiiiiiiIIII) {
        this.ALLATORIxDEMO = iiiiiiiiiIIII;
    }
}
