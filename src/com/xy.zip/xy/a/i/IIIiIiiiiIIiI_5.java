/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiIiIiiiiIiii
 *  com.xy.q.IIIiiiiiIiIiI
 */
package com.xy.a.i;

import com.xy.a.i.IiIiIiiiiIiii;
import com.xy.q.IIIiiiiiIiIiI;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIiIiiiiIIiI
extends IIIiiiiiIiIiI {
    final /* synthetic */ IiIiIiiiiIiii IiiiiiiiIIIII;
    private int ALLATORIxDEMO;

    public IIIiIiiiiIIiI(IiIiIiiiiIiii iiIiIiiiiIiii, int index) {
        this.IiiiiiiiIIIII = iiIiIiiiiIiii;
        super(iiIiIiiiiIiii.ALLATORIxDEMO());
        this.ALLATORIxDEMO("sc/b/S339.png");
        this.ALLATORIxDEMO = index;
    }

    public void mousePressed(MouseEvent e) {
        if (IiIiIiiiiIiii.ALLATORIxDEMO((IiIiIiiiiIiii)this.IiiiiiiiIIIII).getChoice() == null) return;
        IiIiIiiiiIiii.ALLATORIxDEMO((IiIiIiiiiIiii)this.IiiiiiiiIIIII, (int)this.ALLATORIxDEMO);
    }
}
