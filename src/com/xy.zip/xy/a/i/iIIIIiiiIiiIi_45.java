/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.entity.PartJade
 *  com.xy.formula.MsgUntil
 *  com.xy.q.iiIIiiiiIiiII
 */
package com.xy.a.i;

import com.xy.entity.PartJade;
import com.xy.formula.MsgUntil;
import com.xy.q.iiIIiiiiIiiII;
import java.awt.Color;
import javax.swing.tree.DefaultMutableTreeNode;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class iIIIIiiiIiiIi
extends DefaultMutableTreeNode {
    private PartJade IiiiiiiiIIIII;
    private Color ALLATORIxDEMO;

    public iIIIIiiiIiiIi(PartJade partJade) {
        this.ALLATORIxDEMO(partJade);
    }

    /*
     * WARNING - void declaration
     */
    public void ALLATORIxDEMO(PartJade partJade) {
        void partJade2;
        this.IiiiiiiiIIIII = partJade2;
        this.setUserObject(MsgUntil.ALLATORIxDEMO((String)String.valueOf(partJade2.getPartId())));
        this.ALLATORIxDEMO = partJade2.ALLATORIxDEMO() ? iiIIiiiiIiiII.iiIiIiiiiIIII : iiIIiiiiIiiII.iIIIiiiiIiiiI;
    }

    public Color ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }

    public PartJade ALLATORIxDEMO() {
        return this.IiiiiiiiIIIII;
    }
}
