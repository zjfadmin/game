/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiIIIiiiIIiII
 *  com.xy.w.IIIIIiiiIiiII
 */
package com.xy.a.i;

import com.xy.a.i.IiIIIiiiIIiII;
import com.xy.w.IIIIIiiiIiiII;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIiiiiIiIII
implements MouseListener {
    final /* synthetic */ IiIIIiiiIIiII ALLATORIxDEMO;

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    iIiIiiiiIiIII(IiIIIiiiIIiII iiIIIiiiIIiII) {
        this.ALLATORIxDEMO = iiIIIiiiIIiII;
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        IiIIIiiiIIiII.ALLATORIxDEMO((IiIIIiiiIIiII)this.ALLATORIxDEMO, (!IiIIIiiiIIiII.ALLATORIxDEMO((IiIIIiiiIIiII)this.ALLATORIxDEMO) ? 1 : 0) != 0);
        IiIIIiiiIIiII.ALLATORIxDEMO((IiIIIiiiIIiII)this.ALLATORIxDEMO).ALLATORIxDEMO(IIIIIiiiIiiII.iiiIiiiiiiIIi((String)(IiIIIiiiIIiII.ALLATORIxDEMO((IiIIIiiiIIiII)this.ALLATORIxDEMO) ? "sc/e/30.png" : "sc/e/29.png")));
        this.ALLATORIxDEMO.iIiIiiiiIIiii();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
