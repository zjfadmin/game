/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiIIIiiiIIiII
 *  com.xy.bean.SuitOperBean
 *  com.xy.entity.PartJade
 *  com.xy.formula.MsgUntil
 *  com.xy.game.RoleData
 *  com.xy.i.iiIiIiiiiIiii
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iIIiIiiiIiiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.q.iiIiIiiiiIiIi
 *  com.xy.readbean.MoneyType
 *  com.xy.socket.Agreement
 *  com.xy.text.GameView
 *  com.xy.v.iiIiiiiiIIiii
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 */
package com.xy.a.i;

import com.xy.a.i.IiIIIiiiIIiII;
import com.xy.bean.SuitOperBean;
import com.xy.entity.PartJade;
import com.xy.formula.MsgUntil;
import com.xy.game.RoleData;
import com.xy.i.iiIiIiiiiIiii;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iIIiIiiiIiiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.q.iiIiIiiiiIiIi;
import com.xy.readbean.MoneyType;
import com.xy.socket.Agreement;
import com.xy.text.GameView;
import com.xy.v.iiIiiiiiIIiii;
import com.xy.w.IIIIIiiiIiiII;
import com.xy.w.IIIiiiiiIiIiI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.math.BigDecimal;
import javax.swing.JLabel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class iiiiiiiiiiIiI
extends IiiiIiiiiIiIi {
    private IiIIIiiiIIiII IiIiiiiiIIIII;
    private iIIiIiiiIiiIi[] iiIiIiiiiIIIi;
    private JLabel[] iiiiIiiiIiiII;
    private com.xy.q.IIIiiiiiIiIiI iiiIiiiiiiiIi;
    private IIIiiiiiIiIiI iIiiIiiiiiiII;
    private IIIiiiiiIiIiI[] IIiiIiiiIIiIi;
    private MoneyType iIiIiiiiIiIii;
    private iIIiIiiiIiiIi IiIIIiiiiIiiI;
    private BigDecimal iiIiiiiiiiIii = new BigDecimal(this.ALLATORIxDEMO().ALLATORIxDEMO(2, 12) ? 500000 : 5000000);
    private iiIiIiiiiIiii IiiiiiiiIIIII;
    private iiIiIiiiiIiIi ALLATORIxDEMO;

    public void IiiIiiiiiiIiI() {
        this.iiiIiiiiiiiIi.ALLATORIxDEMO(0, null);
        this.iiiIiiiiiiIIi();
        this.ALLATORIxDEMO.iIiIiiiiIIiii();
        this.IiIiiiiiIIIII.iiiIiiiiiiIIi();
    }

    public com.xy.q.IIIiiiiiIiIiI ALLATORIxDEMO() {
        return this.iiiIiiiiiiiIi;
    }

    /*
     * WARNING - void declaration
     */
    public iiiiiiiiiiIiI(GameView gameView) {
        super(-1, -1, IiiiIiiiiIiIi.iIIiIiiiiiiIi, gameView);
        void gameView2;
        this.ALLATORIxDEMO(46, 74, 490, 428, IiiiIiiiiIiIi.iIIiIiiiiiiIi);
        this.iIiiIiiiiiiII = new IIIiiiiiIiIiI();
        this.iIiiIiiiiiiII.setBounds(10, 229, 17, 17);
        this.add((Component)this.iIiiIiiiiiiII);
        this.IiiiiiiiIIIII = new iiIiIiiiiIiii("sc/e/31.png", 1, 4, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IIiiiiiiIiiII, "\u5347 \u7ea7", (IiiiIiiiiIiIi)this);
        this.IiiiiiiiIIIII.setBounds(315, 358, 79, 25);
        this.add((Component)this.IiiiiiiiIIIII);
        this.IiIiiiiiIIIII = new IiIIIiiiIIiII((IiiiIiiiiIiIi)this, this.iIiiIiiiiiiII);
        this.IiIiiiiiIIIII.iIiIiiiiIIiii().setBounds(12, 30, 152, 195);
        this.add(this.IiIiiiiiIIIII.iIiIiiiiIIiii());
        this.IiIiiiiiIIIII.ALLATORIxDEMO().setBounds(174, 30, 305, 198);
        this.add(this.IiIiiiiiIIIII.ALLATORIxDEMO());
        this.iiiiIiiiIiiII = new JLabel[9];
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiiiIiiiIiiII.length) {
            this.iiiiIiiiIiiII[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)55, (int)83, (int)155, (int)21, (int)0, (Color)iiIIiiiiIiiII.ALLATORIxDEMO((String)"#cFFFFFF"), (Font)iiIIiiiiIiiII.iiiiIiiiIiiII);
            this.iiiiIiiiIiiII[IiiiiiiiIIIII].setText(IiiiiiiiIIIII == 0 ? "\u5957\u88c5\u5217\u8868" : (IiiiiiiiIIIII == 1 ? "\u9009\u62e9\u7389\u7b26" : (IiiiiiiiIIIII == 2 ? "\u53ea\u663e\u793a\u5df2\u6709\u7389\u7b26" : (IiiiiiiiIIIII == 3 ? "\u54c1\u8d28" : (IiiiiiiiIIIII == 4 ? "\u4e2a\u6570" : (IiiiiiiiIIIII == 5 ? "\u6d88\u8017\u91d1\u94b1" : (IiiiiiiiIIIII == 6 ? "\u62e5\u6709\u91d1\u94b1" : (IiiiiiiiIIIII == 7 ? "\u8fd8\u9700\u8981  \u4e2a\u7389\u7b26" : (IiiiiiiiIIIII == 8 ? "66" : "")))))))));
            if (IiiiiiiiIIIII == 1) {
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(218, 83, 307, 21);
            } else if (IiiiiiiiIIIII == 2) {
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setFont(iiIIiiiiIiiII.iIiIiiiiiiIIi);
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c000000"));
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setHorizontalAlignment(10);
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(74, 303, 136, 17);
            } else if (IiiiiiiiIIIII >= 3 && IiiiiiiiIIIII <= 4) {
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c000000"));
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(239, 352 + (IiiiiiiiIIIII - 3) * 26, 37, 19);
            } else if (IiiiiiiiIIIII >= 5 && IiiiiiiiIIIII <= 6) {
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c000000"));
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(160, 422 + (IiiiiiiiIIIII - 5) * 26, 72, 19);
            } else if (IiiiiiiiIIIII >= 7 && IiiiiiiiIIIII <= 8) {
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setFont(iiIIiiiiIiiII.iIIiiiiiiIIII);
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c000000"));
                this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(349, 380, 99, 15);
                if (IiiiiiiiIIIII == 8) {
                    this.iiiiIiiiIiiII[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#cFF0000"));
                }
            }
            this.iiiiIiiiIiiII[IiiiiiiiIIIII].setBounds(this.iiiiIiiiIiiII[IiiiiiiiIIIII].getX() - 46, this.iiiiIiiiIiiII[IiiiiiiiIIIII].getY() - 74, this.iiiiIiiiIiiII[IiiiiiiiIIIII].getWidth(), this.iiiiIiiiIiiII[IiiiiiiiIIIII].getHeight());
            this.add(this.iiiiIiiiIiiII[IiiiiiiiIIIII++]);
        }
        this.iiIiIiiiiIIIi = new iIIiIiiiIiiIi[2];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiIiIiiiiIIIi.length) {
            this.iiIiIiiiiIIIi[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)233, (int)(352 + 26 * IiiiiiiiIIIII - 74), (int)64, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii);
            this.iiIiIiiiiIIIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)3, (int)3, (int)3, (int)3, (boolean)false));
            this.add((Component)this.iiIiIiiiiIIIi[IiiiiiiiIIIII++]);
        }
        this.iIiIiiiiIiIii = new MoneyType();
        this.iIiIiiiiIiIii.setIdAndKey(1, "\u73b0 \u91d1");
        this.ALLATORIxDEMO = IiIIIiiiiIIiI.ALLATORIxDEMO((int)189, (int)374, (int)108, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii, (MoneyType)this.iIiIiiiiIiIii, (GameView)gameView2);
        this.ALLATORIxDEMO.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)3, (int)3, (int)3, (int)3, (boolean)false));
        this.ALLATORIxDEMO.ALLATORIxDEMO(2);
        this.IiIIIiiiiIiiI = IiIIIiiiiIIiI.ALLATORIxDEMO((int)189, (int)348, (int)108, (int)19, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii);
        this.IiIIIiiiiIiiI.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/17.png", (int)3, (int)3, (int)3, (int)3, (boolean)false));
        this.add((Component)this.IiIIIiiiiIiiI);
        this.add((Component)this.ALLATORIxDEMO);
        this.iiiIiiiiiiiIi = new com.xy.q.IIIiiiiiIiIiI((IiiiIiiiiIiIi)this);
        this.iiiIiiiiiiiIi.setBounds(125, 276, 50, 50);
        this.add((Component)this.iiiIiiiiiiiIi);
        this.IIiiIiiiIIiIi = new IIIiiiiiIiIiI[6];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIiiIiiiIIiIi.length) {
            this.IIiiIiiiIIiIi[IiiiiiiiIIIII] = new IIIiiiiiIiIiI();
            if (IiiiiiiiIIIII == 0) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/25.png", (int)2, (int)2, (int)2, (int)2, (boolean)false));
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(55, 83, 155, 21);
            } else if (IiiiiiiiIIIII == 1) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/24.png", (int)2, (int)2, (int)2, (int)2, (boolean)false));
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(55, 83, 155, 218);
            } else if (IiiiiiiiIIIII == 2) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/25.png", (int)2, (int)2, (int)2, (int)2, (boolean)false));
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(218, 83, 307, 21);
            } else if (IiiiiiiiIIIII == 3) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/24.png", (int)2, (int)2, (int)2, (int)2, (boolean)false));
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(218, 83, 307, 219);
            } else if (IiiiiiiiIIIII == 4) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].iIiIiiiiIIiii("sc/d/4.png");
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(167, 346, 59, 57);
            } else if (IiiiiiiiIIIII == 5) {
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/33.png", (int)30, (int)30, (int)30, (int)30, (boolean)false));
                this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(57, 327, 467, 158);
            }
            this.IIiiIiiiIIiIi[IiiiiiiiIIIII].setBounds(this.IIiiIiiiIIiIi[IiiiiiiiIIIII].getX() - 46, this.IIiiIiiiIIiIi[IiiiiiiiIIIII].getY() - 74, this.IIiiIiiiIIiIi[IiiiiiiiIIIII].getWidth(), this.IIiiIiiiIIiIi[IiiiiiiiIIIII].getHeight());
            this.add((Component)this.IIiiIiiiIIiIi[IiiiiiiiIIIII++]);
        }
        iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)this.IiIIIiiiiIiiI, (long)this.iiIiiiiiiiIii.longValue());
    }

    /*
     * WARNING - void declaration
     */
    public void iIiIiiiiIIiIi() {
        void IiiiiiiiIIIII;
        PartJade IiiiiiiiIIIII2 = (PartJade)this.iiiIiiiiiiiIi.ALLATORIxDEMO();
        if (IiiiiiiiIIIII2 == null) {
            this.iiIIiiiiIiIIi.iIiIiiiiIIiii("\u8bf7\u9009\u62e9\u4f60\u8981\u5347\u7ea7\u7684\u7389\u7b26..");
            return;
        }
        RoleData IiiiiiiiIIIII3 = this.ALLATORIxDEMO();
        int IiiiiiiiIIIII4 = (int)this.iiiIiiiiiiiIi.ALLATORIxDEMO();
        if (this.iiIiiiiiiiIii.compareTo(IiiiiiiiIIIII3.getLoginResult().getGold()) > 0) {
            this.iiIIiiiiIiIIi.iIiIiiiiIIiii("\u91d1\u5e01\u4e0d\u8db3..");
            return;
        }
        int IiiiiiiiIIIII5 = MsgUntil.iIiIiiiiIIiii((int)IiiiiiiiIIIII4);
        if (IiiiiiiiIIIII5 > IiiiiiiiIIIII2.getJade(IiiiiiiiIIIII4)) {
            this.iiIIiiiiIiIIi.iIiIiiiiIIiii("\u4f60\u6240\u9700\u7684\u7389\u7b26\u6570\u91cf\u4e0d\u8db3..");
            return;
        }
        SuitOperBean IiiiiiiiIIIII6 = new SuitOperBean();
        PartJade partJade = new PartJade(IiiiiiiiIIIII2.getSuitid(), IiiiiiiiIIIII2.getPartId());
        IiiiiiiiIIIII.setJade(IiiiiiiiIIIII4, IiiiiiiiIIIII5);
        IiiiiiiiIIIII6.setType(4);
        IiiiiiiiIIIII6.setJade((PartJade)IiiiiiiiIIIII);
        String IiiiiiiiIIIII7 = Agreement.getSendTextAES((String)"suitoperate", (String)iiIiiiiiIIiii.ALLATORIxDEMO().toJson(IiiiiiiiIIIII6));
        this.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII7);
        IiiiiiiiIIIII2.ALLATORIxDEMO(IiiiiiiiIIIII4, 1);
        IiiiiiiiIIIII3.getLoginResult().setGold(IiiiiiiiIIIII3.getLoginResult().getGold().subtract(this.iiIiiiiiiiIii));
        this.iiiIiiiiiiiIi.ALLATORIxDEMO(0, null);
        this.iiiIiiiiiiIIi();
        this.iiIIiiiiIiIIi.iIiIiiiiIIiii("\u6d88\u8017\u4e86" + IiiiiiiiIIIII5 + "\u4e2a" + MsgUntil.ALLATORIxDEMO((int)IiiiiiiiIIIII4) + "\u7389\u7b26..");
        this.iiIIiiiiIiIIi.iIiIiiiiIIiii("\u6d88\u8017\u4e86" + this.iiIiiiiiiiIii.longValue() / 10000L + "W\u91d1\u5e01..");
    }

    /*
     * Unable to fully structure code
     */
    public void iiiIiiiiiiIIi() {
        block1: {
            IiiiiiiiIIIII = (PartJade)this.iiiIiiiiiiiIi.ALLATORIxDEMO();
            if (IiiiiiiiIIIII != null) break block1;
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl15
        }
        IiiiiiiiIIIII = (int)this.iiiIiiiiiiiIi.ALLATORIxDEMO();
        IiiiiiiiIIIII = IiiiiiiiIIIII.getJade(IiiiiiiiIIIII);
        IiiiiiiiIIIII = MsgUntil.iIiIiiiiIIiii((int)IiiiiiiiIIIII);
        this.iiIiIiiiiIIIi[0].setText(MsgUntil.ALLATORIxDEMO((int)IiiiiiiiIIIII));
        this.iiIiIiiiiIIIi[1].setText(String.valueOf(IiiiiiiiIIIII));
        this.iiiiIiiiIiiII[8].setText(IiiiiiiiIIIII >= IiiiiiiiIIIII ? "0" : String.valueOf(IiiiiiiiIIIII - IiiiiiiiIIIII));
        return;
        do {
            this.iiIiIiiiiIIIi[IiiiiiiiIIIII++].setText(null);
lbl15:
            // 2 sources

        } while (IiiiiiiiIIIII < this.iiIiIiiiiIIIi.length);
        this.iiiiIiiiIiiII[8].setText("");
    }

    public IiIIIiiiIIiII ALLATORIxDEMO() {
        return this.IiIiiiiiIIIII;
    }
}
