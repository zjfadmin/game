/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiIiiiiiIIIiI
 *  com.xy.i.iIiIIiiiIiiiI
 *  com.xy.w.IIIIIiiiIiIii
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIiiIiiiiIIiI
 *  com.xy.w.iiIiIiiiiiIIi
 *  com.xy.w.iiiiiiiiiiIiI
 */
package com.xy.a.i;

import com.xy.a.i.IiIiiiiiIIIiI;
import com.xy.i.iIiIIiiiIiiiI;
import com.xy.w.IIIIIiiiIiIii;
import com.xy.w.IIIIIiiiIiiII;
import com.xy.w.IIiiIiiiiIIiI;
import com.xy.w.iiIiIiiiiiIIi;
import com.xy.w.iiiiiiiiiiIiI;
import java.awt.Image;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiiIiiiiIIII
extends iIiIIiiiIiiiI {
    private int IiiiiiiiIIIII;
    final /* synthetic */ IiIiiiiiIIIiI ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        if (this.IiiiiiiiIIIII != -1) return;
        this.ALLATORIxDEMO.ALLATORIxDEMO().iIiIiiiiIIiIi(138);
    }

    public void ALLATORIxDEMO(MouseEvent e, boolean isChoice) {
    }

    public IiiiIiiiiIIII(IiIiiiiiIIIiI iiIiiiiiIIIiI, int id) {
        this.ALLATORIxDEMO = iiIiiiiiIIIiI;
        super(null, 1, null, iiIiiiiiIIIiI.ALLATORIxDEMO());
        this.IiiiiiiiIIIII = id;
        if (id != -1) return;
        Image[] IiiiiiiiIIIII = new Image[3];
        IIIIIiiiIiIii IiiiiiiiIIIII2 = iiiiiiiiiiIiI.ALLATORIxDEMO((String)"sc/bang/XPBtnXP.tcp", null);
        if (IiiiiiiiIIIII2 != null) {
            IiiiiiiiIIIII[0] = iiiiiiiiiiIiI.ALLATORIxDEMO((IIiiIiiiiIIiI)IiiiiiiiIIIII2.ALLATORIxDEMO(), (iiIiIiiiiiIIi)IiiiiiiiIIIII2.ALLATORIxDEMO()[0], (IIIIIiiiIiIii)IiiiiiiiIIIII2);
            IiiiiiiiIIIII[1] = iiiiiiiiiiIiI.ALLATORIxDEMO((IIiiIiiiiIIiI)IiiiiiiiIIIII2.ALLATORIxDEMO(), (iiIiIiiiiiIIi)IiiiiiiiIIIII2.ALLATORIxDEMO()[2], (IIIIIiiiIiIii)IiiiiiiiIIIII2);
            IiiiiiiiIIIII[2] = iiiiiiiiiiIiI.ALLATORIxDEMO((IIiiIiiiiIIiI)IiiiiiiiIIIII2.ALLATORIxDEMO(), (iiIiIiiiiiIIi)IiiiiiiiIIIII2.ALLATORIxDEMO()[1], (IIIIIiiiIiIii)IiiiiiiiIIIII2);
        }
        if (IiiiiiiiIIIII[0] == null || IiiiiiiiIIIII[1] == null || IiiiiiiiIIIII[2] == null) {
            IiiiiiiiIIIII[1] = IiiiiiiiIIIII[2] = IIIIIiiiIiiII.ALLATORIxDEMO();
            IiiiiiiiIIIII[0] = IiiiiiiiIIIII[2];
        }
        this.ALLATORIxDEMO(IiiiiiiiIIIII);
    }
}
