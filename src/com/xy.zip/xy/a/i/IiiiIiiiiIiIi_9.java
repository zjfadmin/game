/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IIIiiiiiIiIiI
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.w.IIIIIiiiIiiII
 */
package com.xy.a.i;

import com.xy.a.i.IIIiiiiiIiIiI;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.w.IIIIIiiiIiiII;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.math.BigDecimal;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiiIiiiiIiIi
implements MouseListener {
    final /* synthetic */ IIIiiiiiIiIiI ALLATORIxDEMO;

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    IiiiIiiiiIiIi(IIIiiiiiIiIiI iIIiiiiiIiIiI) {
        this.ALLATORIxDEMO = iIIiiiiiIiIiI;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO, (!IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO) ? 1 : 0) != 0);
        IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO)[1].ALLATORIxDEMO(IIIIIiiiIiiII.iiiIiiiiiiIIi((String)(IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO) ? "sc/e/30.png" : "sc/e/29.png")));
        IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO, (BigDecimal)new BigDecimal(IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO) ? 100000 : 80000));
        iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO)[0], (long)IIIiiiiiIiIiI.ALLATORIxDEMO((IIIiiiiiIiIiI)this.ALLATORIxDEMO).longValue());
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }
}
