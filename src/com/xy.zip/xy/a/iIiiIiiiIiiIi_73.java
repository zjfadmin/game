/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIIIiiiIIIiI
 */
package com.xy.a;

import com.xy.a.IiIIIiiiIIIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiiIiiiIiiIi
extends JComponent {
    final /* synthetic */ IiIIIiiiIIIiI ALLATORIxDEMO;

    iIiiIiiiIiiIi(IiIIIiiiIIIiI iiIIIiiiIIIiI) {
        this.ALLATORIxDEMO = iiIIIiiiIIIiI;
    }
}
