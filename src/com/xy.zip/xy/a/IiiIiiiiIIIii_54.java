/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iIIIIiiiIiiIi
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a;

import com.xy.a.iIIIIiiiIiiIi;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiIiiiiIIIii
extends IIIiiiiiIiIiI {
    final /* synthetic */ iIIIIiiiIiiIi ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        iIIIIiiiIiiIi.ALLATORIxDEMO((iIIIIiiiIiiIi)this.ALLATORIxDEMO).mouseReleased(e);
    }

    IiiIiiiiIIIii(iIIIIiiiIiiIi iIIIIiiiIiiIi2, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIIIIiiiIiiIi2;
        super($anonymous0);
    }
}
