/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.IIIiIiiiiIIiI
 */
package com.xy.a.v;

import com.xy.a.v.IIIiIiiiiIIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIIiiiIIiIi
extends JComponent {
    final /* synthetic */ IIIiIiiiiIIiI ALLATORIxDEMO;

    iIiIIiiiIIiIi(IIIiIiiiiIIiI iIIiIiiiiIIiI) {
        this.ALLATORIxDEMO = iIIiIiiiiIIiI;
    }
}
