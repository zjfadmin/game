/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.IIIiIiiiiIIii
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.v;

import com.xy.a.v.IIIiIiiiiIIii;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiiiiiiIIIii
extends IIIiiiiiIiIiI {
    final /* synthetic */ IIIiIiiiiIIii ALLATORIxDEMO;

    IIiiiiiiIIIii(IIIiIiiiiIIii iIIiIiiiiIIii, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIIiIiiiiIIii;
        super($anonymous0);
    }

    public void ALLATORIxDEMO(MouseEvent e) {
        this.ALLATORIxDEMO.ALLATORIxDEMO(e);
    }
}
