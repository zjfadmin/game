/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.iiIIiiiiIiiII
 *  com.xy.i.iiIiIiiiIIIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iIiIIiiiIiiiI
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 */
package com.xy.a.v;

import com.xy.a.v.iiIIiiiiIiiII;
import com.xy.i.iiIiIiiiIIIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iIiIIiiiIiiiI;
import com.xy.w.IIIiiiiiIiIiI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIIIiiiIiIii
extends iIiIIiiiIiiiI {
    private JLabel IIiiIiiiIIiIi;
    private JLabel iIiIiiiiIiIii;
    private JLabel IiIIIiiiiIiiI;
    private IIIiiiiiIiIiI iiIiiiiiiiIii;
    private iiIiIiiiIIIiI IiiiiiiiIIIII;
    final /* synthetic */ iiIIiiiiIiiII ALLATORIxDEMO;

    /*
     * WARNING - void declaration
     */
    public void ALLATORIxDEMO(int n, int n2) {
        void money;
        void beau;
        this.IiiiiiiiIIIII.iIiIiiiiIIiii((int)beau);
        this.IiIIIiiiiIiiI.setText(String.valueOf((int)beau));
        this.IIiiIiiiIIiIi.setText(String.valueOf((int)money));
        this.setVisible(beau != false);
    }

    public IIIIIiiiIiIii(iiIIiiiiIiiII iiIIiiiiIiiII2, int index, iiIIiiiiIiiII beauBuy1View) {
        this.ALLATORIxDEMO = iiIIiiiiIiiII2;
        this.IiiiiiiiIIIII = new iiIiIiiiIIIiI("sc/e/189.png", 1, 180, (IiiiIiiiiIiIi)beauBuy1View);
        this.IiiiiiiiIIIII.setBounds(125, 19, 27, 27);
        this.IiIIIiiiiIiiI = IiIIIiiiiIIiI.ALLATORIxDEMO((int)11, (int)9, (int)120, (int)24, (Color)com.xy.q.iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c484333"), (Font)com.xy.q.iiIIiiiiIiiII.IIiiIiiiIiiii);
        this.iIiIiiiiIiIii = IiIIIiiiiIIiI.ALLATORIxDEMO((int)14, (int)38, (int)50, (int)16, (Color)com.xy.q.iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c6F6957"), (Font)com.xy.q.iiIIiiiiIiiII.iIiIIiiiiIIiI);
        this.IIiiIiiiIIiIi = IiIIIiiiiIIiI.ALLATORIxDEMO((int)54, (int)38, (int)70, (int)16, (Color)Color.red, (Font)com.xy.q.iiIIiiiiIiiII.ALLATORIxDEMO);
        this.iIiIiiiiIiIii.setText("积分：");
        this.IIiiIiiiIIiIi.setText("6");
        this.iiIiiiiiiiIii = new IIIiiiiiIiIiI("sc/d/198.png");
        this.iiIiiiiiiiIii.setBounds(0, 0, 156, 66);
        this.add((Component)this.IiiiiiiiIIIII);
        this.add(this.IiIIIiiiiIiiI);
        this.add(this.iIiIiiiiIiIii);
        this.add(this.IIiiIiiiIIiIi);
        this.add((Component)this.iiIiiiiiiiIii);
    }
}
