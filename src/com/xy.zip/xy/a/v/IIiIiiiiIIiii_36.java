/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.iiIiIiiiiiIIi
 *  com.xy.i.iiIiIiiiIIIiI
 *  com.xy.q.IIIiIiiiiIiII
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.iIiIIiiiIiiiI
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.q.iiiIIiiiIIIii
 *  com.xy.readbean.Activity
 *  com.xy.scene.BWDHRuleBattle
 *  com.xy.scene.BWDHTeam
 *  com.xy.socket.Agreement
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 */
package com.xy.a.v;

import com.xy.a.v.iiIiIiiiiiIIi;
import com.xy.i.iiIiIiiiIIIiI;
import com.xy.q.IIIiIiiiiIiII;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.iIiIIiiiIiiiI;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.q.iiiIIiiiIIIii;
import com.xy.readbean.Activity;
import com.xy.scene.BWDHRuleBattle;
import com.xy.scene.BWDHTeam;
import com.xy.socket.Agreement;
import com.xy.w.IIIIIiiiIiiII;
import com.xy.w.IIIiiiiiIiIiI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiIIiii
extends iIiIIiiiIiiiI {
    private JLabel iIiiIiiiiiiII;
    final /* synthetic */ iiIiIiiiiiIIi IIiiIiiiIIiIi;
    private JLabel[] iIiIiiiiIiIii;
    private iiIiIiiiIIIiI[] IiIIIiiiiIiiI;
    private IIIiiiiiIiIiI[] iiIiiiiiiiIii;
    private IIIiiiiiIiIiI[] IiiiiiiiIIIII;
    private IIIiIiiiiIiII ALLATORIxDEMO;

    public IIiIiiiiIIiii(iiIiIiiiiiIIi iiIiIiiiiiIIi2) {
        this.IIiiIiiiIIiIi = iiIiIiiiiiIIi2;
        this.setBounds(0, 0, 718, 526);
        this.ALLATORIxDEMO = new IIIiIiiiiIiII(2, 100, iiIiIiiiiiIIi2.ALLATORIxDEMO());
        this.ALLATORIxDEMO.iIiIiiiiIIiii(true);
        this.ALLATORIxDEMO.ALLATORIxDEMO(563, 71, 87, 19);
        this.ALLATORIxDEMO.iiiIiiiiiiIIi(new iiiIIiiiIIIii("A组", (Object)0));
        this.ALLATORIxDEMO.iiiIiiiiiiIIi(new iiiIIiiiIIIii("B组", (Object)1));
        this.ALLATORIxDEMO.iiiIiiiiiiIIi(new iiiIIiiiIIIii("C组", (Object)2));
        this.ALLATORIxDEMO.iiiIiiiiiiIIi(new iiiIIiiiIIIii("D组", (Object)3));
        this.ALLATORIxDEMO.ALLATORIxDEMO().setText("A组");
        this.add((Component)this.ALLATORIxDEMO);
        this.iIiiIiiiiiiII = IiIIIiiiiIIiI.ALLATORIxDEMO((int)139, (int)112, (int)420, (int)24, (Color)iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c7D6120"), (Font)iiIIiiiiIiiII.iiiIIiiiIiiII);
        this.iIiiIiiiiiiII.setHorizontalAlignment(0);
        this.iIiiIiiiiiiII.setText("入围赛赛程图  A组");
        this.add(this.iIiiIiiiiiiII);
        this.IiIIIiiiiIiiI = new iiIiIiiiIIIiI[15];
        this.iIiIiiiiIiIii = new JLabel[14];
        this.iiIiiiiiiiIii = new IIIiiiiiIiIiI[7];
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIIiiiiIiiI.length) {
            this.IiIIIiiiiIiiI[IiiiiiiiIIIII] = new iiIiIiiiIIIiI("sc/e/163.png", 2, 146, iiIIiiiiIiiII.iIiIiiiiiiIIi, iiIIiiiiIiiII.IIiiiiiiIiiII, "", iiIiIiiiiiIIi2.ALLATORIxDEMO());
            if (IiiiiiiiIIIII == 0) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(61, 379, 119, 27);
            } else if (IiiiiiiiIIIII == 1) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(61, 412, 119, 27);
            } else if (IiiiiiiiIIIII == 2) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(217, 379, 119, 27);
            } else if (IiiiiiiiIIIII == 3) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(217, 412, 119, 27);
            } else if (IiiiiiiiIIIII == 4) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(360, 379, 119, 27);
            } else if (IiiiiiiiIIIII == 5) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(360, 412, 119, 27);
            } else if (IiiiiiiiIIIII == 6) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(516, 379, 119, 27);
            } else if (IiiiiiiiIIIII == 7) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(516, 412, 119, 27);
            } else if (IiiiiiiiIIIII == 8) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(61, 315, 119, 27);
            } else if (IiiiiiiiIIIII == 9) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(217, 315, 119, 27);
            } else if (IiiiiiiiIIIII == 10) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(360, 315, 119, 27);
            } else if (IiiiiiiiIIIII == 11) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(516, 315, 119, 27);
            } else if (IiiiiiiiIIIII == 12) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(140, 242, 119, 27);
            } else if (IiiiiiiiIIIII == 13) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(438, 242, 119, 27);
            } else if (IiiiiiiiIIIII == 14) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(290, 169, 119, 27);
            }
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiIiiiiiiiIii.length) {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII] = new IIIiiiiiIiIiI("sc/d/144.png");
            this.add((Component)this.iiIiiiiiiiIii[IiiiiiiiIIIII++]);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIIiiiiIiiI.length) {
            if (IiiiiiiiIIIII < this.iIiIiiiiIiIii.length) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)(this.IiIIIiiiiIiiI[IiiiiiiiIIIII].getX() + 9), (int)(this.IiIIIiiiiIiiI[IiiiiiiiIIIII].getY() + 4), (int)100, (int)16, (int)4, (Color)Color.black, (Font)iiIIiiiiIiiII.iIiIIiiiiIIiI);
                this.add(this.iIiIiiiiIiIii[IiiiiiiiIIIII]);
            }
            this.add((Component)this.IiIIIiiiiIiiI[IiiiiiiiIIIII++]);
        }
        this.IiiiiiiiIIIII = new IIIiiiiiIiIiI[48];
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiiiiiiiIIIII.length) {
            this.IiiiiiiiIIIII[IiiiiiiiIIIII] = new IIIiiiiiIiIiI();
            if (IiiiiiiiIIIII == 0) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/103.png", (int)100, (int)5, (int)100, (int)5, (boolean)false));
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(146, 119, 406, 11);
            } else if (IiiiiiiiIIIII >= 1 && IiiiiiiiIIIII <= 40) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].iIiIiiiiIIiii("sc/d/187.png");
                if (IiiiiiiiIIIII == 1) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(179, 391, 9, 2);
                } else if (IiiiiiiiIIIII == 2) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(186, 391, 2, 36);
                } else if (IiiiiiiiIIIII == 3) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(179, 425, 9, 2);
                } else if (IiiiiiiiIIIII == 4) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(187, 408, 8, 2);
                } else if (IiiiiiiiIIIII == 5) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(195, 364, 2, 46);
                } else if (IiiiiiiiIIIII == 6) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(200, 364, 2, 46);
                } else if (IiiiiiiiIIIII == 7) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(202, 408, 8, 2);
                } else if (IiiiiiiiIIIII == 8) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(209, 391, 9, 2);
                } else if (IiiiiiiiIIIII == 9) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(209, 391, 2, 36);
                } else if (IiiiiiiiIIIII == 10) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(209, 425, 9, 2);
                } else if (IiiiiiiiIIIII == 11) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(478, 391, 9, 2);
                } else if (IiiiiiiiIIIII == 12) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(478, 425, 9, 2);
                } else if (IiiiiiiiIIIII == 13) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(485, 391, 2, 36);
                } else if (IiiiiiiiIIIII == 14) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(486, 408, 8, 2);
                } else if (IiiiiiiiIIIII == 15) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(494, 364, 2, 46);
                } else if (IiiiiiiiIIIII == 16) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(499, 364, 2, 46);
                } else if (IiiiiiiiIIIII == 17) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(501, 408, 8, 2);
                } else if (IiiiiiiiIIIII == 18) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(508, 391, 9, 2);
                } else if (IiiiiiiiIIIII == 19) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(508, 425, 9, 2);
                } else if (IiiiiiiiIIIII == 20) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(508, 391, 2, 36);
                } else if (IiiiiiiiIIIII == 21) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(121, 362, 76, 2);
                } else if (IiiiiiiiIIIII == 22) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(200, 362, 76, 2);
                } else if (IiiiiiiiIIIII == 23) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(420, 362, 76, 2);
                } else if (IiiiiiiiIIIII == 24) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(499, 362, 76, 2);
                } else if (IiiiiiiiIIIII == 25) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(120, 338, 2, 26);
                } else if (IiiiiiiiIIIII == 26) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(275, 338, 2, 26);
                } else if (IiiiiiiiIIIII == 27) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(419, 338, 2, 26);
                } else if (IiiiiiiiIIIII == 28) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(574, 338, 2, 26);
                } else if (IiiiiiiiIIIII == 29) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(120, 291, 2, 26);
                } else if (IiiiiiiiIIIII == 30) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(275, 291, 2, 26);
                } else if (IiiiiiiiIIIII == 31) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(419, 291, 2, 26);
                } else if (IiiiiiiiIIIII == 32) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(574, 291, 2, 26);
                } else if (IiiiiiiiIIIII == 33) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(121, 291, 155, 2);
                } else if (IiiiiiiiIIIII == 34) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(420, 291, 155, 2);
                } else if (IiiiiiiiIIIII == 35) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(198, 265, 2, 26);
                } else if (IiiiiiiiIIIII == 36) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(497, 264, 2, 26);
                } else if (IiiiiiiiIIIII == 37) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(198, 218, 2, 26);
                } else if (IiiiiiiiIIIII == 38) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(497, 218, 2, 26);
                } else if (IiiiiiiiIIIII == 39) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(199, 218, 298, 2);
                } else if (IiiiiiiiIIIII == 40) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(347, 192, 2, 26);
                }
            } else if (IiiiiiiiIIIII >= 41 && IiiiiiiiIIIII <= 47) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].iIiIiiiiIIiii("sc/d/188.png");
                if (IiiiiiiiIIIII == 41) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(52, 369, 136, 80);
                } else if (IiiiiiiiIIIII == 42) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(209, 369, 136, 80);
                } else if (IiiiiiiiIIIII == 43) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(351, 369, 136, 80);
                } else if (IiiiiiiiIIIII == 44) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(508, 369, 136, 80);
                } else if (IiiiiiiiIIIII == 45) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(54, 306, 590, 45);
                } else if (IiiiiiiiIIIII == 46) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(54, 233, 590, 45);
                } else if (IiiiiiiiIIIII == 47) {
                    this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(240, 160, 218, 45);
                }
            }
            this.add((Component)this.IiiiiiiiIIIII[IiiiiiiiIIIII++]);
        }
    }

    public void ALLATORIxDEMO(int id, Object data) {
        if (id != 146) return;
        int IiiiiiiiIIIII = (Integer)data;
        if (IiiiiiiiIIIII <= 0) {
            return;
        }
        Activity IiiiiiiiIIIII2 = iiIiIiiiiiIIi.ALLATORIxDEMO((iiIiIiiiiiIIi)this.IIiiIiiiIIiIi).ALLATORIxDEMO();
        String IiiiiiiiIIIII3 = Agreement.getSendTextAES((String)"activity", (String)(String.valueOf(IiiiiiiiIIIII2.getId()) + "|t" + IiiiiiiiIIIII));
        this.IIiiIiiiIIiIi.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII3);
    }

    static /* synthetic */ IIIiIiiiiIiII ALLATORIxDEMO(IIiIiiiiIIiii arg0) {
        return arg0.ALLATORIxDEMO;
    }

    public void ALLATORIxDEMO(BWDHRuleBattle[] ruleBattles) {
        int IiiiiiiiIIIII;
        int n = ruleBattles.length == 7 ? 3 : (ruleBattles.length == 6 ? 2 : (IiiiiiiiIIIII = ruleBattles.length == 4 ? 1 : 0));
        int IiiiiiiiIIIII2 = IiiiiiiiIIIII == 3 ? 7 : (IiiiiiiiIIIII == 2 ? 6 : (IiiiiiiiIIIII == 1 ? 4 : 0));
        while (IiiiiiiiIIIII2 < 8) {
            if (IiiiiiiiIIIII2 == 7) {
                this.IiIIIiiiiIiiI[14].setName(String.valueOf(0));
                this.IiIIIiiiiIiiI[14].setText(null);
            } else {
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setKeep(false);
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setKeep(false);
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setName(String.valueOf(0));
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setName(String.valueOf(0));
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setText(null);
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setText(null);
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2].setText(null);
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2 + 1].setText(null);
                this.iiIiiiiiiiIii[IiiiiiiiIIIII2].setVisible(false);
            }
            ++IiiiiiiiIIIII2;
        }
        IiiiiiiiIIIII2 = 0;
        while (IiiiiiiiIIIII2 < ruleBattles.length) {
            BWDHRuleBattle IiiiiiiiIIIII3 = ruleBattles[IiiiiiiiIIIII2];
            this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setName(String.valueOf(IiiiiiiiIIIII3.getBwdhTeam1().getId()));
            this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setText(IiiiiiiiIIIII3.getBwdhTeam1().getName());
            this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setName(String.valueOf(IiiiiiiiIIIII3.getBwdhTeam2().getId()));
            this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setText(IiiiiiiiIIIII3.getBwdhTeam2().getName());
            if (IiiiiiiiIIIII3.getWin() == 0 && IiiiiiiiIIIII3.getPoint().x == 0 && IiiiiiiiIIIII3.getPoint().x == 0) {
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2].setText(null);
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2 + 1].setText(null);
                this.iiIiiiiiiiIii[IiiiiiiiIIIII2].setVisible(false);
            } else {
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2].setText(String.valueOf(IiiiiiiiIIIII3.getPoint().x));
                this.iIiIiiiiIiIii[2 * IiiiiiiiIIIII2 + 1].setText(String.valueOf(IiiiiiiiIIIII3.getPoint().y));
                if (IiiiiiiiIIIII3.getWin() == 1 && IiiiiiiiIIIII3.getBwdhTeam1().getId() != 0) {
                    this.iiIiiiiiiiIii[IiiiiiiiIIIII2].setBounds(this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].getX() + 99, this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].getY() - 15, 27, 24);
                } else if (IiiiiiiiIIIII3.getWin() == 2 && IiiiiiiiIIIII3.getBwdhTeam1().getId() != 0) {
                    this.iiIiiiiiiiIii[IiiiiiiiIIIII2].setBounds(this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].getX() + 99, this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].getY() - 15, 27, 24);
                }
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2].setKeep(IiiiiiiiIIIII3.getWin() == 1);
                this.IiIIIiiiiIiiI[2 * IiiiiiiiIIIII2 + 1].setKeep(IiiiiiiiIIIII3.getWin() == 2);
                this.iiIiiiiiiiIii[IiiiiiiiIIIII2].setVisible(IiiiiiiiIIIII3.getWin() != 0);
                if (IiiiiiiiIIIII3.getWin() != 0) {
                    BWDHTeam IiiiiiiiIIIII4;
                    int IiiiiiiiIIIII5 = 0;
                    if (IiiiiiiiIIIII2 == 0) {
                        IiiiiiiiIIIII5 = 8;
                    } else if (IiiiiiiiIIIII2 == 1) {
                        IiiiiiiiIIIII5 = 9;
                    } else if (IiiiiiiiIIIII2 == 2) {
                        IiiiiiiiIIIII5 = 10;
                    } else if (IiiiiiiiIIIII2 == 3) {
                        IiiiiiiiIIIII5 = 11;
                    } else if (IiiiiiiiIIIII2 == 4) {
                        IiiiiiiiIIIII5 = 12;
                    } else if (IiiiiiiiIIIII2 == 5) {
                        IiiiiiiiIIIII5 = 13;
                    } else if (IiiiiiiiIIIII2 == 6) {
                        IiiiiiiiIIIII5 = 14;
                    }
                    BWDHTeam bWDHTeam = IiiiiiiiIIIII4 = IiiiiiiiIIIII3.getWin() == 1 ? IiiiiiiiIIIII3.getBwdhTeam1() : IiiiiiiiIIIII3.getBwdhTeam2();
                    if (IiiiiiiiIIIII5 > 0) {
                        this.IiIIIiiiiIiiI[IiiiiiiiIIIII5].setName(String.valueOf(IiiiiiiiIIIII4.getId()));
                        this.IiIIIiiiiIiiI[IiiiiiiiIIIII5].setText(IiiiiiiiIIIII4.getName());
                    }
                }
            }
            ++IiiiiiiiIIIII2;
        }
    }
}
