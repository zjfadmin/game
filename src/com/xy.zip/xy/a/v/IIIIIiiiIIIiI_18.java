/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.iiIiIiiiIIIiI
 */
package com.xy.a.v;

import com.xy.a.v.iiIiIiiiIIIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIIIiiiIIIiI
extends JComponent {
    final /* synthetic */ iiIiIiiiIIIiI ALLATORIxDEMO;

    IIIIIiiiIIIiI(iiIiIiiiIIIiI iiIiIiiiIIIiI2) {
        this.ALLATORIxDEMO = iiIiIiiiIIIiI2;
    }
}
