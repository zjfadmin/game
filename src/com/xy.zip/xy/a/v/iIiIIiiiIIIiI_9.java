/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.IIIiIiiiiIIiI
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.v.IIiiIiiiiIIiI
 */
package com.xy.a.v;

import com.xy.a.v.IIIiIiiiiIIiI;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.v.IIiiIiiiiIIiI;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIIiiiIIIiI
extends IIIiiiiiIiIiI {
    private JLabel IiiiiiiiIIIII;
    final /* synthetic */ IIIiIiiiiIIiI ALLATORIxDEMO;

    public void iiiIiiiiiiIIi(String text) {
        if (IIiiIiiiiIIiI.ALLATORIxDEMO((String)this.IiiiiiiiIIIII.getText(), (String)text)) {
            return;
        }
        this.IiiiiiiiIIIII.setText(text);
    }

    public iIiIIiiiIIIiI(IIIiIiiiiIIiI iIIiIiiiiIIiI, IiiiIiiiiIiIi form) {
        this.ALLATORIxDEMO = iIIiIiiiiIIiI;
        super(form);
        this.IiiiiiiiIIIII = IiIIIiiiiIIiI.ALLATORIxDEMO((int)4, (int)4, (int)42, (int)14, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIiiiiiiIIII);
        this.add(this.IiiiiiiiIIIII);
    }
}
