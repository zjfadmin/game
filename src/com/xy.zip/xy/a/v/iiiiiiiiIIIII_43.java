/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.IiiiIiiiiIIII
 */
package com.xy.a.v;

import com.xy.a.v.IiiiIiiiiIIII;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiiiiiiiIIIII
extends JComponent {
    final /* synthetic */ IiiiIiiiiIIII ALLATORIxDEMO;

    iiiiiiiiIIIII(IiiiIiiiiIIII iiiiIiiiiIIII) {
        this.ALLATORIxDEMO = iiiiIiiiiIIII;
    }
}
