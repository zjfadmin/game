/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.v.iIiIiiiiIiIII
 */
package com.xy.a.v;

import com.xy.a.v.iIiIiiiiIiIII;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIiIiiiIiIII
extends JComponent {
    final /* synthetic */ iIiIiiiiIiIII ALLATORIxDEMO;

    IIIiIiiiIiIII(iIiIiiiiIiIII iIiIiiiiIiIII2) {
        this.ALLATORIxDEMO = iIiIiiiiIiIII2;
    }
}
