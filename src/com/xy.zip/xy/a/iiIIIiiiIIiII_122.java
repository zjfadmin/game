/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIiiiiiIIiIi
 */
package com.xy.a;

import com.xy.a.iiIiiiiiIIiIi;
import javax.swing.JTable;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiIIIiiiIIiII
extends JTable {
    final /* synthetic */ iiIiiiiiIIiIi ALLATORIxDEMO;

    iiIIIiiiIIiII(iiIiiiiiIIiIi iiIiiiiiIIiIi2) {
        this.ALLATORIxDEMO = iiIiiiiiIIiIi2;
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
}
