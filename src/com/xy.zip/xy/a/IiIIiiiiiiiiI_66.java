/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.i.IiIIIiiiiiiIi
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.text.GameView
 */
package com.xy.a;

import com.xy.i.IiIIIiiiiiiIi;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.text.GameView;
import java.awt.Component;

public class IiIIiiiiiiiiI
extends IiiiIiiiiIiIi {
    private IiIIIiiiiiiIi[] iIiIiiiiIiIii;
    private IiIIIiiiiiiIi[] IiIIIiiiiIiiI;
    private IiIIIiiiiiiIi[] iiIiiiiiiiIii;
    private IiIIIiiiiiiIi[] IiiiiiiiIIIII;
    private IiIIIiiiiiiIi[] ALLATORIxDEMO;

    public IiIIiiiiiiiiI(GameView gameView) {
        super(150, 2, IiiiIiiiiIiIi.iIIIIiiiiiIIi, gameView);
        this.ALLATORIxDEMO(-1, 0, 798, 386, IiiiIiiiiIiIi.iIIiIiiiiiiIi);
        this.iIiIiiiiIIiii("sc/b/S419.png");
        this.IiiiiiiiIIIII = new IiIIIiiiiiiIi[this.ALLATORIxDEMO().ALLATORIxDEMO(2, 12) ? 7 : 6];
        this.iIiIiiiiIiIii = new IiIIIiiiiiiIi[6];
        this.ALLATORIxDEMO = new IiIIIiiiiiiIi[7];
        this.IiIIIiiiiIiiI = new IiIIIiiiiiiIi[7];
        this.iiIiiiiiiiIii = new IiIIIiiiiiiIi[this.ALLATORIxDEMO().ALLATORIxDEMO(2, 12) ? 7 : 6];
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiiiiiiiIIIII.length) {
            this.IiiiiiiiIIIII[IiiiiiiiIIIII] = new IiIIIiiiiiiIi("sc/b/B463.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IiiIIiiiIIIIi, "", (IiiiIiiiiIiIi)this);
            this.IiiiiiiiIIIII[IiiiiiiiIIIII].setBounds(140, 58 + IiiiiiiiIIIII * 35, 100, 30);
            this.add((Component)this.IiiiiiiiIIIII[IiiiiiiiIIIII]);
            if (IiiiiiiiIIIII == 0) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(16, "\u8d85\u7ea7\u5deb\u533b");
            } else if (IiiiiiiiIIIII == 1) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(40, "\u6c5f\u6e56\u767e\u6653\u751f");
            } else if (IiiiiiiiIIIII == 2) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(-44, "\u53ec\u5524\u517d");
            } else if (IiiiiiiiIIIII == 3) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(59988, "\u6d3b\u8dc3");
            } else if (IiiiiiiiIIIII == 4) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(59992, "\u4f19\u4f34");
            } else if (IiiiiiiiIIIII == 5) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(59991, "\u526f\u672c");
            } else if (IiiiiiiiIIIII == 6) {
                this.IiiiiiiiIIIII[IiiiiiiiIIIII].ALLATORIxDEMO(59987, "\u6539\u540d");
            }
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIiIiiiiIiIii.length) {
            IiIIiiiiiiiiI iiIIiiiiiiiiI = this;
            IiIIiiiiiiiiI iiIIiiiiiiiiI2 = this;
            iiIIiiiiiiiiI2.iIiIiiiiIiIii[IiiiiiiiIIIII] = new IiIIIiiiiiiIi("sc/b/B463.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IiiIIiiiIIIIi, "", (IiiiIiiiiIiIi)this);
            iiIIiiiiiiiiI.iIiIiiiiIiIii[IiiiiiiiIIIII].setBounds(255, 58 + IiiiiiiiIIIII * 35, 100, 30);
            iiIIiiiiiiiiI.add((Component)iiIIiiiiiiiiI2.iIiIiiiiIiIii[IiiiiiiiIIIII]);
            if (IiiiiiiiIIIII == 0) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(-71, "\u91d1\u5e01\u56de\u6536");
            } else if (IiiiiiiiIIIII == 1) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(59989, "\u4ed9\u7389\u5bc4\u552e");
            } else if (IiiiiiiiIIIII == 2) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(59996, "\u5151\u6362");
            } else if (IiiiiiiiIIIII == 3) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(33, "\u94b1\u5e84");
            } else if (IiiiiiiiIIIII == 4) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(31, "\u5f53\u94fa");
            } else if (IiiiiiiiIIIII == 5) {
                this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(-47, "\u8f6c\u751f");
            }
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.ALLATORIxDEMO.length) {
            IiIIiiiiiiiiI iiIIiiiiiiiiI = this;
            IiIIiiiiiiiiI iiIIiiiiiiiiI3 = this;
            iiIIiiiiiiiiI3.ALLATORIxDEMO[IiiiiiiiIIIII] = new IiIIIiiiiiiIi("sc/b/B463.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IiiIIiiiIIIIi, "", (IiiiIiiiiIiIi)this);
            iiIIiiiiiiiiI.ALLATORIxDEMO[IiiiiiiiIIIII].setBounds(370, 58 + IiiiiiiiIIIII * 35, 100, 30);
            iiIIiiiiiiiiI.add((Component)iiIIiiiiiiiiI3.ALLATORIxDEMO[IiiiiiiiIIIII]);
            if (IiiiiiiiIIIII == 0) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(54, "\u88c5\u5907\u6253\u9020");
            } else if (IiiiiiiiIIIII == 1) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(66, "\u4ed9\u5668");
            } else if (IiiiiiiiIIIII == 2) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(59990, "\u795e\u5175");
            } else if (IiiiiiiiIIIII == 3) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(59995, "\u5b9d\u77f3");
            } else if (IiiiiiiiIIIII == 4) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(59994, "\u7b26\u77f3");
            } else if (IiiiiiiiIIIII == 5) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(59993, "\u70bc\u5996\u77f3");
            } else if (IiiiiiiiIIIII == 6) {
                this.ALLATORIxDEMO[IiiiiiiiIIIII].ALLATORIxDEMO(59999, "\u70bc\u5316\u8f85\u52a9");
            }
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIIiiiiIiiI.length) {
            IiIIiiiiiiiiI iiIIiiiiiiiiI = this;
            IiIIiiiiiiiiI iiIIiiiiiiiiI4 = this;
            iiIIiiiiiiiiI4.IiIIIiiiiIiiI[IiiiiiiiIIIII] = new IiIIIiiiiiiIi("sc/b/B463.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IiiIIiiiIIIIi, "", (IiiiIiiiiIiIi)this);
            iiIIiiiiiiiiI.IiIIIiiiiIiiI[IiiiiiiiIIIII].setBounds(505, 58 + IiiiiiiiIIIII * 35, 100, 30);
            iiIIiiiiiiiiI.add((Component)iiIIiiiiiiiiI4.IiIIIiiiiIiiI[IiiiiiiiIIIII]);
            if (IiiiiiiiIIIII == 0) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(5, "\u6742\u8d27\u5e97");
            } else if (IiiiiiiiIIIII == 1) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(9, "\u836f\u5e97");
            } else if (IiiiiiiiIIIII == 2) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(14, "\u6280\u80fd\u5546\u5e97");
            } else if (IiiiiiiiIIIII == 3) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(15, "\u5185\u4e39\u5546\u5e97");
            } else if (IiiiiiiiIIIII == 4) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(37, "\u7b26\u6587\u5546\u5e97");
            } else if (IiiiiiiiIIIII == 5) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(13, "\u77ff\u77f3\u5546\u5e97");
            } else if (IiiiiiiiIIIII == 6) {
                this.IiIIIiiiiIiiI[IiiiiiiiIIIII].ALLATORIxDEMO(7, "\u4f5c\u574a\u5546\u5e97");
            }
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiIiiiiiiiIii.length) {
            IiIIiiiiiiiiI iiIIiiiiiiiiI = this;
            IiIIiiiiiiiiI iiIIiiiiiiiiI5 = this;
            iiIIiiiiiiiiI5.iiIiiiiiiiIii[IiiiiiiiIIIII] = new IiIIIiiiiiiIi("sc/b/B463.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IiiIIiiiIIIIi, "", (IiiiIiiiiIiIi)this);
            iiIIiiiiiiiiI.iiIiiiiiiiIii[IiiiiiiiIIIII].setBounds(620, 58 + IiiiiiiiIIIII * 35, 100, 30);
            iiIIiiiiiiiiI.add((Component)iiIIiiiiiiiiI5.iiIiiiiiiiIii[IiiiiiiiIIIII]);
            if (IiiiiiiiIIIII == 0) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(605, "\u5927\u95f9\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 1) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(126, "\u6c34\u8def\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 2) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(121, "\u5730\u5bab\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 3) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(120, "\u5927\u96c1\u5854\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 4) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(61, "\u5e2e\u6218\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 5) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(123, "\u5bfb\u8bbf\u79ef\u5206");
            } else if (IiiiiiiiIIIII == 6) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].ALLATORIxDEMO(127, "\u526f\u672c\u79ef\u5206");
            }
            ++IiiiiiiiIIIII;
        }
        if (!this.ALLATORIxDEMO().ALLATORIxDEMO(2, 11)) return;
        this.ALLATORIxDEMO[6].setVisible(false);
        IiiiiiiiIIIII = 2;
        while (IiiiiiiiIIIII < this.iIiIiiiiIiIii.length) {
            IiIIIiiiiiiIi iiIIIiiiiiiIi = this.iIiIiiiiIiIii[IiiiiiiiIIIII];
            int n = 58 + (IiiiiiiiIIIII - 1) * 35;
            ++IiiiiiiiIIIII;
            iiIIIiiiiiiIi.setBounds(255, n, 100, 30);
        }
        this.iIiIiiiiIiIii[1].ALLATORIxDEMO(39, "\u53cc\u500d");
        this.iIiIiiiiIiIii[1].setBounds(255, 58 + (this.iIiIiiiiIiIii.length - 1) * 35, 100, 30);
    }
}
