/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.a.IIiIiiiiiiiII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.a;

import com.xy.a.a.IIiIiiiiiiiII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIiIiiiiIiii
extends IIIiiiiiIiIiI {
    final /* synthetic */ IIiIiiiiiiiII ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        this.ALLATORIxDEMO.ALLATORIxDEMO(e);
    }

    IiIiIiiiiIiii(IIiIiiiiiiiII iIiIiiiiiiiII, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIiIiiiiiiiII;
        super($anonymous0);
    }
}
