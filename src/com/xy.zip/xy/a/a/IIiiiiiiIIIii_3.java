/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.a.IiiIiiiiIiIIi
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.a;

import com.xy.a.a.IiiIiiiiIiIIi;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiiiiiiIIIii
extends IIIiiiiiIiIiI {
    final /* synthetic */ IiiIiiiiIiIIi ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        this.ALLATORIxDEMO.iiiIiiiiiiIIi(e);
    }

    public void mouseExited(MouseEvent e) {
        this.ALLATORIxDEMO(Boolean.FALSE);
        this.IiIIIiiiiiiiI = Boolean.FALSE;
        this.iIIIIiiiiiIIi.ALLATORIxDEMO().iiiIiiiiiiIIi(46);
    }

    IIiiiiiiIIIii(IiiIiiiiIiIIi iiiIiiiiIiIIi, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iiiIiiiiIiIIi;
        super($anonymous0);
    }

    public void mouseEntered(MouseEvent e) {
        this.IiIIIiiiiiiiI = Boolean.TRUE;
        this.ALLATORIxDEMO.ALLATORIxDEMO(e);
    }
}
