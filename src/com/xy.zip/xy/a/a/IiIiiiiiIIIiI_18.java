/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.a.iiIIIiiiiiIII
 *  com.xy.i.IiIiIiiiiIIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 */
package com.xy.a.a;

import com.xy.a.a.iiIIIiiiiiIII;
import com.xy.i.IiIiIiiiiIIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.w.IIIiiiiiIiIiI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIiiiiiIIIiI {
    private IIIiiiiiIiIiI iIiIiiiiIiIii;
    private JLabel IiIIIiiiiIiiI;
    private int iiIiiiiiiiIii;
    private IiIiIiiiiIIiI IiiiiiiiIIIII;
    final /* synthetic */ iiIIIiiiiiIII ALLATORIxDEMO;

    public void ALLATORIxDEMO() {
        if (this.iiIiiiiiiiIii == 0) {
            return;
        }
        if (iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO) == this.iiIiiiiiiiIii) {
            this.iIiIiiiiIiIii.iIiIiiiiIIiii(this.iiIiiiiiiiIii == 1 ? "sc/d/156.png" : (this.iiIiiiiiiiIii == 2 ? "sc/d/154.png" : (this.iiIiiiiiiiIii == 3 ? "sc/d/152.png" : (this.iiIiiiiiiiIii == 4 ? "sc/d/158.png" : ""))));
            return;
        }
        this.iIiIiiiiIiIii.iIiIiiiiIIiii(this.iiIiiiiiiiIii == 1 ? "sc/d/157.png" : (this.iiIiiiiiiiIii == 2 ? "sc/d/155.png" : (this.iiIiiiiiiiIii == 3 ? "sc/d/153.png" : (this.iiIiiiiiiiIii == 4 ? "sc/d/159.png" : ""))));
    }

    static /* synthetic */ IiIiIiiiiIIiI ALLATORIxDEMO(IiIiiiiiIIIiI arg0) {
        return arg0.IiiiiiiiIIIII;
    }

    public IiIiiiiiIIIiI(iiIIIiiiiiIII iiIIIiiiiiIII2, int index, IiiiIiiiiIiIi form) {
        this.ALLATORIxDEMO = iiIIIiiiiiIII2;
        this.iiIiiiiiiiIii = index;
        this.IiIIIiiiiIiiI = IiIIIiiiiIIiI.ALLATORIxDEMO((int)116, (int)290, (int)32, (int)15, (Color)iiIIiiiiIiiII.ALLATORIxDEMO((String)"#cCEB987"), (Font)iiIIiiiiIiiII.iIIiiiiiiIIII);
        this.IiIIIiiiiIiiI.setText(String.valueOf(index));
        this.IiIIIiiiiIiiI.setHorizontalAlignment(0);
        this.iIiIiiiiIiIii = new IIIiiiiiIiIiI();
        this.ALLATORIxDEMO();
        if (index == 0) {
            this.iIiIiiiiIiIii.iIiIiiiiIIiii("sc/d/175.png");
            this.iIiIiiiiIiIii.setBounds(116, 281, 32, 32);
            this.IiiiiiiiIIIII = new IiIiIiiiiIIiI(null, 2, 181, form);
            this.IiiiiiiiIIIII.setBounds(100, 255, 60, 65);
        } else if (index == 1) {
            this.IiIIIiiiiIiiI.setBounds(51, 266, 32, 15);
            this.iIiIiiiiIiIii.setBounds(47, 101, 102, 305);
            this.IiiiiiiiIIIII = new IiIiIiiiiIIiI("sc/e/172.png", 2, 182, form);
            this.IiiiiiiiIIIII.setBounds(43, 246, 50, 126);
        } else if (index == 2) {
            this.IiIIIiiiiIiiI.setBounds(195, 187, 32, 15);
            this.iIiIiiiiIiIii.setBounds(132, 183, 121, 223);
            this.IiiiiiiiIIIII = new IiIiIiiiiIIiI("sc/e/171.png", 2, 183, form);
            this.IiiiiiiiIIIII.setBounds(186, 167, 50, 126);
        } else if (index == 3) {
            this.IiIIIiiiiIiiI.setBounds(82, 79, 32, 15);
            this.iIiIiiiiIiIii.setBounds(63, 51, 192, 148);
            this.IiiiiiiiIIIII = new IiIiIiiiiIIiI("sc/e/170.png", 2, 184, form);
            this.IiiiiiiiIIIII.setBounds(73, 58, 50, 126);
        } else if (index == 4) {
            this.IiIIIiiiiIiiI.setBounds(157, 403, 32, 15);
            this.iIiIiiiiIiIii.setBounds(48, 389, 138, 107);
            this.IiiiiiiiIIIII = new IiIiIiiiiIIiI("sc/e/173.png", 2, 185, form);
            this.IiiiiiiiIIIII.setBounds(148, 383, 50, 126);
        }
        form.add((Component)this.IiIIIiiiiIiiI);
        form.add((Component)this.IiiiiiiiIIIII);
        form.add((Component)this.iIiIiiiiIiIii);
        if (index != 0) return;
        form.add((Component)iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)iiIIIiiiiiIII2));
    }

    static /* synthetic */ JLabel ALLATORIxDEMO(IiIiiiiiIIIiI arg0) {
        return arg0.IiIIIiiiiIiiI;
    }
}
