/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.a.iiIiIiiiiIiIi
 */
package com.xy.a.a;

import com.xy.a.a.iiIiIiiiiIiIi;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIIiiiIIIiI
extends JComponent {
    final /* synthetic */ iiIiIiiiiIiIi ALLATORIxDEMO;

    IIiIIiiiIIIiI(iiIiIiiiiIiIi iiIiIiiiiIiIi2) {
        this.ALLATORIxDEMO = iiIiIiiiiIiIi2;
    }
}
