/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.a.iiIIIiiiiiIII
 *  com.xy.q.iIiIIiiiIiiiI
 *  com.xy.v.iIiIIiiiIiiiI
 *  com.xy.w.IIIIIiiiIiIii
 *  com.xy.w.IIiIiiiiIiiIi
 *  com.xy.w.iiiiiiiiiiIiI
 */
package com.xy.a.a;

import com.xy.a.a.iiIIIiiiiiIII;
import com.xy.q.iIiIIiiiIiiiI;
import com.xy.w.IIIIIiiiIiIii;
import com.xy.w.IIiIiiiiIiiIi;
import com.xy.w.iiiiiiiiiiIiI;
import java.awt.Graphics;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiIiiiiiIIiiI
extends iIiIIiiiIiiiI {
    final /* synthetic */ iiIIIiiiiiIII ALLATORIxDEMO;

    iiIiiiiiIIiiI(iiIIIiiiiiIII iiIIIiiiiiIII2) {
        this.ALLATORIxDEMO = iiIIIiiiiiIII2;
    }

    protected void paintComponent(Graphics g) {
        if (iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO) == null) {
            iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO, (IIIIIiiiIiIii)iiiiiiiiiiIiI.iIiIiiiiIIiii((String)IIiIiiiiIiiIi.iIiIiiiiIIiii((String)"zt")));
        }
        if (iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO) == null) {
            return;
        }
        iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO).ALLATORIxDEMO(com.xy.v.iIiIIiiiIiiiI.ALLATORIxDEMO(), 0);
        iiIIIiiiiiIII.ALLATORIxDEMO((iiIIIiiiiiIII)this.ALLATORIxDEMO).ALLATORIxDEMO(g, 7, 3);
    }
}
