/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IIIIIiiiIIIiI
 */
package com.xy.a;

import com.xy.a.IIIIIiiiIIIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIIIiiiIIiII
extends JComponent {
    final /* synthetic */ IIIIIiiiIIIiI ALLATORIxDEMO;

    IiIIIiiiIIiII(IIIIIiiiIIIiI iIIIIiiiIIIiI) {
        this.ALLATORIxDEMO = iIIIIiiiIIIiI;
    }
}
