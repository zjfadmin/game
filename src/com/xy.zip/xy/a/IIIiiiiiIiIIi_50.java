/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iIiIIiiiiiiii
 */
package com.xy.a;

import com.xy.a.iIiIIiiiiiiii;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIiiiiiIiIIi
extends JComponent {
    final /* synthetic */ iIiIIiiiiiiii ALLATORIxDEMO;

    IIIiiiiiIiIIi(iIiIIiiiiiiii iIiIIiiiiiiii2) {
        this.ALLATORIxDEMO = iIiIIiiiiiiii2;
    }
}
