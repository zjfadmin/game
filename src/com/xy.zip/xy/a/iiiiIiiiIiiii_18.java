/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIiIiiiIIiiI
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.w.IIIIIiiiIiiII
 */
package com.xy.a;

import com.xy.a.IiIiIiiiIIiiI;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.w.IIIIIiiiIiiII;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JComponent;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiiiIiiiIiiii
extends JComponent {
    private IIIiiiiiIiIiI iiIiiiiiiiIii;
    private JLabel IiiiiiiiIIIII;
    final /* synthetic */ IiIiIiiiIIiiI ALLATORIxDEMO;

    public iiiiIiiiIiiii(IiIiIiiiIIiiI iiIiIiiiIIiiI) {
        this.ALLATORIxDEMO = iiIiIiiiIIiiI;
        this.iiIiiiiiiiIii = new IIIiiiiiIiIiI(iiIiIiiiIIiiI.ALLATORIxDEMO());
        this.iiIiiiiiiiIii.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/c/54", (int)6, (int)6, (int)6, (int)6, (boolean)false));
        this.iiIiiiiiiiIii.ALLATORIxDEMO(IIIiiiiiIiIiI.IIiiiiiiiIIIi);
        this.iiIiiiiiiiIii.setBounds(1, 2, 22, 22);
        this.add((Component)this.iiIiiiiiiiIii);
        this.IiiiiiiiIIIII = IiIIIiiiiIIiI.ALLATORIxDEMO((int)0, (int)22, (int)24, (int)16, (int)0, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIIiiiiiIiI);
        this.add(this.IiiiiiiiIIIII);
    }

    static /* synthetic */ IIIiiiiiIiIiI ALLATORIxDEMO(iiiiIiiiIiiii arg0) {
        return arg0.iiIiiiiiiiIii;
    }

    static /* synthetic */ JLabel ALLATORIxDEMO(iiiiIiiiIiiii arg0) {
        return arg0.IiiiiiiiIIIII;
    }

    public void ALLATORIxDEMO() {
        this.iiIiiiiiiiIii.ALLATORIxDEMO(0, null);
        this.IiiiiiiiIIIII.setText(null);
        this.setVisible(false);
    }
}
