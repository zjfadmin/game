/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIiIiiiiIiiI
 */
package com.xy.a;

import com.xy.a.IiIiIiiiiIiiI;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiIiiiI
implements MouseListener {
    final /* synthetic */ IiIiIiiiiIiiI ALLATORIxDEMO;

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        IiIiIiiiiIiiI.ALLATORIxDEMO((IiIiIiiiiIiiI)this.ALLATORIxDEMO, (!IiIiIiiiiIiiI.ALLATORIxDEMO((IiIiIiiiiIiiI)this.ALLATORIxDEMO) ? 1 : 0) != 0);
        IiIiIiiiiIiiI.ALLATORIxDEMO((IiIiIiiiiIiiI)this.ALLATORIxDEMO)[2].iIiIiiiiIIiii(IiIiIiiiiIiiI.ALLATORIxDEMO((IiIiIiiiiIiiI)this.ALLATORIxDEMO) ? "sc/e/30.png" : "sc/e/29.png");
        this.ALLATORIxDEMO.ALLATORIxDEMO(IiIiIiiiiIiiI.ALLATORIxDEMO((IiIiIiiiiIiiI)this.ALLATORIxDEMO));
    }

    IIiIiiiiIiiiI(IiIiIiiiiIiiI iiIiIiiiiIiiI) {
        this.ALLATORIxDEMO = iiIiIiiiiIiiI;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }
}
