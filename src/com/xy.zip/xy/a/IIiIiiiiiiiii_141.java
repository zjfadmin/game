/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiiiIiiiiiIiI
 */
package com.xy.a;

import com.xy.a.iiiiIiiiiiIiI;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiiiiii
implements ListSelectionListener {
    final /* synthetic */ iiiiIiiiiiIiI ALLATORIxDEMO;

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        this.ALLATORIxDEMO.iIiIiiiiIIiIi((String)iiiiIiiiiiIiI.ALLATORIxDEMO((iiiiIiiiiiIiI)this.ALLATORIxDEMO).getSelectedValue());
    }

    IIiIiiiiiiiii(iiiiIiiiiiIiI iiiiIiiiiiIiI2) {
        this.ALLATORIxDEMO = iiiiIiiiiiIiI2;
    }
}
