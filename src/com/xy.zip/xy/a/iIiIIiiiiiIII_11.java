/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iIIIIiiiiIIII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.readbean.FM
 */
package com.xy.a;

import com.xy.a.iIIIIiiiiIIII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.readbean.FM;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIIiiiiiIII
extends IIIiiiiiIiIiI {
    final /* synthetic */ iIIIIiiiiIIII ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        FM IiiiiiiiIIIII = (FM)this.IiiIIiiiiiiiI;
        this.ALLATORIxDEMO.ALLATORIxDEMO(IiiiiiiiIIIII);
    }

    iIiIIiiiiiIII(iIIIIiiiiIIII iIIIIiiiiIIII2, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIIIIiiiiIIII2;
        super($anonymous0);
    }
}
