/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIIIiiiIIIiI
 *  com.xy.i.IIIIIiiiIIIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.iiIIiiiiIiiII
 */
package com.xy.a;

import com.xy.a.IiIIIiiiIIIiI;
import com.xy.i.IIIIIiiiIIIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.iiIIiiiiIiiII;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

/*
 * Exception performing whole class analysis ignored.
 */
public static class iiiiIiiiiiiII {
    JLabel iiIiiiiiiiIii = IiIIIiiiiIIiI.ALLATORIxDEMO((int)0, (int)0, (int)0, (int)0, (int)0, (Color)Color.black, (Font)iiIIiiiiIiiII.iIiIiiiiiiIIi);
    final /* synthetic */ IiIIIiiiIIIiI IiiiiiiiIIIII;
    IIIIIiiiIIIiI ALLATORIxDEMO;

    /*
     * WARNING - void declaration
     */
    public iiiiIiiiiiiII(IiIIIiiiIIIiI iiIIIiiiIIIiI, int n) {
        void i;
        this.IiiiiiiiIIIII = iiIIIiiiIIIiI;
        this.ALLATORIxDEMO = new IIIIIiiiIIIiI("sc/b/B308.png", 1, 155, iiIIIiiiIIIiI.ALLATORIxDEMO());
        this.ALLATORIxDEMO.ALLATORIxDEMO((Object)((int)i));
    }
}
