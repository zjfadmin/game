/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iIiIiiiiiiiIi
 */
package com.xy.a;

import com.xy.a.iIiIiiiiiiiIi;
import java.awt.Graphics;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiiIIiiiIIIii
extends JComponent {
    final /* synthetic */ iIiIiiiiiiiIi ALLATORIxDEMO;

    iiiIIiiiIIIii(iIiIiiiiiiiIi iIiIiiiiiiiIi2) {
        this.ALLATORIxDEMO = iIiIiiiiiiiIi2;
    }

    @Override
    protected void paintChildren(Graphics g) {
        super.paintChildren(g);
        this.ALLATORIxDEMO.iIiIiiiiIIiii(g);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.ALLATORIxDEMO.ALLATORIxDEMO(g);
    }
}
