/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIiIiiiiiIIi
 */
package com.xy.a;

import com.xy.a.iiIiIiiiiiIIi;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiiiiiiiIIII
extends JComponent {
    final /* synthetic */ iiIiIiiiiiIIi ALLATORIxDEMO;

    IiiiiiiiiIIII(iiIiIiiiiiIIi iiIiIiiiiiIIi2) {
        this.ALLATORIxDEMO = iiIiIiiiiiIIi2;
    }
}
