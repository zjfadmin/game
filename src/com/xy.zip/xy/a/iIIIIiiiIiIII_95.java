/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIiIiiiIIiiI
 *  com.xy.i.IiiIiiiiIIIii
 *  com.xy.text.GameView
 */
package com.xy.a;

import com.xy.a.IiIiIiiiIIiiI;
import com.xy.i.IiiIiiiiIIIii;
import com.xy.text.GameView;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIIIIiiiIiIII
implements MouseListener {
    final /* synthetic */ IiIiIiiiIIiiI ALLATORIxDEMO;

    iIIIIiiiIiIII(IiIiIiiiIIiiI iiIiIiiiIIiiI) {
        this.ALLATORIxDEMO = iiIiIiiiIIiiI;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        IiiIiiiiIIIii.ALLATORIxDEMO((int)39, (GameView)this.ALLATORIxDEMO.ALLATORIxDEMO());
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }
}
