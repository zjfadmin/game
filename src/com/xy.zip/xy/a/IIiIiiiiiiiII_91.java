/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIIiiiiIiIiI
 */
package com.xy.a;

import com.xy.a.iiIIiiiiIiIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiiiiII
extends JComponent {
    final /* synthetic */ iiIIiiiiIiIiI ALLATORIxDEMO;

    IIiIiiiiiiiII(iiIIiiiiIiIiI iiIIiiiiIiIiI2) {
        this.ALLATORIxDEMO = iiIIiiiiIiIiI2;
    }
}
