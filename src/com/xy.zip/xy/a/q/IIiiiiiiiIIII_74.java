/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iiiiIiiiiiIII
 */
package com.xy.a.q;

import com.xy.a.q.iiiiIiiiiiIII;
import java.math.BigDecimal;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Exception performing whole class analysis ignored.
 */
static class IIiiiiiiiIIII {
    final /* synthetic */ iiiiIiiiiiIII IiIIIiiiiIiiI;
    private BigDecimal iiIiiiiiiiIii;
    private int IiiiiiiiIIIII;
    private int ALLATORIxDEMO;

    public void iIiIiiiiIIiii(int bl) {
        this.IiiiiiiiIIIII = bl;
    }

    public BigDecimal ALLATORIxDEMO() {
        return this.iiIiiiiiiiIii;
    }

    public void ALLATORIxDEMO(BigDecimal id) {
        this.iiIiiiiiiiIii = id;
    }

    static /* synthetic */ int iIiIiiiiIIiii(IIiiiiiiiIIII arg0) {
        return arg0.IiiiiiiiIIIII;
    }

    static /* synthetic */ int ALLATORIxDEMO(IIiiiiiiiIIII arg0) {
        return arg0.ALLATORIxDEMO;
    }

    public IIiiiiiiiIIII(iiiiIiiiiiIII iiiiIiiiiiIII2) {
        this.IiIIIiiiiIiiI = iiiiIiiiiiIII2;
    }

    public int iIiIiiiiIIiii() {
        return this.IiiiiiiiIIIII;
    }

    public void ALLATORIxDEMO(int num) {
        this.ALLATORIxDEMO = num;
    }

    static /* synthetic */ BigDecimal ALLATORIxDEMO(IIiiiiiiiIIII arg0) {
        return arg0.iiIiiiiiiiIii;
    }

    public int ALLATORIxDEMO() {
        return this.ALLATORIxDEMO;
    }
}
