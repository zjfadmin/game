/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iiiiIiiiiiIiI
 */
package com.xy.a.q;

import com.xy.a.q.iiiiIiiiiiIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIiiiiiiiii
extends JComponent {
    final /* synthetic */ iiiiIiiiiiIiI ALLATORIxDEMO;

    IIiIiiiiiiiii(iiiiIiiiiiIiI iiiiIiiiiiIiI2) {
        this.ALLATORIxDEMO = iiiiIiiiiiIiI2;
    }
}
