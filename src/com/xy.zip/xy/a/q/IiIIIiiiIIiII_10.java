/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IIIIIiiiIIIiI
 */
package com.xy.a.q;

import com.xy.a.q.IIIIIiiiIIIiI;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIIIiiiIIiII
implements ListSelectionListener {
    final /* synthetic */ IIIIIiiiIIIiI ALLATORIxDEMO;

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        this.ALLATORIxDEMO.iIiIiiiiIIiIi((String)IIIIIiiiIIIiI.ALLATORIxDEMO((IIIIIiiiIIIiI)this.ALLATORIxDEMO).getSelectedValue());
    }

    IiIIIiiiIIiII(IIIIIiiiIIIiI iIIIIiiiIIIiI) {
        this.ALLATORIxDEMO = iIIIIiiiIIIiI;
    }
}
