/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IIiiiiiiiIIII
 *  com.xy.a.q.iiiiIiiiiiIII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.readbean.Goodstable
 */
package com.xy.a.q;

import com.xy.a.q.IIiiiiiiiIIII;
import com.xy.a.q.iiiiIiiiiiIII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.readbean.Goodstable;
import java.awt.Color;
import java.awt.Graphics;

/*
 * Exception performing whole class analysis ignored.
 */
static class iiIiiiiiIIiIi
extends IIIiiiiiIiIiI {
    final /* synthetic */ iiiiIiiiiiIII IiiiiiiiIIIII;
    private IIiiiiiiiIIII ALLATORIxDEMO;

    public void ALLATORIxDEMO(IIiiiiiiiIIII bean) {
        this.ALLATORIxDEMO = bean;
        Goodstable IiiiiiiiIIIII = this.ALLATORIxDEMO != null ? this.IiiiiiiiIIIII.ALLATORIxDEMO().ALLATORIxDEMO(IIiiiiiiiIIII.ALLATORIxDEMO((IIiiiiiiiIIII)this.ALLATORIxDEMO)) : null;
        this.ALLATORIxDEMO(IiiiiiiiIIIII != null ? 1 : 0, IiiiiiiiIIIII);
        this.ALLATORIxDEMO(iiiiIiiiiiIII.ALLATORIxDEMO((iiiiIiiiiiIII)this.IiiiiiiiIIIII) != null && iiiiIiiiiiIII.ALLATORIxDEMO((iiiiIiiiiiIII)this.IiiiiiiiIIIII) == this.ALLATORIxDEMO ? "sc/b/S306.png" : null);
    }

    public iiIiiiiiIIiIi(iiiiIiiiiiIII iiiiIiiiiiIII2) {
        this.IiiiiiiiIIIII = iiiiIiiiiiIII2;
        super(iiiiIiiiiiIII2.ALLATORIxDEMO());
    }

    static /* synthetic */ IIiiiiiiiIIII ALLATORIxDEMO(iiIiiiiiIIiIi arg0) {
        return arg0.ALLATORIxDEMO;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (this.ALLATORIxDEMO == null) return;
        g.setColor(Color.red);
        g.setFont(iiIIiiiiIiiII.iiIiiiiiiIIiI);
        g.drawString(String.valueOf(IIiiiiiiiIIII.ALLATORIxDEMO((IIiiiiiiiIIII)this.ALLATORIxDEMO)), 36, 14);
    }
}
