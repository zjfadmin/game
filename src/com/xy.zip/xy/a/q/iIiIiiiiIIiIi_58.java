/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IIIiIiiiIiIii
 */
package com.xy.a.q;

import com.xy.a.q.IIIiIiiiIiIii;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIiiiiIIiIi
implements MouseListener {
    final /* synthetic */ IIIiIiiiIiIii ALLATORIxDEMO;

    iIiIiiiiIIiIi(IIIiIiiiIiIii iIIiIiiiIiIii) {
        this.ALLATORIxDEMO = iIIiIiiiIiIii;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        IIIiIiiiIiIii.ALLATORIxDEMO((IIIiIiiiIiIii)this.ALLATORIxDEMO, (!IIIiIiiiIiIii.ALLATORIxDEMO((IIIiIiiiIiIii)this.ALLATORIxDEMO) ? 1 : 0) != 0);
        IIIiIiiiIiIii.ALLATORIxDEMO((IIIiIiiiIiIii)this.ALLATORIxDEMO)[3].iIiIiiiiIIiii(IIIiIiiiIiIii.ALLATORIxDEMO((IIIiIiiiIiIii)this.ALLATORIxDEMO) ? "sc/e/30.png" : "sc/e/29.png");
    }
}
