/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iIIIIiiiiIIII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.q;

import com.xy.a.q.iIIIIiiiiIIII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiIIiiiiiIII
extends IIIiiiiiIiIiI {
    final /* synthetic */ iIIIIiiiiIIII ALLATORIxDEMO;

    public void mousePressed(MouseEvent e) {
        super.mousePressed(e);
        this.ALLATORIxDEMO.iiiIiiiiiiIIi();
    }

    iIiIIiiiiiIII(iIIIIiiiiIIII iIIIIiiiiIIII2, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIIIIiiiiIIII2;
        super($anonymous0);
    }
}
