/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IIiiiiiiiIIIi
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.q;

import com.xy.a.q.IIiiiiiiiIIIi;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIIIiiiIIiIi
extends IIIiiiiiIiIiI {
    final /* synthetic */ IIiiiiiiiIIIi ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        IIiiiiiiiIIIi.ALLATORIxDEMO((IIiiiiiiiIIIi)this.ALLATORIxDEMO).ALLATORIxDEMO(IIiiiiiiiIIIi.ALLATORIxDEMO((IIiiiiiiiIIIi)this.ALLATORIxDEMO), 1);
    }

    IiIIIiiiIIiIi(IIiiiiiiiIIIi iIiiiiiiiIIIi, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iIiiiiiiiIIIi;
        super($anonymous0);
    }
}
