/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.i.IiiiIiiiiIiII
 *  com.xy.a.iiIiiiiiIIiiI
 *  com.xy.a.q.IIIIIiiiIiiII
 *  com.xy.a.q.IIiIiiiiIiIII
 *  com.xy.bean.QualityClBean
 *  com.xy.bean.SuitOperBean
 *  com.xy.i.IiiiiiiiiIIII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iIIiIiiiIiiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.q.iiIiIiiiiIiIi
 *  com.xy.readbean.AlchemySet
 *  com.xy.readbean.AlchemyUnit
 *  com.xy.readbean.Goodstable
 *  com.xy.readbean.MoneyType
 *  com.xy.socket.Agreement
 *  com.xy.text.GameView
 *  com.xy.v.IIIIiiiiIIIIi
 *  com.xy.v.IIIiiiiiIiIiI
 *  com.xy.v.IIiiIiiiiIIiI
 *  com.xy.v.IiiiIiiiiIiIi
 *  com.xy.v.iIiIIiiiIiiiI
 *  com.xy.v.iiIiIiiiiIiii
 *  com.xy.v.iiIiiiiiIIiii
 *  com.xy.w.IIIIIiiiIiIii
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 *  com.xy.w.iiiiiiiiiiIiI
 */
package com.xy.a.q;

import com.xy.a.i.IiiiIiiiiIiII;
import com.xy.a.iiIiiiiiIIiiI;
import com.xy.a.q.IIIIIiiiIiiII;
import com.xy.a.q.IIiIiiiiIiIII;
import com.xy.bean.QualityClBean;
import com.xy.bean.SuitOperBean;
import com.xy.i.IiiiiiiiiIIII;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.iIIiIiiiIiiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.q.iiIiIiiiiIiIi;
import com.xy.readbean.AlchemySet;
import com.xy.readbean.AlchemyUnit;
import com.xy.readbean.Goodstable;
import com.xy.readbean.MoneyType;
import com.xy.socket.Agreement;
import com.xy.text.GameView;
import com.xy.v.IIIIiiiiIIIIi;
import com.xy.v.IIiiIiiiiIIiI;
import com.xy.v.IiiiIiiiiIiIi;
import com.xy.v.iIiIIiiiIiiiI;
import com.xy.v.iiIiIiiiiIiii;
import com.xy.v.iiIiiiiiIIiii;
import com.xy.w.IIIIIiiiIiIii;
import com.xy.w.IIIiiiiiIiIiI;
import com.xy.w.iiiiiiiiiiIiI;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JLabel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class IiIiIiiiiIIiI
extends com.xy.q.IiiiIiiiiIiIi {
    private long IIIIIiiiIiIIi;
    private int iiIIiiiiIiIIi;
    private IiiiiiiiiIIII[] IiIIiiiiIIIII;
    private iIIiIiiiIiiIi[] iIIIIiiiiiIIi;
    private IIIIIiiiIiIii IiiIIiiiiiiiI;
    private IiiiIiiiiIiII IIiiiiiiIiiII;
    private List<IIIIiiiiIIIIi> IiiiIiiiIiIII;
    private QualityClBean IIiiiiiiiIIIi;
    private com.xy.q.IIIiiiiiIiIiI[] IIIiiiiiIIiII;
    private Image iiIiiiiiiIIiI = null;
    private Object iIiiIiiiIiIIi;
    private IiiiiiiiiIIII[] iiiiIiiiIIiii;
    private long iIIiIiiiiiiIi;
    private iiIiIiiiiIiIi[] IIIIiiiiiiiII;
    private boolean iiIIIiiiiiiiI;
    private IIIIIiiiIiIii IiIiiiiiIIIII;
    private IIIiiiiiIiIiI[] iiIiIiiiiIIIi;
    private List<iiIiIiiiiIiii> iiiiIiiiIiiII;
    private Image iiiIiiiiiiiIi = null;
    private IIiIiiiiIiIII iIiiIiiiiiiII;
    private Image IIiiIiiiIIiIi = null;
    private IIiIiiiiIiIII IiIIIiiiiIiiI;
    private JLabel[] iiIiiiiiiiIii;
    private long IiiiiiiiIIIII;
    private long ALLATORIxDEMO;

    static /* synthetic */ void iiiIiiiiiiIIi(IiIiIiiiiIIiI arg0, Image arg1) {
        arg0.iiiIiiiiiiiIi = arg1;
    }

    public void iIiIiiiiIIiii() {
        this.IIIiiiiiIIiII[0].ALLATORIxDEMO(0, null);
        this.IiIIIiiiiIiiI.ALLATORIxDEMO(0, 0);
        this.IIIiiiiiIIiII[1].ALLATORIxDEMO(0, null);
        this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
        this.iIiIiiiiIIiii(0);
        super.iIiIiiiiIIiii();
    }

    public void iiiIiiiiiiIIi(Goodstable good) {
        if (this.IIiiiiiiIiiII == null) {
            return;
        }
        this.iiiIiiiiiiIIi(false);
        int IiiiiiiiIIIII = (Integer)this.IIiiiiiiIiiII.iiIiiiiiiiIii;
        if (this.iIiIiiiiIIiii()) {
            return;
        }
        if (IiiiiiiiIIIII == 0) {
            this.ALLATORIxDEMO(good);
            return;
        }
        if (IiiiiiiiIIIII != 1) return;
        this.iIiIiiiiIIiii(good);
    }

    static /* synthetic */ iIIiIiiiIiiIi[] ALLATORIxDEMO(IiIiIiiiiIIiI arg0) {
        return arg0.iIIIIiiiiiIIi;
    }

    static /* synthetic */ IIiIiiiiIiIII iIiIiiiiIIiii(IiIiIiiiiIIiI arg0) {
        return arg0.iIiiIiiiiiiII;
    }

    public boolean iIiIiiiiIIiii() {
        return this.iiIIIiiiiiiiI;
    }

    static /* synthetic */ Image iiiIiiiiiiIIi(IiIiIiiiiIIiI arg0) {
        return arg0.iiiIiiiiiiiIi;
    }

    public void iiiIiiiiiiIIi(com.xy.q.IIIiiiiiIiIiI imgGrid) {
        if (this.iiIIiiiiIiIIi != 1) {
            return;
        }
        if (this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 0) {
            this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u5148\u9009\u62e9\u4e3b\u5b88\u62a4\u77f3");
            return;
        }
        this.iiiIiiiiiiIIi(1);
    }

    /*
     * Unable to fully structure code
     */
    public void iIiIiiiiIIiIi(int type) {
        block16: {
            block15: {
                if (type != 0) break block15;
                IiiiiiiiIIIII = 0;
                if (true) ** GOTO lbl15
            }
            if (type != 1) break block16;
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl41
        }
        if (type != 2) return;
        IiiiiiiiIIIII = 0;
        if (true) ** GOTO lbl66
        do {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII].setVisible(IiiiiiiiIIIII < 6 || IiiiiiiiIIIII == 8);
            ++IiiiiiiiIIIII;
lbl15:
            // 2 sources

        } while (IiiiiiiiIIIII < this.iiIiiiiiiiIii.length);
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIIIIiiiiiIIi.length) {
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII].setVisible(IiiiiiiiIIIII < 2);
            ++IiiiiiiiIIIII;
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIIiiiiiiiII.length) {
            this.IIIIiiiiiiiII[IiiiiiiiIIIII++].setVisible(true);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIiiiiiIIiII.length) {
            this.IIIiiiiiIIiII[IiiiiiiiIIIII++].setVisible(true);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIiiiiIIIII.length) {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII].setVisible(IiiiiiiiIIIII < 1);
            ++IiiiiiiiIIIII;
        }
        this.IiIIIiiiiIiiI.setVisible(true);
        this.iIiiIiiiiiiII.setVisible(false);
        this.iiIiIiiiiIIIi[1].setVisible(true);
        this.iiIiIiiiiIIIi[2].setVisible(true);
        return;
        do {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII++].setVisible(true);
lbl41:
            // 2 sources

        } while (IiiiiiiiIIIII < this.iiIiiiiiiiIii.length);
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIIIIiiiiiIIi.length) {
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII++].setVisible(true);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIIiiiiiiiII.length) {
            this.IIIIiiiiiiiII[IiiiiiiiIIIII++].setVisible(true);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIiiiiiIIiII.length) {
            this.IIIiiiiiIIiII[IiiiiiiiIIIII++].setVisible(true);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIiiiiIIIII.length) {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII].setVisible(IiiiiiiiIIIII < 1);
            ++IiiiiiiiIIIII;
        }
        this.IiIIIiiiiIiiI.setVisible(true);
        this.iIiiIiiiiiiII.setVisible(true);
        this.iiIiIiiiiIIIi[1].setVisible(true);
        this.iiIiIiiiiIIIi[2].setVisible(true);
        return;
        do {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII++].setVisible(false);
lbl66:
            // 2 sources

        } while (IiiiiiiiIIIII < this.iiIiiiiiiiIii.length);
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIIIIiiiiiIIi.length) {
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII++].setVisible(false);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIIiiiiiiiII.length) {
            this.IIIIiiiiiiiII[IiiiiiiiIIIII++].setVisible(false);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IIIiiiiiIIiII.length) {
            this.IIIiiiiiIIiII[IiiiiiiiIIIII++].setVisible(false);
        }
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.IiIIiiiiIIIII.length) {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII++].setVisible(true);
        }
        this.IiIIIiiiiIiiI.setVisible(true);
        this.iIiiIiiiiiiII.setVisible(true);
        this.iiIiIiiiiIIIi[1].setVisible(false);
        this.iiIiIiiiiIIIi[2].setVisible(false);
    }

    public boolean ALLATORIxDEMO() {
        if (this.IiIiiiiiIIIII != null) {
            this.IiIiiiiiIIIII = null;
        }
        if (this.IiiIIiiiiiiiI == null) return super.ALLATORIxDEMO();
        this.IiiIIiiiiiiiI = null;
        return super.ALLATORIxDEMO();
    }

    public void iiiIiiiiiiIIi(int index) {
        if (this.iiIIiiiiIiIIi != 0 && this.iiIIiiiiIiIIi != 1) {
            return;
        }
        if (this.IIiiiiiiIiiII == null) {
            this.IIiiiiiiIiiII = new IiiiIiiiiIiII((com.xy.q.IiiiIiiiiIiIi)this);
            this.IIiiiiiiIiiII.IiiiiiiiIIIII.ALLATORIxDEMO(new long[]{108L});
            this.IIiiiiiiIiiII.iiIiiiiiiiIii = index;
            this.IIiiiiiiIiiII.IiiiiiiiIIIII.iiiIiiiiiiIIi(index == 0 ? 0 : 1);
            this.add((Component)this.IIiiiiiiIiiII, 0);
            this.iiiIiiiiiiIIi(true);
            return;
        }
        this.IIiiiiiiIiiII.iiIiiiiiiiIii = index;
        this.IIiiiiiiIiiII.IiiiiiiiIIIII.iiiIiiiiiiIIi(index == 0 ? 0 : 1);
        this.iiiIiiiiiiIIi(!this.IIiiiiiiIiiII.isVisible());
    }

    static /* synthetic */ void iIiIiiiiIIiii(IiIiIiiiiIIiI arg0, Image arg1) {
        arg0.iiIiiiiiiIIiI = arg1;
    }

    public static int iiiiiiiiIIiii() {
        int IiiiiiiiIIIII = IiiiIiiiiIiIi.iIiIiiiiIiIii.nextInt(100);
        if (IiiiiiiiIIIII < 12) {
            return 5;
        }
        if (IiiiiiiiIIIII < 39) {
            return 4;
        }
        if (IiiiiiiiIIIII >= 73) return 2;
        return 3;
    }

    /*
     * WARNING - void declaration
     */
    public void iIiIiiiiIIiii(Goodstable goodstable) {
        void good;
        this.IIIiiiiiIIiII[1].ALLATORIxDEMO(1, (Object)goodstable);
        this.iIiiIiiiiiiII.ALLATORIxDEMO((Goodstable)good, this.ALLATORIxDEMO().ALLATORIxDEMO());
        if (this.iiIIiiiiIiIIi != 1) return;
        if (this.iiiiIiiiIiiII == null) return;
        this.iiiiIiiiIiiII.clear();
    }

    /*
     * WARNING - void declaration
     */
    public void iiiIiiiiiiIIi() {
        int IiiiiiiiIIIII = Integer.parseInt(this.IIiiiiiiiIIIi.getData());
        this.iIiiIiiiiiiII.ALLATORIxDEMO(IiiiiiiiIIIII);
        if (IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)this.IIiiiiiiiIIIi.getNewAttr())) {
            return;
        }
        Goodstable IiiiiiiiIIIII2 = this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO() : null;
        AlchemySet IiiiiiiiIIIII3 = this.ALLATORIxDEMO().ALLATORIxDEMO();
        if (IiiiiiiiIIIII2 == null) return;
        if (IiiiiiiiIIIII3 == null) {
            return;
        }
        if (this.iiiiIiiiIiiII != null) {
            this.iiiiIiiiIiiII.clear();
        }
        if (this.IiiiIiiiIiIII == null) {
            this.IiiiIiiiIiIII = new ArrayList<IIIIiiiiIIIIi>();
        }
        this.IiiiIiiiIiIII.clear();
        int IiiiiiiiIIIII4 = 0;
        while (IiiiiiiiIIIII4 < 7) {
            block10: {
                IIIIIiiiIiiII IiiiiiiiIIIII5;
                IIIIIiiiIiiII IiiiiiiiIIIII6;
                block12: {
                    void IiiiiiiiIIIII7;
                    String IiiiiiiiIIIII8;
                    int IiiiiiiiIIIII9;
                    block11: {
                        if ((IiiiiiiiIIIII >> IiiiiiiiIIIII4 & 1) == 0) break block10;
                        IiiiiiiiIIIII6 = IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.iIiiIiiiiiiII)[IiiiiiiiIIIII4];
                        if (IiiiiiiiIIIII4 < 5 && IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII6)) || IiiiiiiiIIIII4 >= 5 && IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII6) == 0) break block10;
                        IiiiiiiiIIIII9 = this.IiIIIiiiiIiiI.ALLATORIxDEMO(IiiiiiiiIIIII4, IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII6), IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII6));
                        IIIIIiiiIiiII iIIIIiiiIiiII = IiiiiiiiIIIII5 = IiiiiiiiIIIII9 >= 0 ? IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.IiIIIiiiiIiiI)[IiiiiiiiIIIII9] : null;
                        if (IiiiiiiiIIIII5 == null) break block10;
                        if (IiiiiiiiIIIII4 >= 5) break block11;
                        IiiiiiiiIIIII8 = IIiiIiiiiIIiI.iIiIiiiiIIiii((String)this.IIiiiiiiiIIIi.getNewAttr(), (String)(String.valueOf(IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5)) + "="), (String)"|");
                        if (IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)IiiiiiiiIIIII8)) break block10;
                        double IiiiiiiiIIIII10 = Double.parseDouble(IiiiiiiiIIIII8);
                        if (IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) >= IiiiiiiiIIIII10) break block10;
                        AlchemyUnit IiiiiiiiIIIII11 = IiiiiiiiIIIII3.getAlchemyUnit(IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5));
                        iiIiIiiiiIiii IiiiiiiiIIIII12 = new iiIiIiiiiIiii();
                        IiiiiiiiIIIII12.ALLATORIxDEMO = IiiiiiiiIIIII9;
                        IiiiiiiiIIIII12.IiiiiiiiIIIII = "+" + IIiiIiiiiIIiI.ALLATORIxDEMO((double)(IiiiiiiiIIIII10 - IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5)), (int)(IiiiiiiiIIIII11 != null ? IiiiiiiiIIIII11.getSize() : 1)) + iiIiiiiiIIiiI.iIiIiiiiIIiii((String)IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5));
                        if (this.iiiiIiiiIiiII == null) {
                            this.iiiiIiiiIiiII = new ArrayList<iiIiIiiiiIiii>();
                        }
                        this.iiiiIiiiIiiII.add(IiiiiiiiIIIII12);
                        break block12;
                    }
                    IiiiiiiiIIIII8 = IIiiIiiiiIIiI.iIiIiiiiIIiii((String)this.IIiiiiiiiIIIi.getNewAttr(), (String)("\u6280\u80fd=" + IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) + "#"), (String)"|");
                    if (IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)IiiiiiiiIIIII8)) break block10;
                    int IiiiiiiiIIIII13 = Integer.valueOf(IiiiiiiiIIIII8);
                    if (IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) >= (double)IiiiiiiiIIIII13) break block10;
                    iiIiIiiiiIiii iiIiIiiiiIiii2 = new iiIiIiiiiIiii();
                    IiiiiiiiIIIII7.ALLATORIxDEMO = IiiiiiiiIIIII9;
                    IiiiiiiiIIIII7.IiiiiiiiIIIII = "+" + IIiiIiiiiIIiI.ALLATORIxDEMO((double)(IiiiiiiiIIIII13 - (int)IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5)), (int)0) + "\u7ea7";
                    if (this.iiiiIiiiIiiII == null) {
                        this.iiiiIiiiIiiII = new ArrayList<iiIiIiiiiIiii>();
                    }
                    this.iiiiIiiiIiiII.add((iiIiIiiiiIiii)IiiiiiiiIIIII7);
                }
                this.IiiiIiiiIiIII.add(new IIIIiiiiIIIIi((long)(this.iIiiIiiiiiiII.getX() + IiiiiiiiIIIII6.getX() + 30), (long)(this.iIiiIiiiiiiII.getY() + IiiiiiiiIIIII6.getY() + 18), iIiIIiiiIiiiI.ALLATORIxDEMO(), 1L));
                this.IiiiIiiiIiIII.add(new IIIIiiiiIIIIi((long)(this.IiIIIiiiiIiiI.getX() + IiiiiiiiIIIII5.getX() + 30), (long)(this.IiIIIiiiiIiiI.getY() + IiiiiiiiIIIII5.getY() + 18), iIiIIiiiIiiiI.ALLATORIxDEMO(), 0L));
            }
            ++IiiiiiiiIIIII4;
        }
        this.IiIIIiiiiIiiI.ALLATORIxDEMO(IiiiiiiiIIIII2, IiiiiiiiIIIII3);
    }

    public void iIiIiiiiIIiIi(boolean animation) {
        this.iiIIIiiiiiiiI = animation;
        this.ALLATORIxDEMO = iIiIIiiiIiiiI.ALLATORIxDEMO();
        this.IIIIIiiiIiIIi = 0L;
        this.iIiiIiiiIiIIi = null;
        if (this.iiiiIiiiIiiII == null) return;
        this.iiiiIiiiIiiII.clear();
    }

    /*
     * Unable to fully structure code
     */
    public void iIiIiiiiIIiii(int type) {
        block12: {
            block11: {
                block10: {
                    this.iiIIiiiiIiIIi = type;
                    IiiiiiiiIIIII = 0;
                    while (IiiiiiiiIIIII < this.iiiiIiiiIIiii.length) {
                        this.iiiiIiiiIIiii[IiiiiiiiIIIII].setKeep(IiiiiiiiIIIII == this.iiIIiiiiIiIIi || IiiiiiiiIIIII == 0 && this.iiIIiiiiIiIIi == 2);
                        ++IiiiiiiiIIIII;
                    }
                    this.IIiiiiiiiIIIi = null;
                    this.iIiIiiiiIIiIi(false);
                    this.iiiIiiiiiiIIi(false);
                    if (type != 0) break block10;
                    this.iIIiIiiiiiiIi = 200000L;
                    iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)this.iIIIIiiiiiIIi[0], (long)200000L);
                    this.IiiiiiiiIIIII = 0L;
                    iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)this.iIIIIiiiiiIIi[1], (long)0L);
                    this.iiIiiiiiiiIii[0].setText("\u5b88\u62a4\u77f3");
                    this.iiIiiiiiiiIii[1].setText("\u7075\u5143\u6676");
                    this.iiIiiiiiiiIii[0].setBounds(95, 118, 100, 22);
                    this.iiIiiiiiiiIii[1].setBounds(239, 118, 100, 22);
                    IiiiiiiiIIIII = 0;
                    if (true) ** GOTO lbl50
                }
                if (type != 1) break block11;
                this.iIIiIiiiiiiIi = 200000L;
                iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)this.iIIIIiiiiiIIi[0], (long)200000L);
                this.IiiiiiiiIIIII = 100L;
                iiIIiiiiIiiII.ALLATORIxDEMO((JLabel)this.iIIIIiiiiiIIi[1], (long)100L);
                this.iiIiiiiiiiIii[0].setText("\u4e3b\u5b88\u62a4\u77f3");
                this.iiIiiiiiiiIii[1].setText("\u526f\u5b88\u62a4\u77f3");
                this.iiIiiiiiiiIii[0].setBounds(168, 75, 100, 22);
                this.iiIiiiiiiiIii[1].setBounds(483, 75, 100, 22);
                IiiiiiiiIIIII = 0;
                if (true) ** GOTO lbl97
            }
            if (type == 2) {
                this.iIIiIiiiiiiIi = 200000L;
                this.IiiiiiiiIIIII = 0L;
                this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
                this.IiIIIiiiiIiiI.setBounds(55, 132, 257, 248);
                this.iIiiIiiiiiiII.setBounds(370, 132, 257, 248);
                this.IiIIiiiiIIIII[0].setText("\u7ee7\u7eed\u9644\u7075");
                this.IiIIiiiiIIIII[0].setBounds(520, 80, 99, 25);
                this.IiIIiiiiIIIII[1].setBounds(443, 426, 99, 25);
                this.IiIIiiiiIIIII[2].setBounds(128, 426, 99, 25);
            }
            break block12;
            do {
                v0 = this.IIIiiiiiIIiII[IiiiiiiiIIIII];
                v1 = 97 + IiiiiiiiIIIII * 144;
                ++IiiiiiiiIIIII;
                v0.setBounds(v1, 156, 52, 52);
lbl50:
                // 2 sources

            } while (IiiiiiiiIIIII < this.IIIiiiiiIIiII.length);
            IiiiiiiiIIIII = this.ALLATORIxDEMO().ALLATORIxDEMO(new BigDecimal(25297));
            this.IIIiiiiiIIiII[1].ALLATORIxDEMO(IiiiiiiiIIIII != null && IiiiiiiiIIIII.getType() == 107L ? 1 : 0, (Object)IiiiiiiiIIIII);
            this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
            this.iiIiiiiiiiIii[4].setText("\u6d88\u8017\u4f53\u529b");
            this.iiIiiiiiiiIii[5].setText("\u62e5\u6709\u4f53\u529b");
            IiiiiiiiIIIII = 2;
            while (IiiiiiiiIIIII < 6) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c2A1C03"));
                v2 = this.iiIiiiiiiiIii[IiiiiiiiIIIII];
                v3 = 237 + (IiiiiiiiIIIII - 2) * 29;
                ++IiiiiiiiIIIII;
                v2.setBounds(94, v3, 72, 20);
            }
            this.iiIiiiiiiiIii[8].setHorizontalAlignment(10);
            this.iiIiiiiiiiIii[8].setFont(iiIIiiiiIiiII.iIiIiiiiiiIIi);
            this.iiIiiiiiiiIii[8].setForeground(Color.black);
            this.iiIiiiiiiiIii[8].setText("\u4fdd\u7559\u539f\u5c5e\u6027");
            this.iiIiiiiiiiIii[8].setBounds(360, 429, 90, 17);
            this.IIIIiiiiiiiII[1].ALLATORIxDEMO().setIdAndKey(0, null);
            IiiiiiiiIIIII = 0;
            while (IiiiiiiiIIIII < this.IIIIiiiiiiiII.length) {
                v4 = this.IIIIiiiiiiiII[IiiiiiiiIIIII];
                v5 = 264 + IiiiiiiiIIIII * 54;
                ++IiiiiiiiIIIII;
                v4.setBounds(170, v5, 132, 20);
            }
            IiiiiiiiIIIII = 0;
            while (IiiiiiiiIIIII < 2) {
                v6 = this.iIIIIiiiiiIIi[IiiiiiiiIIIII];
                v7 = 237 + IiiiiiiiIIIII * 54;
                ++IiiiiiiiIIIII;
                v6.setBounds(170, v7, 132, 20);
            }
            this.iiIiIiiiiIIIi[1].iIiIiiiiIIiii("sc/d/177.png");
            this.iiIiIiiiiIIIi[1].setBounds(182, 161, 30, 42);
            this.iiIiIiiiiIIIi[2].iIiIiiiiIIiii("sc/e/30.png");
            this.iiIiIiiiiIIIi[2].setBounds(343, 429, 17, 17);
            this.IiIIiiiiIIIII[0].setText("\u5f00\u59cb\u9644\u7075");
            this.IiIIiiiiIIIII[0].setBounds(233, 426, 99, 25);
            this.IiIIIiiiiIiiI.setBounds(353, 105, 257, 248);
            break block12;
            do {
                v8 = this.IIIiiiiiIIiII[IiiiiiiiIIIII];
                v9 = 102 + IiiiiiiiIIIII * 315;
                ++IiiiiiiiIIIII;
                v8.setBounds(v9, 72, 52, 52);
lbl97:
                // 2 sources

            } while (IiiiiiiiIIIII < this.IIIiiiiiIIiII.length);
            this.IIIiiiiiIIiII[1].ALLATORIxDEMO(0, null);
            this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
            this.iiIiiiiiiiIii[4].setText("\u62e5\u6709\u5b88\u62a4\u4e4b\u5c18");
            this.iiIiiiiiiiIii[5].setText("\u6d88\u8017\u5b88\u62a4\u4e4b\u5c18");
            IiiiiiiiIIIII = 2;
            while (IiiiiiiiIIIII < 6) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII].setForeground(Color.black);
                v10 = this.iiIiiiiiiiIii[IiiiiiiiIIIII];
                v11 = 57 + (IiiiiiiiIIIII - 2) % 2 * 227;
                v12 = 415 + (IiiiiiiiIIIII - 2) / 2 * 27;
                ++IiiiiiiiIIIII;
                v10.setBounds(v11, v12, 102, 19);
            }
            this.iiIiiiiiiiIii[8].setHorizontalAlignment(4);
            this.iiIiiiiiiiIii[8].setFont(iiIIiiiiIiiII.iIIIiiiiIIIii);
            this.iiIiiiiiiiIii[8].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#cFFF7D0"));
            this.iiIiiiiiiiIii[8].setText("\u53ef\u5438\u6536\u7075\u7a8d\u4e2a\u6570");
            this.iiIiiiiiiiIii[8].setBounds(254, 385, 120, 16);
            this.IIIIiiiiiiiII[1].ALLATORIxDEMO().setIdAndKey(0, "\u5b88\u62a4\u4e4b\u5c18");
            IiiiiiiiIIIII = 0;
            while (IiiiiiiiIIIII < this.IIIIiiiiiiiII.length) {
                v13 = this.IIIIiiiiiiiII[IiiiiiiiIIIII];
                v14 = 415 + 29 * IiiiiiiiIIIII;
                ++IiiiiiiiIIIII;
                v13.setBounds(386, v14, 114, 19);
            }
            IiiiiiiiIIIII = 0;
            while (IiiiiiiiIIIII < 2) {
                v15 = this.iIIIIiiiiiIIi[IiiiiiiiIIIII];
                v16 = 415 + 29 * IiiiiiiiIIIII;
                ++IiiiiiiiIIIII;
                v15.setBounds(159, v16, 114, 19);
            }
            this.iiIiIiiiiIIIi[1].iIiIiiiiIIiii("sc/d/176.png");
            this.iiIiIiiiiIIIi[1].setBounds(322, 284, 38, 16);
            this.iiIiIiiiiIIIi[2].iIiIiiiiIIiii("sc/d/184.png");
            this.iiIiIiiiiIIIi[2].setBounds(85, 384, 510, 17);
            this.IiIIiiiiIIIII[0].setText("\u5f00\u59cb\u7194\u70bc");
            this.IiIIiiiiIIIII[0].setBounds(515, 426, 99, 25);
            this.IiIIIiiiiIiiI.setBounds(55, 132, 257, 248);
            this.iIiiIiiiiiiII.setBounds(370, 132, 257, 248);
        }
        this.iIiIiiiiIIiIi(type);
    }

    static /* synthetic */ Image iIiIiiiiIIiii(IiIiIiiiiIIiI arg0) {
        return arg0.iiIiiiiiiIIiI;
    }

    /*
     * Unable to fully structure code
     */
    public boolean ALLATORIxDEMO(int id) {
        block20: {
            if (id != 323) break block20;
            if (this.iiIIiiiiIiIIi == 0) {
                v0 = IiiiiiiiIIIII = this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO() : null;
                if (IiiiiiiiIIIII == null) {
                    this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u8bf7\u9009\u62e9\u5b88\u62a4\u77f3");
                    return false;
                }
                this.iIiIiiiiIIiii(2);
                return true;
            }
            if (this.iiIIiiiiIiIIi == 1) {
                if (this.iIiIiiiiIIiii()) {
                    return false;
                }
                IiiiiiiiIIIII = this.ALLATORIxDEMO();
                if (IiiiiiiiIIIII.getLoginResult().getGold().longValue() < this.iIIiIiiiiiiIi) {
                    this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u91d1\u94b1\u4e0d\u8db3");
                    return false;
                }
                if (IiiiiiiiIIIII.getLoginResult().getScoretype("\u5b88\u62a4\u4e4b\u5c18").longValue() < this.IiiiiiiiIIIII) {
                    this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u5b88\u62a4\u4e4b\u5c18\u4e0d\u8db3");
                    return false;
                }
                IiiiiiiiIIIII = this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO() : null;
                v1 = IiiiiiiiIIIII = this.IIIiiiiiIIiII[1].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[1].ALLATORIxDEMO() : null;
                if (IiiiiiiiIIIII != null) {
                    IiiiiiiiIIIII = IiiiiiiiIIIII.getGood(IiiiiiiiIIIII.getRgid());
                }
                if (IiiiiiiiIIIII != null) {
                    IiiiiiiiIIIII = IiiiiiiiIIIII.getGood(IiiiiiiiIIIII.getRgid());
                }
                if (IiiiiiiiIIIII == null || IiiiiiiiIIIII == null) {
                    this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u8bf7\u9009\u62e9\u5b88\u62a4\u77f3\u6216\u5b88\u62a4\u77f3\u4e0d\u5728\u80cc\u5305");
                    return false;
                }
                IiiiiiiiIIIII.getLoginResult().setGold(new BigDecimal(IiiiiiiiIIIII.getLoginResult().getGold().longValue() - this.iIIiIiiiiiiIi));
                IiiiiiiiIIIII.getLoginResult().setScore(com.xy.v.IIIiiiiiIiIiI.iIiIiiiiIIiii((String)IiiiiiiiIIIII.getLoginResult().getScore(), (String)("\u5b88\u62a4\u4e4b\u5c18=" + this.IiiiiiiiIIIII), (int)3));
                IiiiiiiiIIIII.ALLATORIxDEMO(1);
                if (IiiiiiiiIIIII.getUsetime() <= 0) {
                    IiiiiiiiIIIII.iIiIiiiiIIiii(IiiiiiiiIIIII.getRgid());
                }
                this.IIIiiiiiIIiII[1].ALLATORIxDEMO(0, null);
                this.iIiIiiiiIIiIi(true);
                IiiiiiiiIIIII = new SuitOperBean();
                IiiiiiiiIIIII = new ArrayList<BigDecimal>();
                IiiiiiiiIIIII.add(IiiiiiiiIIIII.getRgid());
                IiiiiiiiIIIII.add(IiiiiiiiIIIII.getRgid());
                IiiiiiiiIIIII.setType(144);
                IiiiiiiiIIIII.setGoods(IiiiiiiiIIIII);
                IiiiiiiiIIIII = Agreement.getSendTextAES((String)"suitoperate", (String)iiIiiiiiIIiii.ALLATORIxDEMO().toJson(IiiiiiiiIIIII));
                this.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII);
                return true;
            }
            if (this.iiIIiiiiIiIIi != 2) return false;
            if (this.iIiIiiiiIIiii()) {
                return false;
            }
            IiiiiiiiIIIII = this.ALLATORIxDEMO();
            if (IiiiiiiiIIIII.getLoginResult().getGold().longValue() < this.iIIiIiiiiiiIi) {
                this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u91d1\u94b1\u4e0d\u8db3");
                return false;
            }
            v2 = IiiiiiiiIIIII = this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO() : null;
            if (IiiiiiiiIIIII != null) {
                IiiiiiiiIIIII = IiiiiiiiIIIII.getGood(IiiiiiiiIIIII.getRgid());
            }
            if (IiiiiiiiIIIII == null) {
                this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u8bf7\u9009\u62e9\u5b88\u62a4\u77f3\u6216\u5b88\u62a4\u77f3\u4e0d\u5728\u80cc\u5305");
                return false;
            }
            IiiiiiiiIIIII = IiiiiiiiIIIII.ALLATORIxDEMO(107L);
            if (IiiiiiiiIIIII == null) {
                this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u7f3a\u5c11\u7075\u5143\u6676");
                return false;
            }
            IiiiiiiiIIIII.getLoginResult().setGold(new BigDecimal(IiiiiiiiIIIII.getLoginResult().getGold().longValue() - this.iIIiIiiiiiiIi));
            IiiiiiiiIIIII.ALLATORIxDEMO(1);
            if (IiiiiiiiIIIII.getUsetime() <= 0) {
                IiiiiiiiIIIII.iIiIiiiiIIiii(IiiiiiiiIIIII.getRgid());
            }
            this.iIiIiiiiIIiIi(true);
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl91
        }
        if (id != 324) {
            if (id != 325) return false;
            this.iIiIiiiiIIiii(0);
            return true;
        }
        if (this.IIiiiiiiiIIIi == null) {
            return false;
        }
        IiiiiiiiIIIII = this.ALLATORIxDEMO().getGood(this.IIiiiiiiiIIIi.getRgid());
        if (IiiiiiiiIIIII == null) {
            this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u5b88\u62a4\u77f3\u4e0d\u5728\u80cc\u5305");
            return false;
        }
        IiiiiiiiIIIII.setValue(this.IIiiiiiiiIIIi.getNewAttr());
        IiiiiiiiIIIII = Agreement.getSendTextAES((String)"extrattroper", (String)iiIiiiiiIIiii.ALLATORIxDEMO().toJson(this.IIiiiiiiiIIIi));
        this.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII);
        this.IIiiiiiiiIIIi = null;
        IiiiiiiiIIIII = this.IIIiiiiiIIiII[0].ALLATORIxDEMO() == 1 ? (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO() : null;
        this.IiIIIiiiiIiiI.ALLATORIxDEMO(IiiiiiiiIIIII, this.ALLATORIxDEMO().ALLATORIxDEMO());
        this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
        return true;
        do {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII++].setVisible(false);
lbl91:
            // 2 sources

        } while (IiiiiiiiIIIII < this.IiIIiiiiIIIII.length);
        IiiiiiiiIIIII = new SuitOperBean();
        IiiiiiiiIIIII = new ArrayList<BigDecimal>();
        IiiiiiiiIIIII.add(IiiiiiiiIIIII.getRgid());
        IiiiiiiiIIIII.add(IiiiiiiiIIIII.getRgid());
        IiiiiiiiIIIII.setType(143);
        IiiiiiiiIIIII.setGoods(IiiiiiiiIIIII);
        IiiiiiiiIIIII = Agreement.getSendTextAES((String)"suitoperate", (String)iiIiiiiiIIiii.ALLATORIxDEMO().toJson(IiiiiiiiIIIII));
        this.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII);
        return true;
    }

    public IiIiIiiiiIIiI(GameView gameView) {
        super(175, 2, com.xy.q.IiiiIiiiiIiIi.iIIIIiiiiiIIi, gameView);
        this.ALLATORIxDEMO(-1, 0, 662, 485, com.xy.q.IiiiIiiiiIiIi.iiIIIiiiiiiiI);
        this.ALLATORIxDEMO(com.xy.w.IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/1.png", (int)68, (int)68, (int)68, (int)68, (boolean)false), "\u5b88\u62a4\u77f3\u64cd\u4f5c");
        this.iiiiIiiiIIiii = new IiiiiiiiiIIII[2];
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iiiiIiiiIIiii.length) {
            this.iiiiIiiiIIiii[IiiiiiiiIIIII] = new IiiiiiiiiIIII("sc/e/38.png", 2, 321 + IiiiiiiiIIIII, iiIIiiiiIiiII.IIiiiiiiiIIIi, iiIIiiiiIiiII.IIiiiiiiIiiII, IiiiiiiiIIIII == 0 ? "\u9644\u7075" : (IiiiiiiiIIIII == 1 ? "\u878d\u70bc" : ""), (com.xy.q.IiiiIiiiiIiIi)this);
            this.iiiiIiiiIIiii[IiiiiiiiIIIII].setBounds(54 + 102 * IiiiiiiiIIIII, 23, 95, 33);
            this.add((Component)this.iiiiIiiiIIiii[IiiiiiiiIIIII++]);
        }
        Color IiiiiiiiIIIII2 = iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c2A1C03");
        this.iiIiiiiiiiIii = new JLabel[9];
        int IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.iiIiiiiiiiIii.length) {
            this.iiIiiiiiiiIii[IiiiiiiiIIIII3] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)0, (int)0, (int)0, (int)0, (Color)IiiiiiiiIIIII2, (Font)iiIIiiiiIiiII.iiIIIiiiIiIii);
            if (IiiiiiiiIIIII3 >= 2 && IiiiiiiiIIIII3 <= 5) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setFont(iiIIiiiiIiiII.iiIiIiiiIIIII);
                if (IiiiiiiiIIIII3 == 2) {
                    this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setText("\u6d88\u8017\u91d1\u94b1");
                } else if (IiiiiiiiIIIII3 == 3) {
                    this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setText("\u62e5\u6709\u91d1\u94b1");
                }
            } else if (IiiiiiiiIIIII3 >= 6 && IiiiiiiiIIIII3 <= 7) {
                this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setText("\u953b\u70bc\u7b49\u7ea7");
                this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setFont(iiIIiiiiIiiII.iIIiiiiiiIIII);
                this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setForeground(iiIIiiiiIiiII.ALLATORIxDEMO((String)"#c2E1A05"));
                this.iiIiiiiiiiIii[IiiiiiiiIIIII3].setBounds(170 + (IiiiiiiiIIIII3 - 6) * 315, 106, 60, 17);
            }
            this.add(this.iiIiiiiiiiIii[IiiiiiiiIIIII3++]);
        }
        this.iIIIIiiiiiIIi = new iIIiIiiiIiiIi[5];
        IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.iIIIIiiiiiIIi.length) {
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII3] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)0, (int)0, (int)0, (int)0, (int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii);
            this.iIIIIiiiiiIIi[IiiiiiiiIIIII3].ALLATORIxDEMO(com.xy.w.IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/e/29.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
            if (IiiiiiiiIIIII3 >= 2 && IiiiiiiiIIIII3 <= 3) {
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII3].setBounds(227 + (IiiiiiiiIIIII3 - 2) * 315, 106, 44, 17);
            } else if (IiiiiiiiIIIII3 == 4) {
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII3].setForeground(Color.green);
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII3].setHorizontalAlignment(0);
                this.iIIIIiiiiiIIi[IiiiiiiiIIIII3].setBounds(386, 384, 44, 17);
            }
            this.add((Component)this.iIIIIiiiiiIIi[IiiiiiiiIIIII3++]);
        }
        this.IIIIiiiiiiiII = new iiIiIiiiiIiIi[2];
        IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.IIIIiiiiiiiII.length) {
            MoneyType IiiiiiiiIIIII4 = new MoneyType();
            if (IiiiiiiiIIIII3 == 0) {
                IiiiiiiiIIIII4.setIdAndKey(1, "\u91d1\u94b1");
            }
            this.IIIIiiiiiiiII[IiiiiiiiIIIII3] = IiIIIiiiiIIiI.ALLATORIxDEMO((int)10, (Color)Color.white, (Font)iiIIiiiiIiiII.iIIIiiiiIIIii, (MoneyType)IiiiiiiiIIIII4, (GameView)gameView);
            this.IIIIiiiiiiiII[IiiiiiiiIIIII3].ALLATORIxDEMO(com.xy.w.IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/e/29.png", (int)6, (int)6, (int)6, (int)6, (boolean)false));
            this.add((Component)this.IIIIiiiiiiiII[IiiiiiiiIIIII3++]);
        }
        this.IiIIiiiiIIIII = new IiiiiiiiiIIII[3];
        IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.IiIIiiiiIIIII.length) {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII3] = new IiiiiiiiiIIII("sc/e/26.png", 1, 323 + IiiiiiiiIIIII3, iiIIiiiiIiiII.iiiiIiiiIiiII, null, IiiiiiiiIIIII3 == 1 ? "\u66ff\u6362\u5c5e\u6027" : (IiiiiiiiIIIII3 == 2 ? "\u8fd4\u56de" : ""), (com.xy.q.IiiiIiiiiIiIi)this);
            if (IiiiiiiiIIIII3 == 1) {
                this.IiIIiiiiIIIII[IiiiiiiiIIIII3].setBounds(233, 426, 99, 25);
            } else if (IiiiiiiiIIIII3 == 2) {
                this.IiIIiiiiIIIII[IiiiiiiiIIIII3].setBounds(233, 426, 99, 25);
            }
            this.IiIIiiiiIIIII[IiiiiiiiIIIII3].setForeground(Color.black);
            this.add((Component)this.IiIIiiiiIIIII[IiiiiiiiIIIII3++]);
        }
        this.IIIiiiiiIIiII = new com.xy.q.IIIiiiiiIiIiI[2];
        IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.IIIiiiiiIIiII.length) {
            this.IIIiiiiiIIiII[IiiiiiiiIIIII3] = new com.xy.q.IIIiiiiiIiIiI((com.xy.q.IiiiIiiiiIiIi)this);
            this.IIIiiiiiIIiII[IiiiiiiiIIIII3].ALLATORIxDEMO("sc/d/180.png");
            this.IIIiiiiiIIiII[IiiiiiiiIIIII3].ALLATORIxDEMO(com.xy.q.IIIiiiiiIiIiI.IIIiiiiiiIiiI);
            this.add((Component)this.IIIiiiiiIIiII[IiiiiiiiIIIII3++]);
        }
        this.IiIIIiiiiIiiI = new IIiIiiiiIiIII(this, 0);
        this.iIiiIiiiiiiII = new IIiIiiiiIiIII(this, 1);
        this.add((Component)this.IiIIIiiiiIiiI);
        this.add((Component)this.iIiiIiiiiiiII);
        this.iiIiIiiiiIIIi = new IIIiiiiiIiIiI[4];
        IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < this.iiIiIiiiiIIIi.length) {
            this.iiIiIiiiiIIIi[IiiiiiiiIIIII3] = new IIIiiiiiIiIiI();
            if (IiiiiiiiIIIII3 == 0) {
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII3].ALLATORIxDEMO(com.xy.w.IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/35.png", (int)100, (int)2, (int)100, (int)2, (boolean)false));
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII3].setBounds(48, 37, 590, 20);
            } else if (IiiiiiiiIIIII3 != 1 && IiiiiiiiIIIII3 != 2 && IiiiiiiiIIIII3 == 3) {
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII3].iIiIiiiiIIiii("sc/d/183.png");
                this.iiIiIiiiiIIIi[IiiiiiiiIIIII3].setBounds(46, 59, 592, 347);
            }
            this.add((Component)this.iiIiIiiiiIIIi[IiiiiiiiIIIII3++]);
        }
    }

    /*
     * WARNING - void declaration
     */
    public void ALLATORIxDEMO(Goodstable goodstable) {
        void good;
        this.IIIiiiiiIIiII[0].ALLATORIxDEMO(1, (Object)goodstable);
        this.IiIIIiiiiIiiI.ALLATORIxDEMO((Goodstable)good, this.ALLATORIxDEMO().ALLATORIxDEMO());
        if (this.iiIIiiiiIiIIi != 1) return;
        this.IIIiiiiiIIiII[1].ALLATORIxDEMO(0, null);
        this.iIiiIiiiiiiII.ALLATORIxDEMO(0, 0);
    }

    public int IiiIiiiiiiIiI() {
        return this.iiIIiiiiIiIIi;
    }

    static /* synthetic */ void ALLATORIxDEMO(IiIiIiiiiIIiI arg0, Image arg1) {
        arg0.IIiiIiiiIIiIi = arg1;
    }

    static /* synthetic */ IIiIiiiiIiIII ALLATORIxDEMO(IiIiIiiiiIIiI arg0) {
        return arg0.IiIIIiiiiIiiI;
    }

    public void iIiIiiiiIIiii(com.xy.q.IIIiiiiiIiIiI imgGrid) {
        if (this.iIiIiiiiIIiii()) {
            return;
        }
        if (imgGrid == this.IIIiiiiiIIiII[0]) {
            this.ALLATORIxDEMO(imgGrid);
            return;
        }
        if (imgGrid != this.IIIiiiiiIIiII[1]) return;
        this.iiiIiiiiiiIIi(imgGrid);
    }

    public static int iIiIiiiiIIiIi() {
        int IiiiiiiiIIIII = IiiiIiiiiIiIi.iIiIiiiiIiIii.nextInt(100);
        if (IiiiiiiiIIIII < 4) {
            return 2;
        }
        if (IiiiiiiiIIIII >= 20) return 0;
        return 1;
    }

    public void iiiIiiiiiiIIi(boolean is) {
        if (this.IIiiiiiiIiiII == null) {
            return;
        }
        if (is) {
            if (this.iiIIiiiiIiIIi == 0) {
                this.IIiiiiiiIiiII.setBounds(10, 208, 330, 150);
            } else if (this.iiIIiiiiIiIIi == 1 && (Integer)this.IIiiiiiiIiiII.iiIiiiiiiiIii == 0) {
                this.IIiiiiiiIiiII.setBounds(10, 122, 330, 150);
            } else if (this.iiIIiiiiIiIIi == 1 && (Integer)this.IIiiiiiiIiiII.iiIiiiiiiiIii == 1) {
                this.IIiiiiiiIiiII.setBounds(325, 122, 330, 150);
            }
        }
        this.IIiiiiiiIiiII.setVisible(is);
    }

    static /* synthetic */ Image ALLATORIxDEMO(IiIiIiiiiIIiI arg0) {
        return arg0.IIiiIiiiIIiIi;
    }

    public void ALLATORIxDEMO(com.xy.q.IIIiiiiiIiIiI imgGrid) {
        if (this.iiIIiiiiIiIIi != 0) {
            if (this.iiIIiiiiIiIIi != 1) return;
        }
        this.iiiIiiiiiiIIi(0);
    }

    public static int iiiIiiiiiiIIi() {
        int IiiiiiiiIIIII = IiiiIiiiiIiIi.iIiIiiiiIiIii.nextInt(100);
        if (IiiiiiiiIIIII < 5) {
            return 4;
        }
        if (IiiiiiiiIIIII < 35) {
            return 3;
        }
        if (IiiiiiiiIIIII >= 75) return 1;
        return 2;
    }

    public void ALLATORIxDEMO(int type, Object animationData) {
        if (type != this.iiIIiiiiIiIIi) {
            return;
        }
        this.iIiiIiiiIiIIi = animationData;
    }

    public boolean ALLATORIxDEMO(Goodstable good) {
        Goodstable IiiiiiiiIIIII = (Goodstable)this.IIIiiiiiIIiII[0].ALLATORIxDEMO();
        if (IiiiiiiiIIIII == null) return false;
        if (IIiiIiiiiIIiI.ALLATORIxDEMO((BigDecimal)IiiiiiiiIIIII.getRgid(), (BigDecimal)good.getRgid())) {
            return false;
        }
        if (IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.IiIIIiiiiIiiI) >= 2 + IIiiIiiiiIIiI.ALLATORIxDEMO((String)good.getValue(), (String)"\u7b49\u7ea7=", (String)"|")) {
            return false;
        }
        AlchemySet IiiiiiiiIIIII2 = this.ALLATORIxDEMO().ALLATORIxDEMO();
        if (IiiiiiiiIIIII2 == null) {
            return false;
        }
        int IiiiiiiiIIIII3 = 0;
        while (IiiiiiiiIIIII3 < IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.IiIIIiiiiIiiI).length) {
            block9: {
                String IiiiiiiiIIIII4;
                block10: {
                    IIIIIiiiIiiII IiiiiiiiIIIII5;
                    block8: {
                        AlchemyUnit IiiiiiiiIIIII6;
                        IiiiiiiiIIIII5 = IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.IiIIIiiiiIiiI)[IiiiiiiiIIIII3];
                        IiiiiiiiIIIII4 = null;
                        if (IiiiiiiiIIIII3 >= 5) break block8;
                        if (IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5)) || (IiiiiiiiIIIII6 = IiiiiiiiIIIII2.getAlchemyUnit(IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5))) == null || IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) >= IiiiiiiiIIIII6.getMax()) break block9;
                        IiiiiiiiIIIII4 = "|" + IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) + "=";
                        break block10;
                    }
                    if (IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) == 0 || IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) >= 15.0) break block9;
                    IiiiiiiiIIIII4 = "|\u6280\u80fd=" + IIIIIiiiIiiII.ALLATORIxDEMO((IIIIIiiiIiiII)IiiiiiiiIIIII5) + "#";
                }
                if (good.getValue().indexOf(IiiiiiiiIIIII4) != -1) {
                    return true;
                }
            }
            ++IiiiiiiiIIIII3;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     */
    protected void paintComponent(Graphics g) {
        block4: {
            super.paintComponent(g);
            if (this.iiIIIiiiiiiiI == false) return;
            IiiiiiiiIIIII = (iIiIIiiiIiiiI.ALLATORIxDEMO() - this.ALLATORIxDEMO) / 160L;
            if (IiiiiiiiIIIII <= this.IIIIIiiiIiIIi) return;
            this.IIIIIiiiIiIIi = IiiiiiiiIIIII;
            if (this.iiIIiiiiIiIIi == 1) {
                if (this.iIiiIiiiIiIIi != null && IiiiiiiiIIIII >= 6L) {
                    this.IIiiiiiiiIIIi = (QualityClBean)this.iIiiIiiiIiIIi;
                    this.iIiIiiiiIIiIi(false);
                    this.iiiIiiiiiiIIi();
                    if (IIiiIiiiiIIiI.iIiIiiiiIIiIi((String)this.IIiiiiiiiIIIi.getNewAttr())) {
                        this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u526f\u5b88\u62a4\u77f3\u4e2d\u63d0\u53d6\u51fa\u5339\u914d\u5c5e\u6027/\u7279\u6280\u4e0e\u4e3b\u5b88\u62a4\u77f3\u4e0d\u5339\u914d\uff0c\u4e3b\u5b88\u62a4\u77f3\u672a\u53d1\u751f\u53d8\u5316");
                        return;
                    }
                    this.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u6210\u529f\u4ece\u526f\u5b88\u62a4\u77f3\u4e2d\u63d0\u53d6\u51fa\u5339\u914d\u5c5e\u6027/\u7279\u6280\uff0c\u4e3b\u5b88\u62a4\u77f3\u83b7\u5f97\u589e\u5f3a");
                    return;
                }
                this.iIiiIiiiiiiII.ALLATORIxDEMO();
                return;
            }
            if (this.iiIIiiiiIiIIi != 2) return;
            if (this.iIiiIiiiIiIIi == null || IiiiiiiiIIIII < 6L) break block4;
            this.IIiiiiiiiIIIi = (QualityClBean)this.iIiiIiiiIiIIi;
            this.iIiIiiiiIIiIi(false);
            this.iIiiIiiiiiiII.ALLATORIxDEMO(this.IIiiiiiiiIIIi.getNewAttr(), this.ALLATORIxDEMO().ALLATORIxDEMO());
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl30
        }
        this.iIiiIiiiiiiII.iIiIiiiiIIiii();
        return;
        do {
            this.IiIIiiiiIIIII[IiiiiiiiIIIII++].setVisible(true);
lbl30:
            // 2 sources

        } while (IiiiiiiiIIIII < this.IiIIiiiiIIIII.length);
    }

    protected void paintChildren(Graphics g) {
        super.paintChildren(g);
        if (this.IiiiIiiiIiIII != null && this.IiiiIiiiIiIII.size() > 0) {
            long IiiiiiiiIIIII = iIiIIiiiIiiiI.ALLATORIxDEMO();
            int IiiiiiiiIIIII2 = this.IiiiIiiiIiIII.size() - 1;
            while (IiiiiiiiIIIII2 >= 0) {
                long l;
                IIIIIiiiIiIii IiiiiiiiIIIII3;
                IIIIiiiiIIIIi IiiiiiiiIIIII4 = this.IiiiIiiiIiIII.get(IiiiiiiiIIIII2);
                IIIIIiiiIiIii iIIIIiiiIiIii = IiiiiiiiIIIII3 = IiiiiiiiIIIII4.ALLATORIxDEMO == 0L ? this.IiIiiiiiIIIII : this.IiiIIiiiiiiiI;
                if (IiiiiiiiIIIII3 == null && IiiiiiiiIIIII4.ALLATORIxDEMO == 0L) {
                    IiiiiiiiIIIII3 = this.IiIiiiiiIIIII = iiiiiiiiiiIiI.iIiIiiiiIIiii((String)"sc/mouse/shrl1.tcp");
                    l = IiiiiiiiIIIII;
                } else {
                    if (IiiiiiiiIIIII3 == null && IiiiiiiiIIIII4.ALLATORIxDEMO != 0L) {
                        IiiiiiiiIIIII3 = this.IiiIIiiiiiiiI = iiiiiiiiiiIiI.iIiIiiiiIIiii((String)"sc/mouse/shrl2.tcp");
                    }
                    l = IiiiiiiiIIIII;
                }
                long IiiiiiiiIIIII5 = l - IiiiiiiiIIIII4.iiIiiiiiiiIii - 100L;
                if (IiiiiiiiIIIII5 >= 0L) {
                    if (IiiiiiiiIIIII5 >= (long)(IiiiiiiiIIIII3 != null ? IiiiiiiiIIIII3.IIIiiiiiiIIiI() : 500)) {
                        this.IiiiIiiiIiIII.remove(IiiiiiiiIIIII2);
                    } else if (IiiiiiiiIIIII3 != null) {
                        IiiiiiiiIIIII3.ALLATORIxDEMO(IiiiiiiiIIIII5, 0);
                        IiiiiiiiIIIII3.ALLATORIxDEMO(g, (int)IiiiiiiiIIIII4.IiIIIiiiiIiiI, (int)IiiiiiiiIIIII4.IiiiiiiiIIIII);
                    }
                }
                --IiiiiiiiIIIII2;
            }
        }
        if (this.iiiiIiiiIiiII != null && this.iiiiIiiiIiiII.size() > 0) {
            g.setColor(Color.black);
            g.setFont(iiIIiiiiIiiII.iIIIiiiiIIIii);
            int IiiiiiiiIIIII = this.iiiiIiiiIiiII.size() - 1;
            while (IiiiiiiiIIIII >= 0) {
                iiIiIiiiiIiii IiiiiiiiIIIII6 = this.iiiiIiiiIiiII.get(IiiiiiiiIIIII);
                IIIIIiiiIiiII IiiiiiiiIIIII7 = IIiIiiiiIiIII.ALLATORIxDEMO((IIiIiiiiIiIII)this.IiIIIiiiiIiiI)[(int)IiiiiiiiIIIII6.ALLATORIxDEMO];
                --IiiiiiiiIIIII;
                g.drawString(IiiiiiiiIIIII6.ALLATORIxDEMO(), this.IiIIIiiiiIiiI.getX() + IiiiiiiiIIIII7.getX() + 267, this.IiIIIiiiiIiiI.getY() + IiiiiiiiIIIII7.getY() + 23);
            }
        }
        if (this.iiiiIiiiIiiII != null) return;
        this.iiiiIiiiIiiII = new ArrayList<iiIiIiiiiIiii>();
    }
}
