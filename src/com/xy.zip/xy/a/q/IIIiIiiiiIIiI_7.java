/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IiIiIiiiiIiii
 */
package com.xy.a.q;

import com.xy.a.q.IiIiIiiiiIiii;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIIiIiiiiIIiI
extends JComponent {
    final /* synthetic */ IiIiIiiiiIiii ALLATORIxDEMO;

    IIIiIiiiiIIiI(IiIiIiiiiIiii iiIiIiiiiIiii) {
        this.ALLATORIxDEMO = iiIiIiiiiIiii;
    }
}
