/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iIIIiiiiIiIII
 */
package com.xy.a.q;

import com.xy.a.q.iIIIiiiiIiIII;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiiIiiiiIIIiI
extends JComponent {
    final /* synthetic */ iIIIiiiiIiIII ALLATORIxDEMO;

    IiiIiiiiIIIiI(iIIIiiiiIiIII iIIIiiiiIiIII2) {
        this.ALLATORIxDEMO = iIIIiiiiIiIII2;
    }
}
