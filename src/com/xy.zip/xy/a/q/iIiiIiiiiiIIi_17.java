/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iiIIiiiiiIIII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.w.IIIIIiiiIiIii
 */
package com.xy.a.q;

import com.xy.a.q.iiIIiiiiiIIII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.w.IIIIIiiiIiIii;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIiiIiiiiiIIi
extends IIIiiiiiIiIiI {
    final /* synthetic */ iiIIiiiiiIIII ALLATORIxDEMO;

    /*
     * WARNING - void declaration
     */
    protected void paintComponent(Graphics g) {
        void IiiiiiiiIIIII;
        super.paintComponent(g);
        if (!iiIIiiiiiIIII.ALLATORIxDEMO((iiIIiiiiiIIII)this.ALLATORIxDEMO)) return;
        Graphics2D graphics2D = (Graphics2D)g;
        IiiiiiiiIIIII.setComposite(IIIIIiiiIiIii.iIiiIiiiiiiII);
        IiiiiiiiIIIII.setColor(Color.BLACK);
        IiiiiiiiIIIII.fillRoundRect(0, 0, 55, 55, 10, 10);
    }

    iIiiIiiiiiIIi(iiIIiiiiiIIII iiIIiiiiiIIII2, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iiIIiiiiiIIII2;
        super($anonymous0);
    }
}
