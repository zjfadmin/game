/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iIiIIiiiIIIiI
 */
package com.xy.a.q;

import com.xy.a.q.iIiIIiiiIIIiI;
import javax.swing.JComponent;

/*
 * Exception performing whole class analysis ignored.
 */
static class iIIiIiiiIiiIi
extends JComponent {
    final /* synthetic */ iIiIIiiiIIIiI ALLATORIxDEMO;

    iIIiIiiiIiiIi(iIiIIiiiIIIiI iIiIIiiiIIIiI2) {
        this.ALLATORIxDEMO = iIiIIiiiIIIiI2;
    }
}
