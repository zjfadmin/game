/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.iiIiIiiiiIiIi
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 */
package com.xy.a.q;

import com.xy.a.q.iiIiIiiiiIiIi;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiiiIiiiiIiIi;
import java.awt.event.MouseEvent;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiIIiiiIIIiI
extends IIIiiiiiIiIiI {
    final /* synthetic */ iiIiIiiiiIiIi ALLATORIxDEMO;

    public void ALLATORIxDEMO(MouseEvent e) {
        iiIiIiiiiIiIi.ALLATORIxDEMO((iiIiIiiiiIiIi)this.ALLATORIxDEMO).mouseReleased(e);
    }

    IIiIIiiiIIIiI(iiIiIiiiiIiIi iiIiIiiiiIiIi2, IiiiIiiiiIiIi $anonymous0) {
        this.ALLATORIxDEMO = iiIiIiiiiIiIi2;
        super($anonymous0);
    }
}
