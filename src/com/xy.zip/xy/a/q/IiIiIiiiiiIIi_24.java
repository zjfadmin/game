/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IiIIIiiiiiiII
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiIIIiiiiIIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iIIiIiiiIiiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.w.IIIIIiiiIiiII
 */
package com.xy.a.q;

import com.xy.a.q.IiIIIiiiiiiII;
import com.xy.q.IIIiiiiiIiIiI;
import com.xy.q.IiIIIiiiiIIiI;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iIIiIiiiIiiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.w.IIIIIiiiIiiII;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

/*
 * Exception performing whole class analysis ignored.
 */
static class IiIiIiiiiiIIi
extends IIIiiiiiIiIiI {
    private iIIiIiiiIiiIi IiiiiiiiIIIII;
    final /* synthetic */ IiIIIiiiiiiII ALLATORIxDEMO;

    static /* synthetic */ iIIiIiiiIiiIi ALLATORIxDEMO(IiIiIiiiiiIIi arg0) {
        return arg0.IiiiiiiiIIIII;
    }

    public IiIiIiiiiiIIi(IiIIIiiiiiiII iiIIIiiiiiiII, IiiiIiiiiIiIi form) {
        this.ALLATORIxDEMO = iiIIIiiiiiiII;
        super(form);
        this.IiiiiiiiIIIII = IiIIIiiiiIIiI.ALLATORIxDEMO((int)27, (int)1, (int)16, (int)16, (int)0, (Color)Color.GREEN, (Font)iiIIiiiiIiiII.iIiIIiiiIIIii);
        this.IiiiiiiiIIIII.ALLATORIxDEMO(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/b/S24.png", (int)3, (int)3, (int)3, (int)3, (boolean)false));
        this.add((Component)this.IiiiiiiiIIIII);
    }
}
