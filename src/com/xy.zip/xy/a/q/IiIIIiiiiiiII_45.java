/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.q.IiIiIiiiiiIIi
 *  com.xy.bean.ChongjipackBean
 *  com.xy.bean.LoginResult
 *  com.xy.bean.XXGDBean
 *  com.xy.formula.GoodType
 *  com.xy.i.iIIIIiiiIiiIi
 *  com.xy.q.IIIiiiiiIiIiI
 *  com.xy.q.IiiiIiiiiIiIi
 *  com.xy.q.iiIIiiiiIiiII
 *  com.xy.readbean.Goodstable
 *  com.xy.richtext.RichLabel
 *  com.xy.socket.Agreement
 *  com.xy.v.IIiiIiiiiIIiI
 *  com.xy.v.IiiiIiiiiIIII
 *  com.xy.v.IiiiiiiiiIIII
 *  com.xy.w.IIIIIiiiIiiII
 *  com.xy.w.IIIiiiiiIiIiI
 */
package com.xy.a.q;

import com.xy.a.q.IiIiIiiiiiIIi;
import com.xy.bean.ChongjipackBean;
import com.xy.bean.LoginResult;
import com.xy.bean.XXGDBean;
import com.xy.formula.GoodType;
import com.xy.i.iIIIIiiiIiiIi;
import com.xy.q.IiiiIiiiiIiIi;
import com.xy.q.iiIIiiiiIiiII;
import com.xy.readbean.Goodstable;
import com.xy.richtext.RichLabel;
import com.xy.socket.Agreement;
import com.xy.v.IIiiIiiiiIIiI;
import com.xy.v.IiiiIiiiiIIII;
import com.xy.v.IiiiiiiiiIIII;
import com.xy.w.IIIIIiiiIiiII;
import com.xy.w.IIIiiiiiIiIiI;
import java.awt.Component;
import java.awt.Dimension;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JPanel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class IiIIIiiiiiiII
extends JPanel {
    private ChongjipackBean iiiIiiiiiiiIi;
    private RichLabel iIiiIiiiiiiII;
    private IIIiiiiiIiIiI IIiiIiiiIIiIi;
    private IiIiIiiiiiIIi[] iIiIiiiiIiIii;
    private RichLabel IiIIIiiiiIiiI;
    private int iiIiiiiiiiIii;
    private iIIIIiiiIiiIi IiiiiiiiIIIII;
    private IiiiIiiiiIiIi ALLATORIxDEMO;

    public ChongjipackBean ALLATORIxDEMO() {
        return this.iiiIiiiiiiiIi;
    }

    public static void main(String[] stringArray) {
        System.out.println("\n################################################\n#                                              #\n#        ## #   #    ## ### ### ##  ###        #\n#       # # #   #   # #  #  # # # #  #         #\n#       ### #   #   ###  #  # # ##   #         #\n#       # # ### ### # #  #  ### # # ###        #\n#                                              #\n# Obfuscation by Allatori Obfuscator v7.7 DEMO #\n#                                              #\n#           http://www.allatori.com            #\n#                                              #\n################################################\n");
        String[] IiiiiiiiIIIII = "4=1|2,2|3,3|4|5|6|7|9|10|11|12|13|14&&1=1|2|3|4|5|6&&6=1|2|3|4|5|6".split("&&");
        System.out.println(IiIIIiiiiiiII.ALLATORIxDEMO(IiiiiiiiIIIII, 4, 1));
        System.out.println(IiIIIiiiiiiII.ALLATORIxDEMO(IiiiiiiiIIIII, 4, 2));
        System.out.println(IiIIIiiiiiiII.ALLATORIxDEMO(IiiiiiiiIIIII, 4, 3));
        System.out.println(IiIIIiiiiiiII.ALLATORIxDEMO(IiiiiiiiIIIII, 4, 4));
    }

    public IiIIIiiiiiiII(IiiiIiiiiIiIi form) {
        this.ALLATORIxDEMO = form;
        this.setPreferredSize(new Dimension(463, 61));
        this.setOpaque(false);
        this.setLayout(null);
        this.iIiIiiiiIiIii = new IiIiIiiiiiIIi[5];
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIiIiiiiIiIii.length) {
            this.iIiIiiiiIiIii[IiiiiiiiIIIII] = new IiIiIiiiiiIIi(this, form);
            this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO(com.xy.q.IIIiiiiiIiIiI.iIiIiiiiIiIii);
            this.iIiIiiiiIiIii[IiiiiiiiIIIII].ALLATORIxDEMO("sc/d/4.png");
            this.iIiIiiiiIiIii[IiiiiiiiIIIII].setBounds(14 + IiiiiiiiIIIII * 51, 9, 46, 46);
            this.add((Component)this.iIiIiiiiIiIii[IiiiiiiiIIIII++]);
        }
        this.IiiiiiiiIIIII = new iIIIIiiiIiiIi("sc/e/31.png", 1, 0, iiIIiiiiIiiII.iiiiIiiiIiiII, iiIIiiiiIiiII.IIiiiiiiIiiII, "\u9886\u53d6", form);
        this.IiiiiiiiIIIII.ALLATORIxDEMO((JComponent)this);
        this.IiiiiiiiIIIII.setBounds(360, 17, 79, 25);
        this.add((Component)this.IiiiiiiiIIIII);
        this.IiIIIiiiiIiiI = new RichLabel("1\u7ea7\u5956\u52b1", iiIIiiiiIiiII.iIiIIiiiiIIiI);
        this.iIiiIiiiiiiII = new RichLabel("#R\u6682\u4e0d\u53ef\u9886\u53d6", iiIIiiiiIiiII.iIiIIiiiiIIiI);
        this.IiIIIiiiiIiiI.setTextSize("1\u7ea7\u5956\u52b1", 136);
        this.iIiiIiiiiiiII.setTextSize("#R\u6682\u4e0d\u53ef\u9886\u53d6", 136);
        this.IiIIIiiiiIiiI.setBounds(270, 10, this.IiIIIiiiiIiiI.getWidth(), this.IiIIIiiiiIiiI.getHeight());
        this.iIiiIiiiiiiII.setBounds(270, 30, this.iIiiIiiiiiiII.getWidth(), this.iIiiIiiiiiiII.getHeight());
        this.add((Component)this.IiIIIiiiiIiiI);
        this.add((Component)this.iIiiIiiiiiiII);
        this.IIiiIiiiIIiIi = new IIIiiiiiIiIiI(IIIIIiiiIiiII.ALLATORIxDEMO((String)"sc/d/66.png", (int)30, (int)1, (int)30, (int)1, (boolean)false));
        this.IIiiIiiiIIiIi.setBounds(15, 59, 433, 2);
        this.add((Component)this.IIiiIiiiIIiIi);
    }

    public void ALLATORIxDEMO(ChongjipackBean bean, int typeMenu) {
        Goodstable IiiiiiiiIIIII;
        int IiiiiiiiIIIII2;
        this.iiiIiiiiiiiIi = bean;
        this.iIiIiiiiIIiii();
        if (bean == null) {
            return;
        }
        List IiiiiiiiIIIII3 = ChongjipackBean.getGoodsImpactGrade((String)bean.getPackgoods());
        IiiiiiiiiIIII IiiiiiiiIIIII4 = this.ALLATORIxDEMO.ALLATORIxDEMO();
        LoginResult IiiiiiiiIIIII5 = this.ALLATORIxDEMO.ALLATORIxDEMO().getLoginResult();
        boolean IiiiiiiiIIIII6 = false;
        if (IiiiIiiiiIIII.iIiIiiiiIIiii((int)IiiiiiiiIIIII5.getGrade(), (String)bean.getPackgrade())) {
            IiiiiiiiIIIII2 = -1;
            if (typeMenu == 1) {
                IiiiiiiiIIIII2 = 4;
            } else if (typeMenu - 1 == IiiiiiiiIIIII5.getLowOrHihtpack()) {
                IiiiiiiiIIIII2 = 5;
            }
            if (IiiiiiiiIIIII2 != -1) {
                IiiiiiiiIIIII = null;
                if (IiiiiiiiIIIII5.getVipget() != null) {
                    IiiiiiiiIIIII = IiiiiiiiIIIII5.getVipget().split("&&");
                }
                if (IiIIIiiiiiiII.ALLATORIxDEMO((String[])IiiiiiiiIIIII, IiiiiiiiIIIII2, bean.getPackgradetype())) {
                    this.iIiiIiiiiiiII.setText("#G\u5df2\u9886\u53d6");
                } else {
                    IiiiiiiiIIIII6 = true;
                    this.iIiiIiiiiiiII.setText("#Y\u672a\u9886\u53d6");
                }
            } else {
                this.iIiiIiiiiiiII.setText("#R\u6682\u4e0d\u53ef\u9886\u53d6");
            }
        } else {
            this.iIiiIiiiiiiII.setText("#R\u6682\u4e0d\u53ef\u9886\u53d6");
        }
        this.iiIiiiiiiiIii = 0;
        IiiiiiiiIIIII2 = 0;
        while (IiiiiiiiIIIII2 < IiiiiiiiIIIII3.size() && IiiiiiiiIIIII2 < this.iIiIiiiiIiIii.length) {
            IiiiiiiiIIIII = IiiiiiiiIIIII4.ALLATORIxDEMO(((XXGDBean)IiiiiiiiIIIII3.get(IiiiiiiiIIIII2)).getId());
            IiIiIiiiiiIIi.ALLATORIxDEMO((IiIiIiiiiiIIi)this.iIiIiiiiIiIii[IiiiiiiiIIIII2]).setText(String.valueOf(((XXGDBean)IiiiiiiiIIIII3.get(IiiiiiiiIIIII2)).getSum()));
            this.iIiIiiiiIiIii[IiiiiiiiIIIII2].ALLATORIxDEMO(1, (Object)IiiiiiiiIIIII);
            int n = !GoodType.ALLATORIxDEMO((Long)IiiiiiiiIIIII.getType()) ? ((XXGDBean)IiiiiiiiIIIII3.get(IiiiiiiiIIIII2)).getSum() : 1;
            ++IiiiiiiiIIIII2;
            this.iiIiiiiiiiIii += n;
        }
        this.IiiiiiiiIIIII.setVisible(IiiiiiiiIIIII6);
        this.iIiiIiiiiiiII.setBounds(270, 30, this.iIiiIiiiiiiII.getWidth(), this.iIiiIiiiiiiII.getHeight());
        this.ALLATORIxDEMO(bean.getPackgrade());
    }

    /*
     * Unable to fully structure code
     */
    public static boolean ALLATORIxDEMO(String[] infoArr, int action, int grade) {
        if (infoArr == null) {
            return false;
        }
        IiiiiiiiIIIII = String.valueOf(action) + "=";
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < infoArr.length) {
            if (!infoArr[IiiiiiiiIIIII].startsWith(IiiiiiiiIIIII)) {
                ++IiiiiiiiIIIII;
                continue;
            }
            IiiiiiiiIIIII = IiiiiiiiIIIII.length();
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl17
            do {
                if ((IiiiiiiiIIIII = infoArr[IiiiiiiiIIIII].indexOf("|", IiiiiiiiIIIII + 1)) == -1) {
                    IiiiiiiiIIIII = infoArr[IiiiiiiiIIIII].length();
                }
                if (IIiiIiiiiIIiI.ALLATORIxDEMO((String)infoArr[IiiiiiiiIIIII], (int)IiiiiiiiIIIII, (int)IiiiiiiiIIIII) == grade) return true;
                IiiiiiiiIIIII = IiiiiiiiIIIII + 1;
lbl17:
                // 2 sources

            } while (IiiiiiiiIIIII < infoArr[IiiiiiiiIIIII].length());
            break;
        }
        return false;
    }

    public void iIiIiiiiIIiii() {
        this.IiiiiiiiIIIII.setVisible(false);
        int IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < this.iIiIiiiiIiIii.length) {
            IiIiIiiiiiIIi iiIiIiiiiiIIi = this.iIiIiiiiIiIii[IiiiiiiiIIIII];
            ++IiiiiiiiIIIII;
            iiIiIiiiiiIIi.ALLATORIxDEMO(0, null);
        }
    }

    /*
     * Unable to fully structure code
     */
    public static int ALLATORIxDEMO(String[] infoArr, int action, int grade) {
        if (infoArr == null) {
            return 0;
        }
        IiiiiiiiIIIII = String.valueOf(action) + "=";
        IiiiiiiiIIIII = 0;
        while (IiiiiiiiIIIII < infoArr.length) {
            if (!infoArr[IiiiiiiiIIIII].startsWith(IiiiiiiiIIIII)) {
                ++IiiiiiiiIIIII;
                continue;
            }
            IiiiiiiiIIIII = IiiiiiiiIIIII.length();
            IiiiiiiiIIIII = 0;
            IiiiiiiiIIIII = 0;
            if (true) ** GOTO lbl22
            do {
                if ((IiiiiiiiIIIII = infoArr[IiiiiiiiIIIII].indexOf("|", IiiiiiiiIIIII + 1)) == -1) {
                    IiiiiiiiIIIII = infoArr[IiiiiiiiIIIII].length();
                }
                if ((IiiiiiiiIIIII = infoArr[IiiiiiiiIIIII].indexOf(",", IiiiiiiiIIIII + 1)) == -1 || IiiiiiiiIIIII > IiiiiiiiIIIII) {
                    IiiiiiiiIIIII = IiiiiiiiIIIII;
                }
                if (IIiiIiiiiIIiI.ALLATORIxDEMO((String)infoArr[IiiiiiiiIIIII], (int)IiiiiiiiIIIII, (int)IiiiiiiiIIIII) == grade) {
                    if (IiiiiiiiIIIII >= IiiiiiiiIIIII) return 1;
                    return IIiiIiiiiIIiI.ALLATORIxDEMO((String)infoArr[IiiiiiiiIIIII], (int)(IiiiiiiiIIIII + 1), (int)IiiiiiiiIIIII);
                }
                IiiiiiiiIIIII = IiiiiiiiIIIII + 1;
lbl22:
                // 2 sources

            } while (IiiiiiiiIIIII < infoArr[IiiiiiiiIIIII].length());
            break;
        }
        return 0;
    }

    public void ALLATORIxDEMO() {
        if (this.iiiIiiiiiiiIi == null) {
            return;
        }
        if (this.ALLATORIxDEMO.ALLATORIxDEMO().getGoodPackSum(-1L, new BigDecimal(-1), this.iiIiiiiiiiIii) < this.iiIiiiiiiiIii) {
            this.ALLATORIxDEMO.iiIIiiiiIiIIi.iiiIiiiiiiIIi("\u4f60\u7684\u80cc\u5305\u4e0d\u591f");
            return;
        }
        String IiiiiiiiIIIII = Agreement.getSendTextAES((String)"Chongjipacksure", (String)(this.iiiIiiiiiiiIi.getPacktype() + "|" + this.iiiIiiiiiiiIi.getPackgradetype()));
        this.ALLATORIxDEMO.ALLATORIxDEMO().ALLATORIxDEMO(IiiiiiiiIIIII);
    }

    public void ALLATORIxDEMO(String text) {
        this.IiIIIiiiiIiiI.setTextSize(text, 136);
        this.IiIIIiiiiIiiI.setBounds(270, 10, this.IiIIIiiiiIiiI.getWidth(), this.IiIIIiiiiIiiI.getHeight());
    }
}
