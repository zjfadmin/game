/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.iiIiiiiiIIiIi
 */
package com.xy.a;

import com.xy.a.iiIiiiiiIIiIi;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/*
 * Exception performing whole class analysis ignored.
 */
static class IIiiIiiiIiIii
extends DefaultTableCellRenderer {
    final /* synthetic */ iiIiiiiiIIiIi ALLATORIxDEMO;

    IIiiIiiiIiIii(iiIiiiiiIIiIi iiIiiiiiIIiIi2) {
        this.ALLATORIxDEMO = iiIiiiiiIIiIi2;
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public Component getTableCellRendererComponent(JTable jTable, Object object, boolean bl, boolean bl2, int n, int n2) {
        void column;
        void row;
        void hasFocus;
        void isSelected;
        void value;
        void table;
        this.setForeground(Color.white);
        return super.getTableCellRendererComponent((JTable)table, value, (boolean)isSelected, (boolean)hasFocus, (int)row, (int)column);
    }
}
