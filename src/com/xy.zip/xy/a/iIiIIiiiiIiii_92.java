/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.a.IiIiIiiiIIiiI
 *  com.xy.a.iiIiiiiiIIIiI
 *  com.xy.i.IIIIIiiiIIIiI
 *  com.xy.q.iiIIiiiiIiiII
 */
package com.xy.a;

import com.xy.a.IiIiIiiiIIiiI;
import com.xy.a.iiIiiiiiIIIiI;
import com.xy.i.IIIIIiiiIIIiI;
import com.xy.q.iiIIiiiiIiiII;
import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 * Exception performing whole class analysis ignored.
 */
static class iIiIIiiiiIiii
extends JComponent {
    int IiIIIiiiiIiiI;
    int iiIiiiiiiiIii;
    List<IIIIIiiiIIIiI> IiiiiiiiIIIII = new ArrayList<IIIIIiiiIIIiI>();
    final /* synthetic */ IiIiIiiiIIiiI ALLATORIxDEMO;

    public void ALLATORIxDEMO(int id) {
        if (this.IiIIIiiiiIiiI == id && id != 13) {
            return;
        }
        this.IiIIIiiiiIiiI = id;
        IIIIIiiiIIIiI IiiiiiiiIIIII = null;
        if (id == 13) {
            if (this.ALLATORIxDEMO.ALLATORIxDEMO().teamBean == null) {
                IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
                IiiiiiiiIIIII.setText("\u7ec4\u961f\u64cd\u4f5c");
                IiiiiiiiIIIII.ALLATORIxDEMO(22);
                IiiiiiiiIIIII = this.ALLATORIxDEMO(1);
                IiiiiiiiIIIII.setText("\u521b\u5efa\u961f\u4f0d");
                IiiiiiiiIIIII.ALLATORIxDEMO(23);
                this.iiIiiiiiiiIii = 2;
            } else {
                IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
                IiiiiiiiIIIII.setText("\u7ec4\u961f\u4fe1\u606f");
                IiiiiiiiIIIII.ALLATORIxDEMO(22);
                this.iiIiiiiiiiIii = 1;
            }
        } else if (id == 15) {
            IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
            IiiiiiiiIIIII.setText("\u4ea4\u6613");
            IiiiiiiiIIIII.ALLATORIxDEMO(24);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(1);
            IiiiiiiiIIIII.setText("\u7ed9\u4e88");
            IiiiiiiiIIIII.ALLATORIxDEMO(25);
            this.iiIiiiiiiiIii = 2;
        } else if (id == 17) {
            IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
            IiiiiiiiIIIII.setText("\u5750\u9a91");
            IiiiiiiiIIIII.ALLATORIxDEMO(26);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(1);
            IiiiiiiiIIIII.setText("\u98de\u884c\u5668");
            IiiiiiiiIIIII.ALLATORIxDEMO(27);
            this.iiIiiiiiiiIii = 2;
        } else if (id == 21) {
            if (this.ALLATORIxDEMO.ALLATORIxDEMO().ALLATORIxDEMO(2, 12)) {
                IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
                IiiiiiiiIIIII.setText("\u65b0\u624b\u6307\u5f15");
                IiiiiiiiIIIII.ALLATORIxDEMO(61);
                IiiiiiiiIIIII = this.ALLATORIxDEMO(1);
                IiiiiiiiIIIII.setText("\u5feb\u6377\u64cd\u4f5c(3)");
                IiiiiiiiIIIII.ALLATORIxDEMO(62);
            } else {
                IiiiiiiiIIIII = this.ALLATORIxDEMO(0);
                IiiiiiiiIIIII.setText("\u534f\u8bae\u53ca\u9690\u79c1");
                IiiiiiiiIIIII.ALLATORIxDEMO(70);
                IiiiiiiiIIIII = this.ALLATORIxDEMO(1);
                IiiiiiiiIIIII.setText("\u7cbe\u5f69\u5206\u4eab");
                IiiiiiiiIIIII.ALLATORIxDEMO(70);
            }
            IiiiiiiiIIIII = this.ALLATORIxDEMO(2);
            IiiiiiiiIIIII.setText("\u964d\u5996\u4f0f\u9b54");
            IiiiiiiiIIIII.ALLATORIxDEMO(60);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(3);
            IiiiiiiiIIIII.setText("\u6708\u5361\u5151\u6362");
            IiiiiiiiIIIII.ALLATORIxDEMO(57);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(4);
            IiiiiiiiIIIII.setText("\u7d2f\u8ba1\u9886\u53d6");
            IiiiiiiiIIIII.ALLATORIxDEMO(56);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(5);
            IiiiiiiiIIIII.setText("\u5151\u6362\u5408\u6210");
            IiiiiiiiIIIII.ALLATORIxDEMO(55);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(6);
            IiiiiiiiIIIII.setText("\u6e38\u620f\u5b98\u7f51");
            IiiiiiiiIIIII.ALLATORIxDEMO(58);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(7);
            IiiiiiiiIIIII.setText("\u4ed9\u7389\u5bc4\u552e");
            IiiiiiiiIIIII.ALLATORIxDEMO(59);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(8);
            IiiiiiiiIIIII.setText("\u751f\u6210\u5236\u4f5c");
            IiiiiiiiIIIII.ALLATORIxDEMO(54);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(9);
            IiiiiiiiIIIII.setText("\u6e38\u620f\u52a9\u624b");
            IiiiiiiiIIIII.ALLATORIxDEMO(53);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(10);
            IiiiiiiiIIIII.setText("\u8f85\u52a9\u70bc\u5316");
            IiiiiiiiIIIII.ALLATORIxDEMO(52);
            IiiiiiiiIIIII.setForeground(Color.red);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(11);
            IiiiiiiiIIIII.setText("\u6e38\u620f\u8bbe\u7f6e");
            IiiiiiiiIIIII.ALLATORIxDEMO(51);
            IiiiiiiiIIIII = this.ALLATORIxDEMO(12);
            IiiiiiiiIIIII.setText("\u9000\u51fa\u6e38\u620f");
            IiiiiiiiIIIII.ALLATORIxDEMO(51);
            this.iiIiiiiiiiIii = 13;
        }
        int IiiiiiiiIIIII2 = this.iiIiiiiiiiIii;
        while (IiiiiiiiIIIII2 < this.IiiiiiiiIIIII.size()) {
            IIIIIiiiIIIiI iIIIIiiiIIIiI = this.IiiiiiiiIIIII.get(IiiiiiiiIIIII2);
            ++IiiiiiiiIIIII2;
            iIIIIiiiIIIiI.setVisible(false);
        }
        this.ALLATORIxDEMO();
    }

    public void ALLATORIxDEMO() {
        iiIiiiiiIIIiI IiiiiiiiIIIII = IiIiIiiiIIiiI.ALLATORIxDEMO((IiIiIiiiIIiiI)this.ALLATORIxDEMO)[this.IiIIIiiiiIiiI - 10];
        int IiiiiiiiIIIII2 = 118;
        int IiiiiiiiIIIII3 = 24 * this.iiIiiiiiiiIii;
        int IiiiiiiiIIIII4 = IiiiiiiiIIIII.getX();
        int IiiiiiiiIIIII5 = IiiiiiiiIIIII.getY();
        IiiiiiiiIIIII4 -= (IiiiiiiiIIIII2 - IiiiiiiiIIIII.getWidth()) / 2;
        IiiiiiiiIIIII4 = Math.min(IiiiiiiiIIIII4, this.ALLATORIxDEMO.iiIIiiiiIiIIi.screenData.getScreen_x() - IiiiiiiiIIIII2);
        this.setBounds(IiiiiiiiIIIII4, IiiiiiiiIIIII5 - IiiiiiiiIIIII3, IiiiiiiiIIIII2, IiiiiiiiIIIII3);
    }

    public IIIIIiiiIIIiI ALLATORIxDEMO(int index) {
        IIIIIiiiIIIiI IiiiiiiiIIIII;
        IIIIIiiiIIIiI iIIIIiiiIIIiI = IiiiiiiiIIIII = index < this.IiiiiiiiIIIII.size() ? this.IiiiiiiiIIIII.get(index) : null;
        if (IiiiiiiiIIIII == null) {
            IiiiiiiiIIIII = new IIIIIiiiIIIiI("sc/e/25.png", 1, 0, iiIIiiiiIiiII.iIiIIiiiiIIiI, null, "", this.ALLATORIxDEMO.ALLATORIxDEMO());
            IiiiiiiiIIIII.setBounds(0, 24 * index, 118, 24);
            this.add((Component)IiiiiiiiIIIII);
            this.IiiiiiiiIIIII.add(IiiiiiiiIIIII);
        }
        IiiiiiiiIIIII.setForeground(Color.white);
        IiiiiiiiIIIII.setVisible(true);
        return IiiiiiiiIIIII;
    }

    public iIiIIiiiiIiii(IiIiIiiiIIiiI iiIiIiiiIIiiI) {
        this.ALLATORIxDEMO = iiIiIiiiIIiiI;
    }
}
