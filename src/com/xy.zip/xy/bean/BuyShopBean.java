/*
 * Decompiled with CFR 0.152.
 */
package com.xy.bean;

public class BuyShopBean {
    private String cd;
    private Integer nId;
    private int ate;
    private int sum;

    public int getAte() {
        return this.ate;
    }

    public String getCd() {
        return this.cd;
    }

    public void setCd(String cd) {
        this.cd = cd;
    }

    public Integer getnId() {
        return this.nId;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }

    public void setnId(Integer nId) {
        this.nId = nId;
    }

    public int getSum() {
        return this.sum;
    }

    public void setAte(int ate) {
        this.ate = ate;
    }
}
