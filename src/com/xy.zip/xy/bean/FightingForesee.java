/*
 * Decompiled with CFR 0.152.
 */
package com.xy.bean;

public class FightingForesee {
    private String alias;
    private int type;
    private String robotid;
    private String erdui;
    private int I;
    private String yidui;
    private int nd;

    public void setI(int i) {
        this.I = i;
    }

    public String getYidui() {
        return this.yidui;
    }

    public String getAlias() {
        return this.alias;
    }

    public void setNd(int nd) {
        this.nd = nd;
    }

    public int getNd() {
        return this.nd;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getType() {
        return this.type;
    }

    public String getErdui() {
        return this.erdui;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setRobotid(String robotid) {
        this.robotid = robotid;
    }

    public int getI() {
        return this.I;
    }

    public void setYidui(String yidui) {
        this.yidui = yidui;
    }

    public String getRobotid() {
        return this.robotid;
    }

    public void setErdui(String erdui) {
        this.erdui = erdui;
    }
}
