/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.entity.Baby
 */
package com.xy.bean;

import com.xy.entity.Baby;
import java.util.List;

public class BabyListBean {
    private List<Baby> babyList;

    public void setBabyList(List<Baby> babyList) {
        this.babyList = babyList;
    }

    public List<Baby> getBabyList() {
        return this.babyList;
    }
}
