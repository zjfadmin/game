/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.xy.battle.BattlePlayProgress
 *  com.xy.battle.BattleScene
 *  com.xy.battle.FightingState
 *  com.xy.d.IiIiIiiiiIIiI
 */
package com.xy.battle.effect;

import com.xy.battle.BattlePlayProgress;
import com.xy.battle.BattleScene;
import com.xy.battle.FightingState;
import com.xy.d.IiIiIiiiiIIiI;

public interface Effect {
    public BattlePlayProgress ALLATORIxDEMO(FightingState var1, IiIiIiiiiIIiI var2, BattleScene var3);
}
